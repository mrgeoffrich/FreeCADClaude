; HEADER_BLOCK_START
; BambuStudio 02.08.01.55
; model printing time: 4m 1s; total estimated time: 4m 2s
; total layer number: 40
; total filament length [mm] : 331.99
; total filament volume [cm^3] : 798.54
; total filament weight [g] : 0.00
; model label id: 8,12
; object max height: 5.00,8.00
; filament_density: 0
; filament_diameter: 1.75
; max_z_height: 8.00
; filament: 1
; HEADER_BLOCK_END

; CONFIG_BLOCK_START
; accel_to_decel_enable = 0
; accel_to_decel_factor = 50%
; activate_air_filtration = 0
; additional_cooling_fan_speed = 0
; additional_fan_full_speed_layer = 0
; alternate_extra_wall = 0
; apply_scarf_seam_on_circles = 1
; auxiliary_fan = 0
; avoid_crossing_wall_includes_support = 0
; bed_custom_model = 
; bed_custom_texture = 
; bed_exclude_area = 
; bed_temperature_formula = by_first_filament
; before_layer_change_gcode = 
; best_object_pos = 0.5,0.5
; bottom_color_penetration_layers = 3
; bottom_shell_layers = 3
; bottom_shell_thickness = 0
; bottom_surface_density = 100%
; bottom_surface_pattern = zig-zag
; bridge_angle = 0
; bridge_flow = 1
; bridge_no_support = 0
; bridge_speed = 50
; brim_object_gap = 0
; brim_type = auto_brim
; brim_width = 0
; chamber_temperatures = 0
; change_filament_gcode = 
; circle_compensation_manual_offset = 0
; circle_compensation_speed = 200
; close_additional_fan_first_x_layers = 1
; close_fan_the_first_x_layers = 1
; complete_print_exhaust_fan_speed = 80
; cool_plate_temp = 35
; cool_plate_temp_initial_layer = 35
; cooling_filter_enabled = 0
; cooling_perimeter_transition_distance = 10
; cooling_slowdown_logic = uniform_cooling
; counter_coef_1 = 0
; counter_coef_2 = 0.025
; counter_coef_3 = -0.11
; counter_limit_max = 0.05
; counter_limit_min = -0.04
; counterbore_hole_bridging = none
; curr_bed_type = Cool Plate
; default_acceleration = 10000
; default_filament_colour = ""
; default_filament_profile = "Bambu PLA Basic @BBL P2S"
; default_jerk = 0
; default_print_profile = 0.20mm Standard @BBL P2S
; deretraction_speed = 30
; detect_floating_vertical_shell = 1
; detect_narrow_internal_solid_infill = 1
; detect_overhang_wall = 1
; detect_thin_wall = 0
; diameter_limit = 50
; different_settings_to_system = ;;
; draft_shield = disabled
; during_print_exhaust_fan_speed = 60
; elefant_foot_compensation = 0
; embedding_wall_into_infill = 0
; enable_arc_fitting = 0
; enable_circle_compensation = 0
; enable_filament_dynamic_map = 0
; enable_height_slowdown = 0
; enable_long_retraction_when_cut = 2
; enable_mixed_color_sublayer = 0
; enable_order_independent_overlap_carving = 0
; enable_overhang_bridge_fan = 1
; enable_overhang_speed = 1
; enable_pre_heating = 0
; enable_pressure_advance = 0
; enable_prime_tower = 0
; enable_support = 0
; enable_support_ironing = 0
; enable_tower_interface_features = 0
; enable_wrapping_detection = 0
; enforce_support_layers = 0
; eng_plate_temp = 55
; eng_plate_temp_initial_layer = 55
; ensure_vertical_shell_thickness = enabled
; exclude_object = 1
; extruder_ams_count = 
; extruder_clearance_dist_to_rod = 36.5
; extruder_clearance_height_to_lid = 141.5
; extruder_clearance_height_to_rod = 32.5
; extruder_clearance_max_radius = 72
; extruder_colour = ""
; extruder_max_nozzle_count = 1
; extruder_nozzle_stats = 
; extruder_offset = 0x0
; extruder_printable_area = 
; extruder_printable_height = 0
; extruder_type = Direct Drive
; extruder_variant_list = "Direct Drive Standard,Direct Drive High Flow,Direct Drive E3D High Flow"
; fan_cooling_layer_time = 60
; fan_direction = right
; fan_max_speed = 100
; fan_min_speed = 20
; farthest_point_timelapse = 1
; filament_adaptive_volumetric_speed = 0
; filament_adhesiveness_category = 0
; filament_bridge_speed = 25
; filament_change_length = 10
; filament_change_length_nc = 10
; filament_colour = #00AE42
; filament_cooling_before_tower = 10
; filament_cost = 0
; filament_density = 0
; filament_dev_ams_drying_ams_limitations = ""
; filament_dev_ams_drying_heat_distortion_temperature = 0
; filament_dev_ams_drying_temperature = 0
; filament_dev_ams_drying_time = 0
; filament_dev_chamber_drying_bed_temperature = 0
; filament_dev_chamber_drying_time = 0
; filament_dev_drying_cooling_temperature = 0
; filament_dev_drying_softening_temperature = 0
; filament_diameter = 1.75
; filament_enable_overhang_speed = 1
; filament_end_gcode = " "
; filament_extruder_compatibility = 0
; filament_extruder_variant = "Direct Drive Standard"
; filament_flow_ratio = 0.98
; filament_flush_temp = 0
; filament_flush_temp_fast = 0
; filament_flush_volumetric_speed = 0
; filament_ids = ""
; filament_is_mixed = 0
; filament_is_support = 0
; filament_map = 1
; filament_map_2 = 0
; filament_map_mode = Auto For Flush
; filament_max_volumetric_speed = 12
; filament_metal_stickiness = None
; filament_minimal_purge_on_wipe_tower = 15
; filament_mixed_components = ""
; filament_mixed_gradient = 0
; filament_mixed_gradient_curve = ""
; filament_mixed_gradient_per_part = 0
; filament_mixed_gradient_range = ""
; filament_mixed_sublayer_ratios = ""
; filament_notes = 
; filament_nozzle_map = 0
; filament_overhang_1_4_speed = 0
; filament_overhang_2_4_speed = 0
; filament_overhang_3_4_speed = 0
; filament_overhang_4_4_speed = 0
; filament_overhang_totally_speed = 10
; filament_pre_cooling_temperature = 0
; filament_pre_cooling_temperature_nc = 0
; filament_preheat_temperature_delta = 0
; filament_prime_volume = 45
; filament_prime_volume_nc = 60
; filament_printable = 3
; filament_ramming_travel_time = 0
; filament_ramming_travel_time_nc = 0
; filament_ramming_volumetric_speed = -1
; filament_ramming_volumetric_speed_nc = -1
; filament_retract_length_nc = 10
; filament_scarf_gap = 0
; filament_scarf_height = 10%
; filament_scarf_length = 10
; filament_scarf_seam_type = none
; filament_self_index = 1
; filament_settings_id = "Generic PLA @BBL P2S"
; filament_shrink = 100%
; filament_soluble = 0
; filament_start_gcode = "; filament start gcode\n"
; filament_tower_interface_pre_extrusion_dist = 10
; filament_tower_interface_pre_extrusion_length = 0
; filament_tower_interface_print_temp = -1
; filament_tower_interface_purge_volume = 20
; filament_tower_ironing_area = 4
; filament_type = PLA
; filament_velocity_adaptation_factor = 1
; filament_vendor = (Undefined)
; filament_volume_map = 0
; filename_format = [input_filename_base].gcode
; fill_multiline = 1
; filter_out_gap_fill = 0
; first_layer_print_sequence = 0
; first_x_layer_fan_speed = 40
; first_x_layer_part_fan_speed = 0
; flush_into_infill = 0
; flush_into_objects = 0
; flush_into_support = 1
; flush_multiplier = 1
; flush_multiplier_fast = 1.2
; flush_volumes_matrix = 0,280,280,280,280,0,280,280,280,280,0,280,280,280,280,0
; flush_volumes_vector = 140,140,140,140,140,140,140,140
; full_fan_speed_layer = 0
; fuzzy_skin = none
; fuzzy_skin_first_layer = 0
; fuzzy_skin_mode = displacement
; fuzzy_skin_noise_type = classic
; fuzzy_skin_octaves = 4
; fuzzy_skin_persistence = 0.5
; fuzzy_skin_point_distance = 0.8
; fuzzy_skin_scale = 1
; fuzzy_skin_thickness = 0.3
; gap_infill_speed = 250
; gcode_add_line_number = 0
; gcode_flavor = marlin
; grab_length = 0
; group_algo_with_time = 0
; has_filament_switcher = 0
; has_scarf_joint_seam = 0
; head_wrap_detect_zone = 
; hole_coef_1 = 0
; hole_coef_2 = -0.025
; hole_coef_3 = 0.28
; hole_limit_max = 0.25
; hole_limit_min = 0.08
; hot_plate_temp = 45
; hot_plate_temp_initial_layer = 45
; hotend_cooling_rate = 2
; hotend_heating_rate = 2
; impact_strength_z = 0
; independent_support_layer_height = 1
; infill_combination = 0
; infill_direction = 45
; infill_instead_top_bottom_surfaces = 0
; infill_jerk = 9
; infill_lock_depth = 1
; infill_rotate_step = 0
; infill_shift_step = 0.4
; infill_wall_overlap = 15%
; inherits_group = ;;
; initial_layer_acceleration = 500
; initial_layer_flow_ratio = 1
; initial_layer_infill_speed = 105
; initial_layer_jerk = 9
; initial_layer_line_width = 0.4
; initial_layer_print_height = 0.2
; initial_layer_speed = 50
; initial_layer_travel_acceleration = 6000
; inner_wall_acceleration = 0
; inner_wall_jerk = 9
; inner_wall_line_width = 0.4
; inner_wall_speed = 300
; interface_shells = 0
; interlocking_beam = 0
; interlocking_beam_layer_count = 2
; interlocking_beam_width = 0.8
; interlocking_boundary_avoidance = 2
; interlocking_depth = 2
; interlocking_orientation = 22.5
; internal_bridge_support_thickness = 0
; internal_solid_infill_line_width = 0.4
; internal_solid_infill_pattern = zig-zag
; internal_solid_infill_speed = 250
; ironing_direction = 45
; ironing_fan_speed = -1
; ironing_flow = 10%
; ironing_inset = 0
; ironing_pattern = zig-zag
; ironing_spacing = 0.1
; ironing_speed = 20
; ironing_type = no ironing
; is_infill_first = 0
; layer_change_gcode = 
; layer_height = 0.2
; line_width = 0.4
; locked_skeleton_infill_pattern = zigzag
; locked_skin_infill_pattern = crosszag
; long_retractions_when_cut = 0
; long_retractions_when_ec = 0
; machine_bed_mass_Y = 0
; machine_end_gcode = M104 S0 ; turn off temperature\nG28 X0  ; home X axis\nM84     ; disable motors\n
; machine_hotend_change_time = 0
; machine_load_filament_time = 26
; machine_max_acceleration_e = 5000,5000
; machine_max_acceleration_extruding = 20000,20000
; machine_max_acceleration_retracting = 5000,5000
; machine_max_acceleration_travel = 10000,10000
; machine_max_acceleration_x = 20000,20000
; machine_max_acceleration_y = 20000,20000
; machine_max_acceleration_z = 500,500
; machine_max_force_Y = 0
; machine_max_jerk_e = 2.5,2.5
; machine_max_jerk_x = 9,9
; machine_max_jerk_y = 9,9
; machine_max_jerk_z = 3,3
; machine_max_printed_mass = 0
; machine_max_speed_e = 30,30
; machine_max_speed_x = 600,600
; machine_max_speed_y = 600,600
; machine_max_speed_z = 20,20
; machine_min_extruding_rate = 0
; machine_min_travel_rate = 0
; machine_pause_gcode = 
; machine_prepare_compensation_time = 370
; machine_start_gcode = G28 ; home all axes\nG1 Z5 F5000 ; lift nozzle\n
; machine_switch_extruder_time = 5
; machine_unload_filament_time = 31
; master_extruder_id = 1
; max_bridge_length = 10
; max_layer_height = 0
; max_travel_detour_distance = 0
; min_bead_width = 85%
; min_feature_size = 25%
; min_layer_height = 0.07
; minimum_sparse_infill_area = 15
; mmu_segmented_region_interlocking_depth = 0
; mmu_segmented_region_max_width = 0
; monotonic_travel_into_wall = 45%
; no_slow_down_for_cooling_on_outwalls = 0
; nozzle_diameter = 0.4
; nozzle_flush_dataset = 0
; nozzle_height = 4.2
; nozzle_temperature = 220
; nozzle_temperature_initial_layer = 220
; nozzle_temperature_range_high = 240
; nozzle_temperature_range_low = 190
; nozzle_type = hardened_steel
; nozzle_volume = 110
; nozzle_volume_type = Standard
; only_one_wall_first_layer = 0
; ooze_prevention = 0
; other_layers_print_sequence = 0
; other_layers_print_sequence_nums = 0
; outer_wall_acceleration = 6000
; outer_wall_jerk = 9
; outer_wall_line_width = 0
; outer_wall_speed = 200
; overhang_1_4_speed = 0
; overhang_2_4_speed = 50
; overhang_3_4_speed = 30
; overhang_4_4_speed = 10
; overhang_fan_speed = 100
; overhang_fan_threshold = 95%
; overhang_threshold_participating_cooling = 95%
; overhang_totally_speed = 10
; override_filament_scarf_seam_setting = 0
; override_process_overhang_speed = 0
; physical_extruder_map = 0
; post_process = 
; pre_start_fan_time = 0
; precise_outer_wall = 0
; precise_z_height = 0
; pressure_advance = 0.02
; prime_tower_brim_width = 3
; prime_tower_enable_framework = 0
; prime_tower_extra_rib_length = 0
; prime_tower_fillet_wall = 1
; prime_tower_flat_ironing = 1
; prime_tower_infill_gap = 150%
; prime_tower_lift_height = -1
; prime_tower_lift_speed = 90
; prime_tower_max_speed = 90
; prime_tower_rib_wall = 1
; prime_tower_rib_width = 8
; prime_tower_skip_points = 1
; prime_tower_width = 35
; prime_volume_mode = Default
; print_compatible_printers = "Bambu Lab P2S 0.4 nozzle"
; print_extruder_id = 1
; print_extruder_variant = "Direct Drive Standard"
; print_flow_ratio = 1
; print_in_clockwise = 1
; print_sequence = by layer
; print_settings_id = 0.20mm Standard @BBL P2S
; printable_area = 0x0,200x0,200x200,0x200
; printable_height = 256
; printer_extruder_id = 1
; printer_extruder_variant = "Direct Drive Standard"
; printer_model = Bambu Lab P2S
; printer_notes = 
; printer_settings_id = Bambu Lab P2S 0.4 nozzle
; printer_structure = undefine
; printer_technology = FFF
; printer_variant = 0.4
; printing_by_object_gcode = 
; process_notes = 
; raft_contact_distance = 0.1
; raft_expansion = 1.5
; raft_first_layer_density = 90%
; raft_first_layer_expansion = -1
; raft_layers = 0
; reduce_crossing_wall = 0
; reduce_fan_stop_start_freq = 0
; reduce_infill_retraction_mode = Auto
; required_nozzle_HRC = 0
; resolution = 0.01
; retract_before_wipe = 0%
; retract_length_toolchange = 2
; retract_lift_above = 0
; retract_lift_below = 249
; retract_restart_extra = 0
; retract_restart_extra_toolchange = 0
; retract_when_changing_layer = 1
; retraction_distances_when_cut = 18
; retraction_distances_when_ec = 0
; retraction_length = 0.8
; retraction_minimum_travel = 1
; retraction_speed = 30
; role_base_wipe_speed = 1
; scan_first_layer = 0
; scarf_angle_threshold = 155
; seam_gap = 15%
; seam_placement_away_from_overhangs = 0
; seam_position = aligned
; seam_slope_conditional = 1
; seam_slope_entire_loop = 0
; seam_slope_gap = 0
; seam_slope_inner_walls = 1
; seam_slope_min_length = 10
; seam_slope_start_height = 10%
; seam_slope_steps = 10
; seam_slope_type = none
; silent_mode = 0
; single_extruder_multi_material = 0
; skeleton_infill_density = 15%
; skeleton_infill_line_width = 0.4
; skin_infill_density = 15%
; skin_infill_depth = 2
; skin_infill_line_width = 0.4
; skirt_distance = 2
; skirt_height = 1
; skirt_loops = 1
; skirt_per_object = 1
; slice_closing_radius = 0.049
; slicing_mode = regular
; slow_down_for_layer_cooling = 1
; slow_down_layer_time = 5
; slow_down_min_speed = 20
; slowdown_end_acc = 100000
; slowdown_end_height = 400
; slowdown_end_speed = 1000
; slowdown_start_acc = 100000
; slowdown_start_height = 0
; slowdown_start_speed = 1000
; small_perimeter_speed = 50%
; small_perimeter_threshold = 0
; smooth_coefficient = 4
; smooth_speed_discontinuity_area = 1
; solid_infill_filament = 0
; sparse_infill_acceleration = 100%
; sparse_infill_anchor = 400%
; sparse_infill_anchor_max = 20
; sparse_infill_density = 20%
; sparse_infill_filament = 0
; sparse_infill_lattice_angle_1 = -45
; sparse_infill_lattice_angle_2 = 45
; sparse_infill_line_width = 0.4
; sparse_infill_pattern = cubic
; sparse_infill_speed = 270
; spiral_mode = 0
; spiral_mode_max_xy_smoothing = 200%
; spiral_mode_smooth = 0
; standby_temperature_delta = -5
; start_end_points = 30x-3,54x245
; supertack_plate_temp = 35
; supertack_plate_temp_initial_layer = 35
; support_air_filtration = 0
; support_angle = 0
; support_base_pattern = default
; support_base_pattern_spacing = 2.5
; support_bottom_interface_spacing = 0.5
; support_bottom_z_distance = 0.2
; support_chamber_temp_control = 0
; support_cooling_filter = 0
; support_critical_regions_only = 0
; support_expansion = 0
; support_fast_purge_mode = 0
; support_filament = 0
; support_interface_bottom_layers = 0
; support_interface_filament = 0
; support_interface_loop_pattern = 0
; support_interface_not_for_body = 1
; support_interface_pattern = auto
; support_interface_spacing = 0.5
; support_interface_speed = 80
; support_interface_top_layers = 3
; support_ironing_direction = 0
; support_ironing_flow = 10%
; support_ironing_inset = 0
; support_ironing_pattern = zig-zag
; support_ironing_spacing = 0.1
; support_ironing_speed = 20
; support_line_width = 0.4
; support_object_first_layer_gap = 0.2
; support_object_skip_flush = 1
; support_object_xy_distance = 0.35
; support_on_build_plate_only = 0
; support_remove_small_overhang = 1
; support_speed = 150
; support_style = default
; support_threshold_angle = 30
; support_top_z_distance = 0.2
; support_type = normal(auto)
; symmetric_infill_y_axis = 0
; temperature_vitrification = 100
; template_custom_gcode = 
; textured_plate_temp = 45
; textured_plate_temp_initial_layer = 45
; thick_bridges = 0
; thumbnail_size = 50x50
; time_lapse_gcode = 
; timelapse_type = 0
; top_area_threshold = 200%
; top_color_penetration_layers = 4
; top_one_wall_type = all top
; top_shell_layers = 4
; top_shell_thickness = 0.6
; top_solid_infill_flow_ratio = 1
; top_surface_acceleration = 2000
; top_surface_density = 100%
; top_surface_jerk = 9
; top_surface_line_width = 0.4
; top_surface_pattern = zig-zag
; top_surface_speed = 200
; top_z_overrides_xy_distance = 0
; travel_acceleration = 10000
; travel_jerk = 9
; travel_short_distance_acceleration = 250
; travel_speed = 600
; travel_speed_z = 0
; tree_support_branch_angle = 40
; tree_support_branch_diameter = 5
; tree_support_branch_diameter_angle = 5
; tree_support_branch_distance = 5
; tree_support_wall_count = -1
; upward_compatible_machine = "Bambu Lab A1 0.4 nozzle";"Bambu Lab H2S 0.4 nozzle";"Bambu Lab H2D 0.4 nozzle";"Bambu Lab H2D Pro 0.4 nozzle";"Bambu Lab H2C 0.4 nozzle";"Bambu Lab X2D 0.4 nozzle";"Bambu Lab A2L 0.4 nozzle"
; use_firmware_retraction = 0
; use_relative_e_distances = 1
; vertical_shell_speed = 80%
; volumetric_speed_coefficients = ""
; wall_distribution_count = 1
; wall_filament = 0
; wall_generator = arachne
; wall_loops = 2
; wall_sequence = inner wall/outer wall
; wall_transition_angle = 10
; wall_transition_filter_deviation = 25%
; wall_transition_length = 100%
; wipe = 1
; wipe_distance = 2
; wipe_speed = 80%
; wipe_tower_no_sparse_layers = 0
; wipe_tower_rotation_angle = 0
; wipe_tower_x = 15
; wipe_tower_y = 220
; wrapping_detection_gcode = 
; wrapping_detection_layers = 20
; wrapping_exclude_area = 153x256,216x256,216x235,153x235
; xy_contour_compensation = 0
; xy_hole_compensation = 0
; z_direction_outwall_speed_continuous = 0
; z_hop = 0.4
; z_hop_types = Auto Lift
; CONFIG_BLOCK_END

; EXECUTABLE_BLOCK_START
M73 P0 R4
M201 X20000 Y20000 Z500 E5000
M203 X600 Y600 Z20 E30
M204 P20000 R5000 T20000
M205 X9.00 Y9.00 Z3.00 E2.50
M106 S0
M190 S35 ; set bed temperature and wait for it to be reached
M104 S220 ; set nozzle temperature
; FEATURE: Custom
G28 ; home all axes
G1 Z5 F5000 ; lift nozzle
; MACHINE_START_GCODE_END
; filament start gcode
;VT0 H-1
M109 S220 ; set nozzle temperature and wait for it to be reached
G90
G21
M83 ; use relative distances for extrusion
M981 S1 P20000 ;open spaghetti detector
; CHANGE_LAYER
; Z_HEIGHT: 0.2
; LAYER_HEIGHT: 0.2
G1 E-.8 F1800
M106 S0
G1 X89.986 Y95.303 F36000
M204 S6000
G1 Z.4
G1 Z.2
G1 E.8 F1800
; FEATURE: Skirt
; LINE_WIDTH: 0.4
G1 F3000
M204 S500
G1 X89.332 Y95.953 E.02683
G1 X88.781 Y96.694 E.02687
G1 X88.347 Y97.509 E.02687
G1 X88.038 Y98.379 E.02687
G1 X87.877 Y99.178 E.02371
G1 X87.823 Y100.1 E.02687
G1 X87.907 Y101.019 E.02686
G1 X88.127 Y101.916 E.02687
G1 X88.478 Y102.77 E.02687
G1 X88.952 Y103.562 E.02687
G1 X89.404 Y104.128 E.02107
G1 X90.058 Y104.758 E.02642
G1 X98.628 Y111.693 E.32079
G1 X99.999 Y112.179 E.0423
G1 X109.999 Y112.179 E.29097
G1 X110.754 Y112.043 E.02233
G1 X111.786 Y111.245 E.03797
G1 X112.177 Y110 E.03797
G1 X112.177 Y90 E.58195
G1 X112.042 Y89.245 E.02233
G1 X111.244 Y88.212 E.03797
G1 X109.999 Y87.821 E.03797
G1 X99.999 Y87.821 E.29097
G1 X98.628 Y88.307 E.0423
M73 P1 R4
G1 X90.033 Y95.266 E.32179
; OBJECT_ID: 8
; WIPE_START
G1 X89.332 Y95.953 E-.37311
M73 P1 R3
G1 X88.781 Y96.694 E-.35085
G1 X88.736 Y96.778 E-.03604
; WIPE_END
G1 E-.04 F1800
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
M204 S6000
G1 X95.247 Y100.76 Z.6 F36000
G1 X109.442 Y109.443 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3000
M204 S500
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S6000
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3000
M204 S500
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
M73 P2 R3
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 1 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer1 end: 8,12
M625
; WIPE_START
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X101.421 Y109.3 F36000
M204 S6000
G1 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.40003
G1 F6300
M204 S500
G1 X100.859 Y108.739 E.0231
G1 X100.859 Y108.234 E.0147
G1 X101.765 Y109.139 E.03727
G1 X102.27 Y109.139 E.0147
G1 X100.859 Y107.729 E.05806
G1 X100.859 Y107.224 E.0147
G1 X102.775 Y109.139 E.07884
G1 X103.28 Y109.139 E.0147
G1 X100.859 Y106.719 E.09963
G1 X100.859 Y106.214 E.0147
G1 X103.785 Y109.139 E.12041
G1 X104.29 Y109.139 E.0147
G1 X100.859 Y105.709 E.14119
G1 X100.859 Y105.204 E.0147
M73 P3 R3
G1 X104.795 Y109.139 E.16198
G1 X105.3 Y109.139 E.0147
G1 X100.859 Y104.699 E.18276
G1 X100.859 Y104.193 E.0147
G1 X105.805 Y109.139 E.20354
G1 X106.31 Y109.139 E.0147
G1 X100.859 Y103.688 E.22433
G1 X100.859 Y103.183 E.0147
G1 X106.815 Y109.139 E.24511
G1 X107.32 Y109.139 E.0147
G1 X100.859 Y102.678 E.2659
G1 X100.859 Y102.173 E.0147
G1 X107.825 Y109.139 E.28668
G1 X108.33 Y109.139 E.0147
G1 X100.859 Y101.668 E.30746
G1 X100.859 Y101.163 E.0147
G1 X108.835 Y109.139 E.32825
G1 X109.138 Y109.139 E.00881
M73 P4 R3
G1 X109.138 Y108.937 E.00589
G1 X100.859 Y100.658 E.34071
G1 X100.859 Y100.153 E.0147
G1 X109.138 Y108.432 E.34071
G1 X109.138 Y107.927 E.0147
G1 X100.859 Y99.648 E.34071
G1 X100.859 Y99.143 E.0147
G1 X109.138 Y107.422 E.34071
G1 X109.138 Y106.917 E.0147
G1 X100.859 Y98.638 E.34071
G1 X100.859 Y98.133 E.0147
G1 X109.138 Y106.412 E.34071
G1 X109.138 Y105.907 E.0147
G1 X100.859 Y97.628 E.34071
G1 X100.859 Y97.123 E.0147
G1 X109.138 Y105.402 E.34071
G1 X109.138 Y104.897 E.0147
M73 P5 R3
G1 X100.859 Y96.618 E.34071
G1 X100.859 Y96.113 E.0147
G1 X109.138 Y104.392 E.34071
G1 X109.138 Y103.887 E.0147
G1 X100.859 Y95.608 E.34071
G1 X100.859 Y95.103 E.0147
G1 X109.138 Y103.382 E.34071
G1 X109.138 Y102.877 E.0147
G1 X100.859 Y94.598 E.34071
G1 X100.859 Y94.093 E.0147
G1 X109.138 Y102.372 E.34071
G1 X109.138 Y101.867 E.0147
G1 X100.859 Y93.588 E.34071
G1 X100.859 Y93.083 E.0147
G1 X109.138 Y101.362 E.34071
G1 X109.138 Y100.857 E.0147
M73 P6 R3
G1 X100.859 Y92.578 E.34071
G1 X100.859 Y92.073 E.0147
G1 X109.138 Y100.352 E.34071
G1 X109.138 Y99.847 E.0147
G1 X100.859 Y91.568 E.34071
G1 X100.859 Y91.063 E.0147
G1 X109.138 Y99.342 E.34071
G1 X109.138 Y98.837 E.0147
G1 X101.162 Y90.861 E.32824
G1 X101.667 Y90.861 E.0147
G1 X109.138 Y98.332 E.30746
G1 X109.138 Y97.827 E.0147
G1 X102.172 Y90.861 E.28667
G1 X102.677 Y90.861 E.0147
G1 X109.138 Y97.321 E.26589
G1 X109.138 Y96.816 E.0147
M73 P7 R3
G1 X103.182 Y90.861 E.24511
G1 X103.687 Y90.861 E.0147
G1 X109.138 Y96.311 E.22432
G1 X109.138 Y95.806 E.0147
G1 X104.192 Y90.861 E.20354
G1 X104.697 Y90.861 E.0147
G1 X109.138 Y95.301 E.18275
G1 X109.138 Y94.796 E.0147
G1 X105.202 Y90.861 E.16197
G1 X105.707 Y90.861 E.0147
G1 X109.138 Y94.291 E.14119
G1 X109.138 Y93.786 E.0147
G1 X106.212 Y90.861 E.1204
G1 X106.718 Y90.861 E.0147
G1 X109.138 Y93.281 E.09962
G1 X109.138 Y92.776 E.0147
G1 X107.223 Y90.861 E.07884
G1 X107.728 Y90.861 E.0147
G1 X109.138 Y92.271 E.05805
G1 X109.138 Y91.766 E.0147
G1 X108.233 Y90.861 E.03727
G1 X108.738 Y90.861 E.0147
G1 X109.299 Y91.422 E.0231
; OBJECT_ID: 12
; WIPE_START
G1 X108.738 Y90.861 E-.30161
G1 X108.233 Y90.861 E-.19191
M73 P8 R3
G1 X108.728 Y91.356 E-.26648
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
M204 S6000
G1 X102.91 Y96.296 Z.6 F36000
G1 X94.554 Y103.391 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3000
M204 S500
G1 X95.177 Y103.233 E.01869
G1 X95.794 Y102.936 E.01992
G1 X96.34 Y102.522 E.01994
G1 X96.793 Y102.008 E.01994
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.134 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.158 E.01994
G1 X95.331 Y96.827 E.02012
G1 X94.855 Y96.667 E.0146
G1 X94.171 Y96.564 E.02012
G1 X93.487 Y96.598 E.01993
G1 X92.821 Y96.768 E.02
G1 X92.206 Y97.064 E.01986
G1 X91.658 Y97.48 E.02001
G1 X91.207 Y97.992 E.01986
G1 X90.864 Y98.585 E.01994
G1 X90.646 Y99.234 E.01994
G1 X90.561 Y99.914 E.01993
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01993
G1 X92.067 Y102.847 E.02013
G1 X92.501 Y103.097 E.01458
G1 X93.151 Y103.334 E.02013
G1 X93.829 Y103.436 E.01993
G1 X94.496 Y103.403 E.01943
M204 S6000
G1 X94.642 Y103.737 F36000
; FEATURE: Outer wall
G1 F3000
M204 S500
G1 X95.299 Y103.57 E.01973
G1 X95.981 Y103.242 E.022
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02202
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.022
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.474 Y96.498 E.02207
G1 X94.939 Y96.319 E.01642
G1 X94.189 Y96.206 E.02207
G1 X93.434 Y96.243 E.02201
G1 X92.698 Y96.431 E.02208
G1 X92.019 Y96.758 E.02194
G1 X91.414 Y97.217 E.02209
G1 X90.916 Y97.782 E.02194
G1 X90.537 Y98.437 E.02202
G1 X90.296 Y99.155 E.02202
G1 X90.202 Y99.905 E.02201
G1 X90.259 Y100.66 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.653 E.02201
G1 X91.862 Y103.14 E.02208
G1 X92.35 Y103.422 E.0164
G1 X93.063 Y103.682 E.02208
G1 X93.811 Y103.794 E.02201
G1 X94.566 Y103.757 E.02202
G1 X94.584 Y103.752 E.00054
; WIPE_START
G1 X95.299 Y103.57 E-.28044
G1 X95.981 Y103.242 E-.28736
G1 X96.384 Y102.936 E-.1922
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X92.512 Y102.938 Z.6 F36000
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.41118
G1 F6300
M204 S500
G1 X91.729 Y102.156 E.0332
G1 X91.366 Y101.701 E.01746
G1 X91.082 Y101.146 E.01873
G1 X91.02 Y100.926 E.00686
G1 X93.078 Y102.984 E.08737
G1 X93.227 Y103.038 E.00473
G1 X93.729 Y103.114 E.01524
G1 X90.892 Y100.278 E.12037
G1 X90.866 Y99.922 E.0107
G1 X90.887 Y99.752 E.00515
G1 X94.247 Y103.111 E.14258
G1 X94.467 Y103.1 E.00663
G1 X94.698 Y103.041 E.00714
G1 X90.947 Y99.291 E.15917
G1 X91.078 Y98.901 E.01234
M73 P9 R3
G1 X95.107 Y102.93 E.17096
G1 X95.458 Y102.76 E.01171
G1 X91.24 Y98.542 E.17903
G1 X91.43 Y98.212 E.01144
G1 X95.782 Y102.564 E.18469
G1 X96.079 Y102.339 E.01116
G1 X91.668 Y97.928 E.1872
G1 X91.866 Y97.703 E.009
G1 X91.922 Y97.661 E.00209
G1 X96.332 Y102.072 E.18719
G1 X96.57 Y101.788 E.01109
G1 X92.218 Y97.437 E.18469
G1 X92.366 Y97.325 E.00556
G1 X92.542 Y97.24 E.00587
G1 X96.76 Y101.458 E.17903
G1 X96.858 Y101.289 E.00585
G1 X96.922 Y101.099 E.00603
G1 X92.893 Y97.07 E.17097
G1 X93.302 Y96.959 E.01273
G1 X97.053 Y100.709 E.15917
G1 X97.113 Y100.248 E.01394
G1 X93.753 Y96.889 E.14258
G1 X94.156 Y96.869 E.01211
G1 X94.271 Y96.886 E.00349
G1 X97.108 Y99.722 E.12037
G1 X97.088 Y99.456 E.00802
M73 P10 R3
G1 X96.98 Y99.074 E.01189
G1 X94.912 Y97.007 E.08776
G1 X95.209 Y97.106 E.00939
G1 X95.766 Y97.409 E.01903
G1 X96.203 Y97.776 E.0171
G1 X96.907 Y98.481 E.02991
; CHANGE_LAYER
; Z_HEIGHT: 0.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F6300
G1 X96.203 Y97.776 E-.37873
G1 X95.766 Y97.409 E-.21657
G1 X95.385 Y97.202 E-.1647
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
M106 S252.45
; open powerlost recovery
M1003 S1
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
M204 S10000
G17
G3 Z.6 I-.799 J.918 P1  F36000
G1 X109.442 Y109.443 Z.6
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F8905
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F8905
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 2 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer2 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X108.577 Y109.3 F36000
G1 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40003
G1 F8905
G1 X109.138 Y108.739 E.0231
G1 X109.138 Y108.234 E.0147
G1 X108.233 Y109.139 E.03727
G1 X107.728 Y109.139 E.0147
G1 X109.138 Y107.729 E.05805
G1 X109.138 Y107.224 E.0147
G1 X107.223 Y109.139 E.07884
G1 X106.718 Y109.139 E.0147
G1 X109.138 Y106.719 E.09962
G1 X109.138 Y106.214 E.0147
G1 X106.212 Y109.139 E.1204
G1 X105.707 Y109.139 E.0147
G1 X109.138 Y105.709 E.14119
G1 X109.138 Y105.204 E.0147
G1 X105.202 Y109.139 E.16197
G1 X104.697 Y109.139 E.0147
G1 X109.138 Y104.699 E.18275
G1 X109.138 Y104.194 E.0147
G1 X104.192 Y109.139 E.20354
G1 X103.687 Y109.139 E.0147
G1 X109.138 Y103.689 E.22432
G1 X109.138 Y103.184 E.0147
G1 X103.182 Y109.139 E.24511
G1 X102.677 Y109.139 E.0147
M73 P11 R3
G1 X109.138 Y102.679 E.26589
G1 X109.138 Y102.174 E.0147
G1 X102.172 Y109.139 E.28667
G1 X101.667 Y109.139 E.0147
G1 X109.138 Y101.668 E.30746
G1 X109.138 Y101.163 E.0147
G1 X101.162 Y109.139 E.32824
G1 X100.859 Y109.139 E.00881
G1 X100.859 Y108.937 E.00588
G1 X109.138 Y100.658 E.34071
G1 X109.138 Y100.153 E.0147
G1 X100.859 Y108.432 E.34071
G1 X100.859 Y107.927 E.0147
G1 X109.138 Y99.648 E.34071
G1 X109.138 Y99.143 E.0147
G1 X100.859 Y107.422 E.34071
G1 X100.859 Y106.917 E.0147
G1 X109.138 Y98.638 E.34071
G1 X109.138 Y98.133 E.0147
G1 X100.859 Y106.412 E.34071
G1 X100.859 Y105.907 E.0147
G1 X109.138 Y97.628 E.34071
G1 X109.138 Y97.123 E.0147
G1 X100.859 Y105.402 E.34071
G1 X100.859 Y104.897 E.0147
G1 X109.138 Y96.618 E.34071
G1 X109.138 Y96.113 E.0147
G1 X100.859 Y104.392 E.34071
G1 X100.859 Y103.887 E.0147
G1 X109.138 Y95.608 E.3407
G1 X109.138 Y95.103 E.0147
G1 X100.859 Y103.382 E.3407
G1 X100.859 Y102.877 E.0147
G1 X109.138 Y94.598 E.3407
G1 X109.138 Y94.093 E.0147
G1 X100.859 Y102.372 E.3407
G1 X100.859 Y101.867 E.0147
G1 X109.138 Y93.588 E.3407
G1 X109.138 Y93.083 E.0147
G1 X100.859 Y101.362 E.3407
G1 X100.859 Y100.857 E.0147
G1 X109.138 Y92.578 E.3407
G1 X109.138 Y92.073 E.0147
G1 X100.859 Y100.352 E.3407
G1 X100.859 Y99.847 E.0147
G1 X109.138 Y91.568 E.34071
G1 X109.138 Y91.063 E.0147
G1 X100.859 Y99.342 E.34071
G1 X100.859 Y98.837 E.0147
M73 P12 R3
G1 X108.835 Y90.861 E.32825
G1 X108.33 Y90.861 E.0147
G1 X100.859 Y98.332 E.30746
G1 X100.859 Y97.827 E.0147
G1 X107.825 Y90.861 E.28668
G1 X107.32 Y90.861 E.0147
G1 X100.859 Y97.322 E.2659
G1 X100.859 Y96.817 E.0147
G1 X106.815 Y90.861 E.24511
G1 X106.31 Y90.861 E.0147
G1 X100.859 Y96.312 E.22433
G1 X100.859 Y95.807 E.0147
G1 X105.805 Y90.861 E.20354
G1 X105.3 Y90.861 E.0147
G1 X100.859 Y95.302 E.18276
G1 X100.859 Y94.796 E.0147
G1 X104.795 Y90.861 E.16198
G1 X104.29 Y90.861 E.0147
G1 X100.859 Y94.291 E.14119
G1 X100.859 Y93.786 E.0147
G1 X103.785 Y90.861 E.12041
G1 X103.28 Y90.861 E.0147
G1 X100.859 Y93.281 E.09963
G1 X100.859 Y92.776 E.0147
G1 X102.775 Y90.861 E.07884
G1 X102.27 Y90.861 E.0147
G1 X100.859 Y92.271 E.05806
G1 X100.859 Y91.766 E.0147
G1 X101.765 Y90.861 E.03727
G1 X101.26 Y90.861 E.0147
G1 X100.699 Y91.422 E.0231
; OBJECT_ID: 12
; WIPE_START
G1 F10080.927
G1 X101.26 Y90.861 E-.30169
G1 X101.765 Y90.861 E-.19191
G1 X101.269 Y91.356 E-.2664
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X97.547 Y98.019 Z.8 F36000
G1 X94.544 Y103.394 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F8905
G1 X95.177 Y103.233 E.01899
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
G1 X96.793 Y102.008 E.01993
G1 X97.138 Y101.409 E.02014
G1 X97.354 Y100.766 E.01972
G1 X97.439 Y100.086 E.01995
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00996
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01994
G1 X95.331 Y96.827 E.02011
G1 X94.855 Y96.667 E.0146
G1 X94.171 Y96.564 E.02012
G1 X93.487 Y96.598 E.01993
G1 X92.823 Y96.767 E.01993
G1 X92.206 Y97.065 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01993
G1 X92.067 Y102.847 E.02013
G1 X92.501 Y103.097 E.01458
G1 X93.151 Y103.334 E.02013
G1 X93.829 Y103.436 E.01993
G1 X94.485 Y103.403 E.01913
M204 S250
G1 X94.632 Y103.74 F36000
; FEATURE: Outer wall
G1 F8905
M204 S6000
G1 X95.299 Y103.57 E.02003
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.466 Y101.556 E.02222
G1 X97.704 Y100.846 E.0218
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.011
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.474 Y96.498 E.02206
G1 X94.939 Y96.319 E.01642
G1 X94.189 Y96.206 E.02207
G1 X93.434 Y96.243 E.02201
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.66 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.653 E.022
G1 X91.862 Y103.14 E.02208
G1 X92.35 Y103.422 E.0164
G1 X93.063 Y103.682 E.02208
G1 X93.811 Y103.794 E.02201
G1 X94.566 Y103.757 E.02201
G1 X94.574 Y103.755 E.00024
; WIPE_START
G1 F10082.057
M204 S10000
G1 X95.299 Y103.57 E-.28438
G1 X95.981 Y103.242 E-.28739
G1 X96.376 Y102.943 E-.18823
; WIPE_END
G1 E-.04 F1800
G1 X95.511 Y102.913 Z.8 F36000
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41095
G1 F8905
G1 X96.183 Y102.241 E.02852
G1 X96.545 Y101.83 E.01642
G1 X96.86 Y101.283 E.01893
G1 X96.981 Y100.922 E.01143
G1 X94.918 Y102.985 E.08751
G1 X94.467 Y103.1 E.01395
G1 X94.273 Y103.11 E.00583
G1 X97.11 Y100.273 E.12031
G1 X97.134 Y100.078 E.0059
G1 X97.11 Y99.753 E.00978
G1 X93.746 Y103.117 E.14267
G1 X93.294 Y103.048 E.01372
G1 X97.043 Y99.299 E.15903
G1 X96.929 Y98.893 E.01265
M73 P13 R3
G1 X92.902 Y102.92 E.17082
G1 X92.63 Y102.821 E.00867
G1 X92.535 Y102.766 E.00329
G1 X96.759 Y98.543 E.17913
G1 X96.634 Y98.299 E.00821
G1 X96.566 Y98.214 E.00324
G1 X92.21 Y102.571 E.18475
G1 X91.927 Y102.333 E.01108
G1 X96.335 Y97.925 E.18696
G1 X96.245 Y97.811 E.00437
G1 X96.073 Y97.667 E.00672
G1 X91.665 Y102.075 E.18696
G1 X91.434 Y101.786 E.01111
G1 X95.79 Y97.429 E.18475
G1 X95.457 Y97.241 E.01145
G1 X91.241 Y101.457 E.17881
G1 X91.071 Y101.107 E.01167
G1 X95.107 Y97.072 E.17116
G1 X94.784 Y96.963 E.01022
G1 X94.706 Y96.952 E.00234
G1 X90.957 Y100.701 E.15903
G1 X90.912 Y100.544 E.00489
G1 X90.89 Y100.247 E.00893
G1 X94.254 Y96.883 E.14267
G1 X94.156 Y96.869 E.00297
G1 X93.727 Y96.89 E.01289
G1 X90.89 Y99.727 E.1203
G1 X90.943 Y99.302 E.01283
G1 X91.019 Y99.078 E.00711
G1 X93.082 Y97.015 E.08749
G1 X92.928 Y97.054 E.00477
G1 X92.365 Y97.325 E.01872
G1 X91.895 Y97.681 E.01768
G1 X91.081 Y98.495 E.03451
; CHANGE_LAYER
; Z_HEIGHT: 0.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F9781.81
G1 X91.895 Y97.681 E-.4373
G1 X92.365 Y97.325 E-.22407
G1 X92.599 Y97.212 E-.09863
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z.8 I-.715 J.985 P1  F36000
G1 X109.442 Y109.443 Z.8
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F8943
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F8943
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 3 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer3 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X101.421 Y109.3 F36000
G1 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40003
G1 F8943
G1 X100.859 Y108.739 E.0231
G1 X100.859 Y108.234 E.0147
G1 X101.765 Y109.139 E.03727
G1 X102.27 Y109.139 E.0147
G1 X100.859 Y107.729 E.05806
G1 X100.859 Y107.224 E.0147
G1 X102.775 Y109.139 E.07884
G1 X103.28 Y109.139 E.0147
G1 X100.859 Y106.719 E.09963
G1 X100.859 Y106.214 E.0147
G1 X103.785 Y109.139 E.12041
G1 X104.29 Y109.139 E.0147
M73 P14 R3
G1 X100.859 Y105.709 E.14119
G1 X100.859 Y105.204 E.0147
G1 X104.795 Y109.139 E.16198
G1 X105.3 Y109.139 E.0147
G1 X100.859 Y104.699 E.18276
G1 X100.859 Y104.193 E.0147
G1 X105.805 Y109.139 E.20354
G1 X106.31 Y109.139 E.0147
G1 X100.859 Y103.688 E.22433
G1 X100.859 Y103.183 E.0147
G1 X106.815 Y109.139 E.24511
G1 X107.32 Y109.139 E.0147
G1 X100.859 Y102.678 E.2659
G1 X100.859 Y102.173 E.0147
G1 X107.825 Y109.139 E.28668
G1 X108.33 Y109.139 E.0147
G1 X100.859 Y101.668 E.30746
G1 X100.859 Y101.163 E.0147
G1 X108.835 Y109.139 E.32825
G1 X109.138 Y109.139 E.00881
G1 X109.138 Y108.937 E.00589
G1 X100.859 Y100.658 E.34071
G1 X100.859 Y100.153 E.0147
G1 X109.138 Y108.432 E.34071
G1 X109.138 Y107.927 E.0147
G1 X100.859 Y99.648 E.34071
G1 X100.859 Y99.143 E.0147
G1 X109.138 Y107.422 E.34071
G1 X109.138 Y106.917 E.0147
G1 X100.859 Y98.638 E.34071
G1 X100.859 Y98.133 E.0147
G1 X109.138 Y106.412 E.34071
G1 X109.138 Y105.907 E.0147
G1 X100.859 Y97.628 E.34071
G1 X100.859 Y97.123 E.0147
G1 X109.138 Y105.402 E.34071
G1 X109.138 Y104.897 E.0147
G1 X100.859 Y96.618 E.34071
G1 X100.859 Y96.113 E.0147
G1 X109.138 Y104.392 E.34071
G1 X109.138 Y103.887 E.0147
G1 X100.859 Y95.608 E.34071
G1 X100.859 Y95.103 E.0147
G1 X109.138 Y103.382 E.34071
G1 X109.138 Y102.877 E.0147
G1 X100.859 Y94.598 E.34071
G1 X100.859 Y94.093 E.0147
G1 X109.138 Y102.372 E.34071
G1 X109.138 Y101.867 E.0147
G1 X100.859 Y93.588 E.34071
G1 X100.859 Y93.083 E.0147
G1 X109.138 Y101.362 E.34071
G1 X109.138 Y100.857 E.0147
M73 P15 R3
G1 X100.859 Y92.578 E.34071
G1 X100.859 Y92.073 E.0147
G1 X109.138 Y100.352 E.34071
G1 X109.138 Y99.847 E.0147
G1 X100.859 Y91.568 E.34071
G1 X100.859 Y91.063 E.0147
G1 X109.138 Y99.342 E.34071
G1 X109.138 Y98.837 E.0147
G1 X101.162 Y90.861 E.32824
G1 X101.667 Y90.861 E.0147
G1 X109.138 Y98.332 E.30746
G1 X109.138 Y97.827 E.0147
G1 X102.172 Y90.861 E.28667
G1 X102.677 Y90.861 E.0147
G1 X109.138 Y97.321 E.26589
G1 X109.138 Y96.816 E.0147
G1 X103.182 Y90.861 E.24511
G1 X103.687 Y90.861 E.0147
G1 X109.138 Y96.311 E.22432
G1 X109.138 Y95.806 E.0147
G1 X104.192 Y90.861 E.20354
G1 X104.697 Y90.861 E.0147
G1 X109.138 Y95.301 E.18275
G1 X109.138 Y94.796 E.0147
G1 X105.202 Y90.861 E.16197
G1 X105.707 Y90.861 E.0147
G1 X109.138 Y94.291 E.14119
G1 X109.138 Y93.786 E.0147
G1 X106.212 Y90.861 E.1204
G1 X106.718 Y90.861 E.0147
G1 X109.138 Y93.281 E.09962
G1 X109.138 Y92.776 E.0147
G1 X107.223 Y90.861 E.07884
G1 X107.728 Y90.861 E.0147
G1 X109.138 Y92.271 E.05805
G1 X109.138 Y91.766 E.0147
G1 X108.233 Y90.861 E.03727
G1 X108.738 Y90.861 E.0147
G1 X109.299 Y91.422 E.0231
; OBJECT_ID: 12
; WIPE_START
G1 F10080.927
G1 X108.738 Y90.861 E-.30161
G1 X108.233 Y90.861 E-.19191
G1 X108.728 Y91.356 E-.26648
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X102.908 Y96.293 Z1 F36000
G1 X94.534 Y103.397 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F8943
G1 X95.177 Y103.233 E.01931
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
G1 X96.793 Y102.009 E.01992
G1 X97.14 Y101.404 E.02029
G1 X97.354 Y100.766 E.01958
G1 X97.439 Y100.086 E.01995
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00996
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.158 E.01994
G1 X95.331 Y96.827 E.02012
G1 X94.855 Y96.667 E.0146
G1 X94.171 Y96.564 E.02012
G1 X93.487 Y96.598 E.01994
G1 X92.823 Y96.767 E.01993
G1 X92.206 Y97.065 E.01994
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.866 E.01992
G1 X91.537 Y102.402 E.01993
G1 X92.062 Y102.842 E.01994
G1 X92.664 Y103.17 E.01993
G1 X93.324 Y103.374 E.02012
G1 X93.822 Y103.436 E.01459
G1 X94.474 Y103.404 E.019
M204 S250
G1 X94.622 Y103.743 F36000
; FEATURE: Outer wall
G1 F8943
M204 S6000
G1 X95.299 Y103.57 E.02035
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.468 Y101.551 E.02237
G1 X97.704 Y100.846 E.02165
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.011
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.348 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.474 Y96.498 E.02207
G1 X94.939 Y96.319 E.01642
G1 X94.189 Y96.206 E.02207
G1 X93.434 Y96.243 E.02201
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02202
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.154 E.022
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.66 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.022
G1 X91.28 Y102.652 E.02201
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.249 Y103.724 E.02207
G1 X93.809 Y103.794 E.01641
G1 X94.563 Y103.757 E.02199
; WIPE_START
M73 P16 R3
G1 F10082.057
M204 S10000
G1 X95.299 Y103.57 E-.28852
G1 X95.981 Y103.242 E-.28746
G1 X96.367 Y102.949 E-.18402
; WIPE_END
G1 E-.04 F1800
G1 X92.481 Y102.908 Z1 F36000
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41118
G1 F8943
G1 X91.729 Y102.156 E.03193
G1 X91.366 Y101.701 E.01746
G1 X91.082 Y101.146 E.01872
G1 X91.02 Y100.926 E.00686
G1 X93.073 Y102.979 E.08712
G1 X93.389 Y103.076 E.00992
G1 X93.734 Y103.119 E.01045
G1 X90.892 Y100.278 E.1206
G1 X90.866 Y99.922 E.0107
G1 X90.887 Y99.752 E.00515
G1 X94.247 Y103.111 E.14258
G1 X94.467 Y103.1 E.00663
G1 X94.698 Y103.041 E.00714
G1 X90.947 Y99.291 E.15917
G1 X91.078 Y98.901 E.01234
G1 X95.107 Y102.93 E.17096
G1 X95.458 Y102.76 E.01171
G1 X91.24 Y98.542 E.17903
G1 X91.43 Y98.212 E.01144
G1 X95.782 Y102.564 E.18469
G1 X96.079 Y102.339 E.01116
G1 X91.668 Y97.928 E.18719
G1 X91.868 Y97.702 E.00906
G1 X91.921 Y97.661 E.00203
G1 X96.332 Y102.072 E.18719
G1 X96.569 Y101.788 E.01109
G1 X92.218 Y97.436 E.18468
G1 X92.365 Y97.325 E.00555
G1 X92.542 Y97.24 E.00588
G1 X96.76 Y101.458 E.179
G1 X96.862 Y101.279 E.00618
G1 X96.922 Y101.099 E.00569
G1 X92.893 Y97.07 E.17098
G1 X93.302 Y96.959 E.01272
G1 X97.053 Y100.709 E.15918
G1 X97.113 Y100.248 E.01394
G1 X93.753 Y96.889 E.14258
G1 X94.156 Y96.869 E.01211
G1 X94.271 Y96.886 E.00349
G1 X97.108 Y99.722 E.12037
G1 X97.088 Y99.456 E.00802
G1 X96.98 Y99.074 E.01189
G1 X94.912 Y97.006 E.08776
G1 X95.209 Y97.106 E.00939
G1 X95.766 Y97.41 E.01904
G1 X96.203 Y97.776 E.0171
G1 X96.907 Y98.481 E.0299
; CHANGE_LAYER
; Z_HEIGHT: 0.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F9775.702
G1 X96.203 Y97.776 E-.37868
G1 X95.766 Y97.41 E-.21655
G1 X95.385 Y97.202 E-.16477
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z1 I-.799 J.918 P1  F36000
G1 X109.442 Y109.443 Z1
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3550
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3550
M204 S6000
M73 P17 R3
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 4 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer4 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X109.138 Y106.45 F36000
G1 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3550
G1 X109.138 Y105.022 E.04156
G1 X100.859 Y107.24 E.24939
G1 X100.859 Y109.139 E.05527
G1 X101.964 Y109.139 E.03215
G1 X106.862 Y90.861 E.55063
G1 X104.234 Y90.861 E.07647
G1 X109.138 Y95.765 E.2018
G1 X109.138 Y93.931 E.05334
G1 X100.859 Y96.15 E.24939
G1 X100.859 Y95.061 E.03169
G1 X109.138 Y103.339 E.34068
G1 X109.138 Y103.061 E.00812
G1 X107.509 Y109.139 E.18312
G1 X107.363 Y109.139 E.00425
M73 P18 R3
G1 X100.859 Y102.635 E.26764
G1 X100.859 Y101.695 E.02737
G1 X109.138 Y99.476 E.24939
G1 X109.138 Y98.048 E.04156
G1 X100.859 Y93.997 F36000
G1 F3550
G1 X100.859 Y92.568 E.04156
G1 X101.317 Y90.861 E.05144
G1 X102.745 Y90.861 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X101.317 Y90.861 E-.54276
G1 X101.169 Y91.413 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X97.468 Y98.088 Z1.2 F36000
G1 X94.522 Y103.399 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3550
G1 X95.177 Y103.233 E.01964
G1 X95.794 Y102.935 E.01994
G1 X96.34 Y102.522 E.01993
G1 X96.793 Y102.008 E.01994
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01994
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.158 E.01994
G1 X95.331 Y96.827 E.02012
G1 X94.855 Y96.667 E.0146
G1 X94.171 Y96.564 E.02012
G1 X93.487 Y96.598 E.01993
G1 X92.823 Y96.767 E.01993
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01994
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01992
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01993
G1 X92.067 Y102.847 E.02012
G1 X92.501 Y103.097 E.01459
G1 X93.151 Y103.334 E.02012
G1 X93.829 Y103.436 E.01994
G1 X94.463 Y103.404 E.01847
M204 S250
G1 X94.611 Y103.745 F36000
; FEATURE: Outer wall
G1 F3550
M204 S6000
G1 X95.299 Y103.57 E.02068
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02201
G1 X97.085 Y102.218 E.02202
G1 X97.463 Y101.563 E.022
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.474 Y96.498 E.02207
G1 X94.939 Y96.319 E.01642
G1 X94.189 Y96.206 E.02207
G1 X93.434 Y96.243 E.02201
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.022
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.022
G1 X91.28 Y102.653 E.02201
G1 X91.861 Y103.14 E.02207
G1 X92.35 Y103.422 E.01641
G1 X93.063 Y103.682 E.02207
G1 X93.811 Y103.794 E.02201
G1 X94.552 Y103.757 E.02159
M204 S10000
G1 X94.04 Y103.121 F36000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3550
G1 X93.844 Y103.131 E.00573
G1 X93.226 Y103.038 E.01817
G1 X92.656 Y102.831 E.01767
G1 X94.25 Y96.883 E.17917
G1 X94.156 Y96.869 E.00275
G1 X93.533 Y96.9 E.01817
G1 X92.928 Y97.054 E.01817
G1 X92.365 Y97.325 E.01816
G1 X92.228 Y97.428 E.005
G1 X96.577 Y101.777 E.17893
G1 X96.858 Y101.29 E.01636
G1 X97.057 Y100.698 E.01817
G1 X97.134 Y100.078 E.01817
G1 X97.11 Y99.752 E.0095
G1 X91.182 Y101.341 E.17858
G1 X91.082 Y101.146 E.00638
G1 X90.912 Y100.544 E.01819
G1 X90.869 Y99.962 E.017
; CHANGE_LAYER
; Z_HEIGHT: 1
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X90.912 Y100.544 E-.22198
G1 X91.082 Y101.146 E-.2375
G1 X91.182 Y101.341 E-.08328
G1 X91.734 Y101.193 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z1.2 I-.514 J1.103 P1  F36000
G1 X109.442 Y109.443 Z1.2
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3599
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
M73 P19 R3
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3599
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 5 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer5 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X109.138 Y106.596 F36000
G1 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3599
G1 X109.138 Y105.168 E.04156
G1 X100.859 Y107.386 E.24939
G1 X100.859 Y109.139 E.05101
G1 X101.818 Y109.139 E.02789
G1 X106.716 Y90.861 E.55063
G1 X104.434 Y90.861 E.06639
M73 P20 R3
G1 X109.138 Y95.565 E.19357
G1 X109.138 Y94.078 E.04327
G1 X100.859 Y96.296 E.24939
G1 X100.859 Y94.861 E.04177
G1 X109.138 Y103.139 E.34068
G1 X109.138 Y101.086 F36000
G1 F3599
G1 X109.138 Y102.514 E.04156
G1 X107.363 Y109.139 E.19958
G1 X107.563 Y109.139 E.00583
G1 X100.859 Y102.435 E.27587
G1 X100.859 Y101.841 E.01729
G1 X109.138 Y99.623 E.24939
G1 X109.138 Y98.195 E.04156
G1 X100.859 Y93.45 F36000
G1 F3599
G1 X100.859 Y92.022 E.04156
G1 X101.17 Y90.861 E.03498
G1 X102.599 Y90.861 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X101.17 Y90.861 E-.54276
G1 X101.023 Y91.413 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X97.381 Y98.12 Z1.4 F36000
G1 X94.513 Y103.402 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3599
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01993
G1 X96.793 Y102.008 E.01994
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01994
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.158 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.676 Y96.626 E.02012
G1 X94.178 Y96.564 E.0146
G1 X93.487 Y96.598 E.02013
G1 X92.823 Y96.767 E.01993
G1 X92.206 Y97.065 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01993
G1 X92.062 Y102.843 E.01994
G1 X92.664 Y103.17 E.01993
G1 X93.324 Y103.374 E.02012
G1 X93.822 Y103.436 E.0146
G1 X94.453 Y103.405 E.01838
M204 S250
G1 X94.599 Y103.748 F36000
; FEATURE: Outer wall
G1 F3599
M204 S6000
G1 X95.299 Y103.57 E.02103
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02201
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02202
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02207
G1 X94.191 Y96.206 E.01641
G1 X93.434 Y96.243 E.02207
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.66 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.653 E.02201
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.249 Y103.724 E.02207
G1 X93.809 Y103.794 E.01641
G1 X94.54 Y103.758 E.02131
; WIPE_START
G1 F10082.057
M204 S10000
G1 X95.299 Y103.57 E-.29722
G1 X95.981 Y103.242 E-.28748
M73 P21 R3
G1 X96.349 Y102.963 E-.1753
; WIPE_END
G1 E-.04 F1800
G1 X91.35 Y98.35 Z1.4 F36000
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3599
G1 X91.454 Y98.17 E.00607
G1 X91.868 Y97.702 E.01817
G1 X92.342 Y97.342 E.01733
G1 X96.65 Y101.65 E.17726
G1 X96.858 Y101.289 E.01211
G1 X97.057 Y100.698 E.01816
G1 X97.134 Y100.078 E.01817
G1 X97.121 Y99.896 E.00532
G1 X91.248 Y101.47 E.17692
G1 X91.366 Y101.701 E.00757
G1 X91.756 Y102.189 E.01816
G1 X92.234 Y102.59 E.01817
G1 X92.531 Y102.752 E.00983
G1 X94.106 Y96.871 E.17715
G1 X94.612 Y96.924 E.01478
G1 X95.218 Y97.111 E.01847
G1 X95.468 Y97.247 E.00829
; CHANGE_LAYER
; Z_HEIGHT: 1.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X95.218 Y97.111 E-.10829
G1 X94.612 Y96.924 E-.24115
G1 X94.106 Y96.871 E-.19301
G1 X93.958 Y97.424 E-.21755
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z1.4 I-.746 J.961 P1  F36000
G1 X109.442 Y109.443 Z1.4
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3576
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3576
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 6 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer6 end: 8,12
M625
; WIPE_START
M73 P22 R3
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X109.138 Y106.743 F36000
G1 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3576
G1 X109.138 Y105.314 E.04156
G1 X100.859 Y107.533 E.24939
G1 X100.859 Y109.139 E.04675
G1 X101.671 Y109.139 E.02363
G1 X106.569 Y90.861 E.55063
G1 X104.634 Y90.861 E.05631
G1 X109.138 Y95.365 E.18534
G1 X109.138 Y94.224 E.03319
G1 X100.859 Y96.442 E.24939
G1 X100.859 Y94.661 E.05185
G1 X109.138 Y102.939 E.34068
G1 X109.138 Y100.539 F36000
G1 F3576
G1 X109.138 Y101.968 E.04156
G1 X107.217 Y109.139 E.21604
G1 X107.763 Y109.139 E.01591
G1 X100.859 Y102.235 E.2841
G1 X100.859 Y101.988 E.00721
G1 X109.138 Y99.769 E.24939
G1 X109.138 Y98.341 E.04156
G1 X100.859 Y92.904 F36000
G1 F3576
G1 X100.859 Y91.475 E.04156
G1 X101.024 Y90.861 E.01852
G1 X102.452 Y90.861 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X101.024 Y90.861 E-.54276
G1 X100.876 Y91.413 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X97.297 Y98.154 Z1.6 F36000
G1 X94.512 Y103.402 Z1.6
M73 P23 R3
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3576
G1 X95.201 Y103.223 E.0207
G1 X95.793 Y102.936 E.01917
G1 X96.34 Y102.522 E.01996
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.158 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.676 Y96.626 E.02012
G1 X94.178 Y96.564 E.01459
G1 X93.487 Y96.598 E.02012
G1 X92.823 Y96.767 E.01994
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01992
G1 X92.067 Y102.847 E.02013
G1 X92.501 Y103.097 E.01459
G1 X93.151 Y103.334 E.02013
G1 X93.829 Y103.436 E.01993
G1 X94.452 Y103.405 E.01815
M204 S250
G1 X94.587 Y103.751 F36000
; FEATURE: Outer wall
G1 F3576
M204 S6000
G1 X95.324 Y103.56 E.02216
G1 X95.981 Y103.242 E.02123
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02207
G1 X94.191 Y96.206 E.01641
G1 X93.434 Y96.243 E.02207
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.154 E.022
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.66 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.652 E.022
G1 X91.861 Y103.14 E.02208
G1 X92.35 Y103.422 E.01641
G1 X93.063 Y103.682 E.02208
G1 X93.811 Y103.794 E.02201
G1 X94.528 Y103.759 E.02089
; WIPE_START
G1 F10082.057
M204 S10000
G1 X95.324 Y103.56 E-.31195
G1 X95.981 Y103.242 E-.2772
G1 X96.339 Y102.97 E-.17085
; WIPE_END
G1 E-.04 F1800
G1 X93.75 Y103.117 Z1.6 F36000
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3576
G1 X93.227 Y103.038 E.01539
G1 X92.63 Y102.821 E.01847
G1 X92.401 Y102.689 E.0077
G1 X93.958 Y96.879 E.17503
G1 X93.533 Y96.9 E.01239
G1 X92.928 Y97.054 E.01817
G1 X92.473 Y97.273 E.01468
G1 X96.723 Y101.523 E.17489
G1 X96.858 Y101.289 E.00785
G1 X97.057 Y100.698 E.01816
G1 X97.131 Y100.039 E.01928
G1 X91.314 Y101.598 E.17525
G1 X91.082 Y101.146 E.0148
G1 X90.912 Y100.544 E.01818
G1 X90.89 Y100.25 E.00858
; CHANGE_LAYER
; Z_HEIGHT: 1.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X90.912 Y100.544 E-.1121
G1 X91.082 Y101.146 E-.23738
G1 X91.314 Y101.598 E-.19328
G1 X91.866 Y101.45 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z1.6 I-.504 J1.108 P1  F36000
G1 X109.442 Y109.443 Z1.6
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3583
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
M73 P24 R3
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3583
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 7 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer7 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X109.138 Y106.889 F36000
G1 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3583
G1 X109.138 Y105.461 E.04156
G1 X100.859 Y107.679 E.24939
G1 X100.859 Y109.139 E.04249
G1 X101.525 Y109.139 E.01937
G1 X106.423 Y90.861 E.55063
G1 X104.834 Y90.861 E.04623
G1 X109.138 Y95.165 E.17711
G1 X109.138 Y94.371 E.02311
G1 X100.859 Y96.589 E.24939
G1 X100.859 Y94.461 E.06193
G1 X109.138 Y102.739 E.34068
M73 P25 R3
G1 X109.138 Y104.168 E.04156
G1 X109.138 Y100.094 F36000
G1 F3583
G1 X109.138 Y101.421 E.03861
G1 X107.07 Y109.139 E.2325
G1 X107.963 Y109.139 E.02599
G1 X100.859 Y102.035 E.29233
G1 X100.859 Y102.134 E.00287
G1 X109.138 Y99.916 E.24939
G1 X109.138 Y98.487 E.04156
G1 X102.971 Y90.861 F36000
G1 F3583
G1 X101.543 Y90.861 E.04156
G1 X100.859 Y91.044 E.0206
G1 X100.859 Y92.472 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X100.859 Y91.044 E-.54276
G1 X101.412 Y90.896 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X97.725 Y97.579 Z1.8 F36000
G1 X94.513 Y103.402 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3583
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01993
G1 X96.793 Y102.008 E.01994
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.158 E.01994
G1 X95.331 Y96.827 E.02011
G1 X94.855 Y96.667 E.0146
G1 X94.171 Y96.564 E.02012
G1 X93.487 Y96.598 E.01994
G1 X92.823 Y96.767 E.01993
G1 X92.206 Y97.065 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01992
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01993
G1 X92.067 Y102.847 E.02013
G1 X92.501 Y103.097 E.01459
G1 X93.151 Y103.334 E.02013
G1 X93.829 Y103.436 E.01993
G1 X94.453 Y103.405 E.01819
M204 S250
G1 X94.575 Y103.754 F36000
; FEATURE: Outer wall
G1 F3583
M204 S6000
G1 X95.3 Y103.57 E.02176
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02201
G1 X97.085 Y102.218 E.02202
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.01099
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.348 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.474 Y96.498 E.02206
G1 X94.939 Y96.319 E.01642
G1 X94.189 Y96.206 E.02207
G1 X93.434 Y96.243 E.02201
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.022
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.653 E.02201
G1 X91.861 Y103.14 E.02208
G1 X92.35 Y103.422 E.01641
G1 X93.063 Y103.682 E.02207
G1 X93.811 Y103.794 E.02201
G1 X94.515 Y103.759 E.02052
; WIPE_START
G1 F10082.057
M204 S10000
G1 X95.3 Y103.57 E-.3066
G1 X95.981 Y103.242 E-.28742
G1 X96.329 Y102.978 E-.16598
; WIPE_END
G1 E-.04 F1800
G1 X93.605 Y103.095 Z1.8 F36000
G1 Z1.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
M73 P25 R2
G1 F3583
G1 X93.227 Y103.038 E.01113
G1 X92.63 Y102.821 E.01847
G1 X92.274 Y102.616 E.01196
G1 X93.81 Y96.886 E.1726
G1 X93.533 Y96.9 E.00807
G1 X92.928 Y97.054 E.01817
G1 X92.608 Y97.208 E.01032
G1 X96.796 Y101.396 E.17235
G1 X96.858 Y101.289 E.00359
G1 X97.057 Y100.698 E.01816
G1 X97.12 Y100.189 E.01492
M73 P26 R2
G1 X91.386 Y101.725 E.17275
G1 X91.082 Y101.146 E.01905
G1 X90.912 Y100.544 E.01818
G1 X90.901 Y100.396 E.00431
; CHANGE_LAYER
; Z_HEIGHT: 1.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X90.912 Y100.544 E-.05634
G1 X91.082 Y101.146 E-.23747
G1 X91.386 Y101.725 E-.24873
G1 X91.939 Y101.577 E-.21746
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z1.8 I-.499 J1.11 P1  F36000
G1 X109.442 Y109.443 Z1.8
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3605
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3605
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 8 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer8 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X105.495 Y109.139 F36000
G1 Z2
M73 P27 R2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3605
G1 X106.924 Y109.139 E.04156
G1 X109.138 Y100.875 E.24896
G1 X109.138 Y100.062 E.02365
G1 X100.859 Y102.28 E.24939
G1 X100.859 Y101.835 E.01295
G1 X108.163 Y109.139 E.30056
G1 X109.138 Y109.139 E.02836
G1 X109.138 Y105.607 E.10278
G1 X100.859 Y107.826 E.24939
G1 X100.859 Y109.139 E.03823
G1 X101.379 Y109.139 E.01511
G1 X106.276 Y90.861 E.55063
G1 X105.034 Y90.861 E.03615
G1 X109.138 Y94.965 E.16888
G1 X109.138 Y94.517 E.01303
G1 X100.859 Y96.735 E.24939
G1 X100.859 Y94.261 E.07201
G1 X109.138 Y102.539 E.34068
G1 X109.138 Y103.968 E.04156
G1 X100.859 Y92.618 F36000
G1 F3605
G1 X100.859 Y91.19 E.04156
G1 X102.089 Y90.861 E.03706
G1 X103.518 Y90.861 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X102.089 Y90.861 E-.54276
G1 X101.537 Y91.009 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X97.774 Y97.649 Z2 F36000
G1 X94.513 Y103.402 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3605
G1 X95.177 Y103.233 E.01994
G1 X95.792 Y102.936 E.01988
G1 X96.365 Y102.498 E.02099
G1 X96.793 Y102.009 E.01889
G1 X97.136 Y101.415 E.01997
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00997
G1 X97.388 Y99.403 E.00996
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.676 Y96.626 E.02012
G1 X94.178 Y96.564 E.01459
G1 X93.487 Y96.598 E.02012
G1 X92.823 Y96.767 E.01993
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
M73 P28 R2
G1 X90.612 Y100.597 E.01992
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.866 E.01992
G1 X91.537 Y102.402 E.01993
G1 X92.062 Y102.843 E.01994
G1 X92.669 Y103.173 E.02012
G1 X93.145 Y103.333 E.0146
G1 X93.829 Y103.436 E.02012
G1 X94.453 Y103.405 E.01818
M204 S250
G1 X94.562 Y103.757 F36000
; FEATURE: Outer wall
G1 F3605
M204 S6000
G1 X94.566 Y103.757 E.00014
G1 X95.3 Y103.57 E.02201
G1 X95.98 Y103.242 E.02199
G1 X96.61 Y102.759 E.02309
G1 X97.084 Y102.218 E.02094
G1 X97.463 Y101.562 E.02203
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.717 E.01101
G1 X97.741 Y99.34 E.011
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02207
G1 X94.191 Y96.206 E.01641
G1 X93.434 Y96.243 E.02207
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.022
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.022
G1 X91.28 Y102.653 E.02201
G1 X91.86 Y103.139 E.02202
G1 X92.526 Y103.502 E.02206
G1 X93.061 Y103.681 E.01642
G1 X93.811 Y103.794 E.02207
G1 X94.502 Y103.76 E.02013
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.02461
G1 X95.3 Y103.57 E-.2875
G1 X95.98 Y103.242 E-.28715
G1 X96.316 Y102.985 E-.16074
; WIPE_END
G1 E-.04 F1800
G1 X96.007 Y102.389 Z2 F36000
G1 Z1.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3605
G1 X96.156 Y102.275 E.00547
G1 X96.545 Y101.832 E.01715
G1 X96.866 Y101.266 E.01893
G1 X92.743 Y97.143 E.16966
G1 X92.928 Y97.054 E.00596
G1 X93.533 Y96.9 E.01817
G1 X93.661 Y96.893 E.00374
G1 X92.153 Y102.522 E.16957
G1 X91.756 Y102.189 E.01509
G1 X91.482 Y101.846 E.01277
G1 X97.101 Y100.34 E.16928
G1 X97.134 Y100.078 E.00769
G1 X97.088 Y99.456 E.01816
G1 X96.941 Y98.936 E.01571
; CHANGE_LAYER
; Z_HEIGHT: 1.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X97.088 Y99.456 E-.2052
G1 X97.134 Y100.078 E-.23715
G1 X97.101 Y100.34 E-.10041
G1 X96.549 Y100.488 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z2 I-.694 J1 P1  F36000
G1 X109.442 Y109.443 Z2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3575
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3575
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
M73 P29 R2
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 9 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer9 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X109.138 Y108.486 F36000
G1 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3575
G1 X109.138 Y109.139 E.01902
G1 X108.363 Y109.139 E.02254
G1 X100.859 Y101.635 E.30879
G1 X100.859 Y102.427 E.02303
G1 X109.138 Y100.209 E.24939
G1 X109.138 Y100.328 E.00349
G1 X106.777 Y109.139 E.26542
G1 X105.349 Y109.139 E.04156
G1 X100.859 Y98.31 F36000
G1 F3575
G1 X100.859 Y96.882 E.04156
G1 X109.138 Y94.663 E.24939
G1 X109.138 Y94.765 E.00295
G1 X105.234 Y90.861 E.16065
G1 X106.13 Y90.861 E.02607
G1 X101.232 Y109.139 E.55063
G1 X100.859 Y109.139 E.01085
G1 X100.859 Y107.972 E.03397
G1 X109.138 Y105.754 E.24939
G1 X109.138 Y102.339 E.09935
M73 P30 R2
G1 X100.859 Y94.061 E.34068
G1 X100.859 Y91.337 E.07926
G1 X102.636 Y90.861 E.05352
G1 X104.064 Y90.861 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X102.636 Y90.861 E-.54276
G1 X102.084 Y91.009 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X98.109 Y97.525 Z2.2 F36000
G1 X94.528 Y103.396 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3575
G1 X94.552 Y103.395 E.00069
G1 X95.176 Y103.233 E.01876
G1 X95.794 Y102.936 E.01996
G1 X96.34 Y102.522 E.01993
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00996
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01994
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01994
G1 X95.331 Y96.827 E.02011
G1 X94.855 Y96.667 E.0146
G1 X94.171 Y96.564 E.02012
G1 X93.487 Y96.598 E.01994
G1 X92.823 Y96.767 E.01993
G1 X92.206 Y97.065 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01994
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.11 Y101.867 E.01994
G1 X91.537 Y102.402 E.01992
G1 X92.067 Y102.847 E.02013
G1 X92.501 Y103.097 E.01459
G1 X93.151 Y103.334 E.02013
G1 X93.827 Y103.436 E.01988
G1 X94.468 Y103.4 E.01868
M204 S250
G1 X94.548 Y103.753 F36000
; FEATURE: Outer wall
G1 F3575
M204 S6000
G1 X94.607 Y103.749 E.00172
G1 X95.299 Y103.57 E.0208
G1 X95.981 Y103.242 E.02202
G1 X96.584 Y102.785 E.02201
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.011
G1 X97.537 Y98.612 E.02202
G1 X97.191 Y97.939 E.02202
G1 X96.72 Y97.347 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.474 Y96.498 E.02206
G1 X94.939 Y96.319 E.01642
G1 X94.189 Y96.206 E.02207
G1 X93.434 Y96.243 E.02201
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.154 E.022
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.061 E.02202
G1 X91.28 Y102.653 E.022
G1 X91.862 Y103.14 E.02208
G1 X92.35 Y103.422 E.0164
G1 X93.063 Y103.682 E.02208
G1 X93.81 Y103.794 E.02199
G1 X94.488 Y103.756 E.01976
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.607 Y103.749 E-.04525
G1 X95.299 Y103.57 E-.2717
G1 X95.981 Y103.242 E-.28758
G1 X96.307 Y102.995 E-.15547
; WIPE_END
G1 E-.04 F1800
G1 X91.712 Y97.878 Z2.2 F36000
G1 Z1.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3575
G1 X91.868 Y97.702 E.00684
G1 X92.365 Y97.325 E.01817
G1 X92.878 Y97.078 E.01656
G1 X96.916 Y101.116 E.16617
G1 X97.057 Y100.698 E.01284
G1 X97.082 Y100.492 E.00604
G1 X91.578 Y101.967 E.16581
G1 X91.755 Y102.189 E.00828
G1 X92.033 Y102.422 E.01055
G1 X93.512 Y96.905 E.16619
G1 X94.156 Y96.869 E.01879
G1 X94.784 Y96.963 E.01846
G1 X94.924 Y97.01 E.0043
; CHANGE_LAYER
; Z_HEIGHT: 2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X94.784 Y96.963 E-.05614
G1 X94.156 Y96.869 E-.24112
G1 X93.512 Y96.905 E-.24534
G1 X93.364 Y97.458 E-.2174
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z2.2 I-.727 J.976 P1  F36000
G1 X109.442 Y109.443 Z2.2
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3582
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
M73 P31 R2
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3582
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 10 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer10 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X109.138 Y100.355 F36000
G1 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3582
G1 X100.859 Y102.573 E.24939
G1 X100.859 Y101.435 E.03311
G1 X108.563 Y109.139 E.31702
G1 X106.631 Y109.139 E.05623
M73 P32 R2
G1 X109.138 Y99.782 E.28188
G1 X109.138 Y98.354 E.04156
G1 X100.859 Y98.456 F36000
G1 F3582
G1 X100.859 Y97.028 E.04156
G1 X109.138 Y94.81 E.24939
G1 X109.138 Y94.565 E.00713
G1 X105.434 Y90.861 E.15242
G1 X105.984 Y90.861 E.01599
G1 X101.086 Y109.139 E.55063
G1 X100.859 Y109.139 E.00659
G1 X100.859 Y108.118 E.02971
G1 X109.138 Y105.9 E.24939
G1 X109.138 Y102.139 E.10942
G1 X100.859 Y93.861 E.34068
G1 X100.859 Y91.483 E.06918
G1 X103.182 Y90.861 E.06998
G1 X104.611 Y90.861 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X103.182 Y90.861 E-.54276
G1 X102.63 Y91.009 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X98.448 Y97.393 Z2.4 F36000
G1 X94.513 Y103.402 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3582
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.935 E.01993
G1 X96.34 Y102.522 E.01993
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01994
G1 X95.331 Y96.827 E.02011
G1 X94.855 Y96.667 E.0146
G1 X94.171 Y96.564 E.02012
G1 X93.487 Y96.598 E.01994
G1 X92.823 Y96.767 E.01993
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01993
G1 X92.062 Y102.843 E.01994
G1 X92.669 Y103.173 E.02012
G1 X93.145 Y103.333 E.0146
G1 X93.829 Y103.436 E.02012
G1 X94.453 Y103.405 E.01819
M204 S250
G1 X94.534 Y103.758 F36000
; FEATURE: Outer wall
G1 F3582
M204 S6000
G1 X94.566 Y103.757 E.00095
G1 X95.3 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02201
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.474 Y96.498 E.02206
G1 X94.939 Y96.319 E.01642
G1 X94.189 Y96.206 E.02207
G1 X93.434 Y96.243 E.02201
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.653 E.02201
M73 P33 R2
G1 X91.86 Y103.139 E.02202
G1 X92.526 Y103.502 E.02207
G1 X93.061 Y103.681 E.01641
G1 X93.811 Y103.794 E.02207
G1 X94.474 Y103.761 E.01932
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.03514
G1 X95.3 Y103.57 E-.28745
G1 X95.981 Y103.242 E-.28747
G1 X96.296 Y103.003 E-.14994
; WIPE_END
G1 E-.04 F1800
G1 X96.239 Y102.177 Z2.4 F36000
G1 Z2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3582
G1 X96.546 Y101.83 E.01348
G1 X96.858 Y101.289 E.01817
G1 X96.966 Y100.966 E.00992
G1 X93.028 Y97.028 E.16205
G1 X93.354 Y96.945 E.00979
G1 X91.914 Y102.322 E.16196
G1 X91.756 Y102.189 E.00601
G1 X91.674 Y102.087 E.00379
G1 X97.063 Y100.643 E.16234
G1 X97.134 Y100.078 E.01657
G1 X97.088 Y99.456 E.01816
G1 X97.024 Y99.23 E.00683
; CHANGE_LAYER
; Z_HEIGHT: 2.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X97.088 Y99.456 E-.08918
G1 X97.134 Y100.078 E-.23715
G1 X97.063 Y100.643 E-.21643
G1 X96.511 Y100.791 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z2.4 I-.677 J1.011 P1  F36000
G1 X109.442 Y109.443 Z2.4
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3585
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3585
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 11 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer11 end: 8,12
M625
; WIPE_START
M73 P34 R2
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X109.138 Y104.618 F36000
G1 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3585
G1 X109.138 Y106.046 E.04156
G1 X100.859 Y108.265 E.24939
G1 X100.859 Y106.836 E.04156
G1 X100.859 Y109.041 F36000
G1 F3585
G1 X100.859 Y108.81 E.00672
G1 X101.189 Y109.139 E.01355
G1 X100.939 Y109.139 E.00725
G1 X105.837 Y90.861 E.55063
G1 X105.634 Y90.861 E.00591
G1 X109.138 Y94.365 E.14419
G1 X109.138 Y94.956 E.01721
G1 X100.859 Y97.175 E.24939
G1 X100.859 Y98.603 E.04156
G1 X109.138 Y97.807 F36000
G1 F3585
G1 X109.138 Y99.236 E.04156
G1 X106.484 Y109.139 E.29834
G1 X108.763 Y109.139 E.06631
G1 X100.859 Y101.235 E.32525
G1 X100.859 Y102.72 E.04319
G1 X109.138 Y100.501 E.24939
G1 X109.138 Y101.939 E.04185
G1 X100.859 Y93.661 E.34068
G1 X100.859 Y91.629 E.0591
G1 X103.729 Y90.861 E.08644
G1 X105.157 Y90.861 E.04156
; OBJECT_ID: 12
; WIPE_START
M73 P35 R2
G1 F10081.784
G1 X103.729 Y90.861 E-.54276
G1 X103.176 Y91.009 E-.21725
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X98.8 Y97.262 Z2.6 F36000
G1 X94.502 Y103.402 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3585
G1 X94.513 Y103.402 E.00032
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01993
G1 X96.793 Y102.008 E.01994
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01994
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.158 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.676 Y96.626 E.02012
G1 X94.178 Y96.564 E.01459
G1 X93.487 Y96.598 E.02013
G1 X92.823 Y96.767 E.01993
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.11 Y101.867 E.01994
G1 X91.537 Y102.402 E.01992
G1 X92.062 Y102.843 E.01994
G1 X92.669 Y103.173 E.02011
G1 X93.145 Y103.333 E.0146
G1 X93.829 Y103.436 E.02012
G1 X94.442 Y103.405 E.01787
M204 S250
G1 X94.52 Y103.759 F36000
; FEATURE: Outer wall
G1 F3585
M204 S6000
G1 X94.566 Y103.757 E.00136
G1 X95.3 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02201
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02202
G1 X96.72 Y97.348 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02207
G1 X94.191 Y96.206 E.01641
G1 X93.434 Y96.243 E.02207
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.061 E.02202
G1 X91.28 Y102.653 E.022
G1 X91.86 Y103.139 E.02202
G1 X92.526 Y103.502 E.02206
G1 X93.061 Y103.681 E.01642
G1 X93.811 Y103.794 E.02207
G1 X94.46 Y103.762 E.01891
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.04055
G1 X95.3 Y103.57 E-.28745
G1 X95.981 Y103.242 E-.28743
G1 X96.284 Y103.012 E-.14457
; WIPE_END
G1 E-.04 F1800
G1 X93 Y102.964 Z2.6 F36000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3585
G1 X92.791 Y102.894 E.0064
G1 X92.234 Y102.591 E.01846
G1 X91.794 Y102.222 E.0167
G1 X93.188 Y96.988 E.1576
G1 X97.017 Y100.817 E.15756
G1 X97.022 Y100.801 E.00049
G1 X91.776 Y102.206 E.15802
G1 X91.366 Y101.701 E.01893
G1 X91.082 Y101.145 E.01817
G1 X91.04 Y100.998 E.00445
; CHANGE_LAYER
; Z_HEIGHT: 2.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X91.082 Y101.145 E-.05808
G1 X91.366 Y101.701 E-.23732
G1 X91.776 Y102.206 E-.24717
G1 X92.329 Y102.058 E-.21744
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z2.6 I-.482 J1.117 P1  F36000
G1 X109.442 Y109.443 Z2.6
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3604
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
M73 P36 R2
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3604
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 12 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer12 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X109.138 Y104.765 F36000
G1 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3604
G1 X109.138 Y106.193 E.04156
G1 X100.859 Y108.411 E.24939
G1 X102.817 Y109.139 F36000
G1 F3604
G1 X101.389 Y109.139 E.04156
G1 X100.859 Y108.61 E.02178
G1 X100.859 Y108.892 E.00819
G1 X105.691 Y90.861 E.54317
G1 X105.834 Y90.861 E.00417
G1 X109.138 Y94.165 E.13596
G1 X109.138 Y95.103 E.02729
G1 X100.859 Y97.321 E.24939
G1 X100.859 Y95.893 E.04156
G1 X105.512 Y90.861 F36000
M73 P37 R2
G1 F3604
G1 X104.275 Y90.861 E.036
G1 X100.859 Y91.776 E.1029
G1 X100.859 Y93.461 E.04902
G1 X109.138 Y101.739 E.34068
G1 X109.138 Y100.648 E.03177
G1 X100.859 Y102.866 E.24939
G1 X100.859 Y101.035 E.05327
G1 X108.963 Y109.139 E.33348
G1 X106.338 Y109.139 E.07639
G1 X109.138 Y98.689 E.3148
G1 X109.138 Y97.261 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X109.138 Y98.689 E-.54276
G1 X108.99 Y99.241 E-.21725
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X101.654 Y101.347 Z2.8 F36000
G1 X94.488 Y103.403 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3604
G1 X94.513 Y103.402 E.00074
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.158 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.676 Y96.626 E.02012
G1 X94.178 Y96.564 E.0146
G1 X93.487 Y96.598 E.02013
G1 X92.823 Y96.767 E.01993
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01994
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01993
G1 X92.062 Y102.843 E.01994
G1 X92.664 Y103.17 E.01993
G1 X93.325 Y103.374 E.02012
G1 X93.822 Y103.436 E.01459
G1 X94.428 Y103.406 E.01764
M204 S250
G1 X94.505 Y103.76 F36000
; FEATURE: Outer wall
G1 F3604
M204 S6000
G1 X94.566 Y103.757 E.00178
G1 X95.299 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02201
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02207
G1 X94.191 Y96.206 E.01641
G1 X93.434 Y96.243 E.02207
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.653 E.02201
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.249 Y103.724 E.02207
G1 X93.809 Y103.794 E.01641
G1 X94.445 Y103.763 E.01855
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.04607
G1 X95.299 Y103.57 E-.28742
G1 X95.981 Y103.242 E-.28739
G1 X96.273 Y103.021 E-.13912
; WIPE_END
G1 E-.04 F1800
G1 X93.145 Y103.001 Z2.8 F36000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3604
G1 X92.782 Y102.889 E.01103
G1 X92.234 Y102.591 E.01816
G1 X91.908 Y102.317 E.01237
G1 X96.968 Y100.962 E.15241
G1 X97.061 Y100.661 E.00915
G1 X93.347 Y96.947 E.15284
G1 X93.04 Y97.025 E.00921
M73 P38 R2
G1 X91.681 Y102.096 E.15276
G1 X91.366 Y101.701 E.0147
G1 X91.082 Y101.146 E.01816
G1 X91.001 Y100.858 E.0087
; CHANGE_LAYER
; Z_HEIGHT: 2.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X91.082 Y101.146 E-.11358
G1 X91.366 Y101.701 E-.23716
G1 X91.681 Y102.096 E-.19202
G1 X91.829 Y101.544 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z2.8 I-.498 J1.11 P1  F36000
G1 X109.442 Y109.443 Z2.8
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3599
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3599
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 13 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer13 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X104.763 Y109.139 F36000
G1 Z3
M73 P39 R2
G1 Z2.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3599
G1 X106.192 Y109.139 E.04156
G1 X109.138 Y98.143 E.33126
G1 X109.138 Y96.715 E.04156
G1 X105.366 Y90.861 F36000
G1 F3599
G1 X104.821 Y90.861 E.01584
G1 X100.859 Y91.922 E.11936
G1 X100.859 Y93.261 E.03894
G1 X109.138 Y101.539 E.34068
G1 X109.138 Y100.794 E.02169
G1 X100.859 Y103.012 E.24939
G1 X100.859 Y100.835 E.06335
G1 X109.138 Y109.114 E.34068
G1 X109.138 Y106.339 E.08074
G1 X100.859 Y108.558 E.24939
G1 X100.859 Y109.139 E.01693
G1 X101.589 Y109.139 E.02122
G1 X100.859 Y108.41 E.03001
G1 X100.859 Y108.345 E.00189
G1 X105.544 Y90.861 E.52671
G1 X106.034 Y90.861 E.01425
G1 X109.138 Y93.965 E.12773
G1 X109.138 Y95.249 E.03737
G1 X100.859 Y97.467 E.24939
G1 X100.859 Y96.039 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X100.859 Y97.467 E-.54276
G1 X101.412 Y97.319 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X95.673 Y102.352 Z3 F36000
G1 X94.473 Y103.404 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3599
G1 X94.51 Y103.402 E.00109
G1 X95.231 Y103.212 E.02168
G1 X95.792 Y102.937 E.0182
G1 X96.34 Y102.522 E.01999
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00997
G1 X97.388 Y99.403 E.00996
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.134 E.01992
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.676 Y96.626 E.02012
G1 X94.178 Y96.564 E.01459
G1 X93.487 Y96.598 E.02012
G1 X92.823 Y96.767 E.01994
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
M73 P40 R2
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01993
G1 X92.062 Y102.843 E.01994
G1 X92.664 Y103.17 E.01993
G1 X93.324 Y103.374 E.02012
G1 X93.822 Y103.436 E.0146
G1 X94.413 Y103.407 E.01721
M204 S250
G1 X94.491 Y103.76 F36000
; FEATURE: Outer wall
G1 F3599
M204 S6000
G1 X94.566 Y103.757 E.00218
G1 X95.356 Y103.548 E.02379
G1 X95.98 Y103.242 E.02023
G1 X96.584 Y102.785 E.02203
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.717 E.01101
G1 X97.741 Y99.34 E.011
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.022
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02207
G1 X94.191 Y96.206 E.01641
G1 X93.434 Y96.243 E.02207
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.653 E.02201
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.249 Y103.724 E.02207
G1 X93.809 Y103.794 E.01641
G1 X94.431 Y103.763 E.01812
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.05126
G1 X95.356 Y103.548 E-.31069
G1 X95.98 Y103.242 E-.26422
G1 X96.261 Y103.029 E-.13383
; WIPE_END
G1 E-.04 F1800
G1 X93.309 Y103.052 Z3 F36000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3599
G1 X92.782 Y102.889 E.01605
G1 X92.234 Y102.591 E.01816
G1 X92.041 Y102.428 E.00734
G1 X96.914 Y101.123 E.1468
G1 X97.057 Y100.698 E.01304
G1 X97.083 Y100.483 E.00629
G1 X93.506 Y96.906 E.14719
G1 X92.88 Y97.077 E.01889
G1 X91.572 Y101.959 E.14706
G1 X91.366 Y101.701 E.00959
G1 X91.082 Y101.146 E.01816
G1 X90.953 Y100.689 E.01381
; CHANGE_LAYER
; Z_HEIGHT: 2.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X91.082 Y101.146 E-.18038
G1 X91.366 Y101.701 E-.23714
G1 X91.572 Y101.959 E-.12524
G1 X91.72 Y101.407 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z3 I-.503 J1.108 P1  F36000
G1 X109.442 Y109.443 Z3
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3620
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3620
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
M73 P41 R2
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 14 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer14 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X104.617 Y109.139 F36000
G1 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3620
G1 X106.045 Y109.139 E.04156
G1 X109.138 Y97.596 E.34772
G1 X109.138 Y96.168 E.04156
G1 X107.662 Y90.861 F36000
G1 F3620
G1 X106.234 Y90.861 E.04156
G1 X109.138 Y93.765 E.1195
G1 X109.138 Y95.395 E.04745
G1 X100.859 Y97.614 E.24939
G1 X100.859 Y100.635 E.08792
G1 X109.138 Y108.914 E.34068
G1 X109.138 Y106.486 E.07066
G1 X100.859 Y108.704 E.24939
G1 X100.859 Y109.139 E.01267
G1 X101.789 Y109.139 E.02704
G1 X100.859 Y108.21 E.03824
G1 X100.859 Y107.799 E.01197
G1 X105.398 Y90.861 E.51025
G1 X100.859 Y92.069 E.13666
M73 P42 R2
G1 X100.859 Y93.061 E.02886
G1 X109.138 Y101.339 E.34068
G1 X109.138 Y100.941 E.01161
G1 X100.859 Y103.159 E.24939
G1 X100.859 Y104.587 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X100.859 Y103.159 E-.54276
G1 X101.412 Y103.011 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X94.445 Y103.403 Z3.2 F36000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3620
G1 X94.567 Y103.393 E.00357
G1 X95.175 Y103.233 E.01828
G1 X95.794 Y102.936 E.01998
G1 X96.34 Y102.522 E.01994
G1 X96.793 Y102.008 E.01994
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.158 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.68 Y96.627 E.01998
G1 X94.056 Y96.561 E.01828
G1 X93.491 Y96.597 E.01646
G1 X92.823 Y96.767 E.02005
G1 X92.206 Y97.064 E.01992
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01992
G1 X92.062 Y102.843 E.01994
G1 X92.664 Y103.17 E.01993
G1 X93.318 Y103.372 E.01993
G1 X94.004 Y103.441 E.02005
G1 X94.386 Y103.408 E.01114
M204 S250
G1 X94.476 Y103.759 F36000
; FEATURE: Outer wall
G1 F3620
M204 S6000
G1 X94.628 Y103.746 E.00446
G1 X95.299 Y103.57 E.02017
G1 X95.981 Y103.242 E.02202
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02202
G1 X94.063 Y96.202 E.02017
G1 X93.435 Y96.243 E.01832
G1 X92.701 Y96.43 E.02205
G1 X92.019 Y96.758 E.022
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.653 E.022
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.247 Y103.724 E.02201
G1 X94.001 Y103.799 E.02205
G1 X94.416 Y103.764 E.0121
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.628 Y103.746 E-.08103
G1 X95.299 Y103.57 E-.26347
G1 X95.981 Y103.242 E-.28759
G1 X96.249 Y103.039 E-.12791
; WIPE_END
G1 E-.04 F1800
G1 X91.59 Y98.016 Z3.2 F36000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3620
G1 X91.868 Y97.702 E.0122
G1 X92.365 Y97.325 E.01817
G1 X92.712 Y97.158 E.01119
G1 X91.462 Y101.821 E.14048
G1 X91.755 Y102.189 E.01368
G1 X92.173 Y102.539 E.01586
G1 X96.86 Y101.283 E.14119
G1 X97.057 Y100.698 E.01798
G1 X97.106 Y100.306 E.0115
G1 X93.689 Y96.889 E.14062
G1 X94.049 Y96.865 E.01052
G1 X94.619 Y96.926 E.01666
G1 X95.091 Y97.072 E.01438
; CHANGE_LAYER
; Z_HEIGHT: 3
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X94.619 Y96.926 E-.18781
G1 X94.049 Y96.865 E-.21759
G1 X93.689 Y96.889 E-.13736
G1 X94.093 Y97.293 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z3.2 I-.755 J.954 P1  F36000
G1 X109.442 Y109.443 Z3.2
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3606
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
M73 P43 R2
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3606
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 15 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer15 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X104.471 Y109.139 F36000
G1 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3606
G1 X105.899 Y109.139 E.04156
G1 X109.138 Y97.05 E.36418
G1 X109.138 Y95.542 E.04388
G1 X100.859 Y97.76 E.24939
G1 X100.859 Y100.435 E.07784
M73 P44 R2
G1 X109.138 Y108.714 E.34068
G1 X109.138 Y106.632 E.06058
G1 X100.859 Y108.85 E.24939
G1 X100.859 Y109.139 E.00841
G1 X101.989 Y109.139 E.03286
G1 X100.859 Y108.01 E.04647
G1 X100.859 Y107.252 E.02205
G1 X105.251 Y90.861 E.49379
G1 X109.138 Y92.136 F36000
G1 F3606
G1 X109.138 Y93.565 E.04156
G1 X106.434 Y90.861 E.11127
G1 X105.914 Y90.861 E.01512
G1 X100.859 Y92.215 E.15228
G1 X100.859 Y92.861 E.01878
G1 X109.138 Y101.139 E.34068
G1 X109.138 Y101.087 E.00153
G1 X100.859 Y103.305 E.24939
G1 X100.859 Y101.877 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X100.859 Y103.305 E-.54276
G1 X101.412 Y103.157 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X94.426 Y103.398 Z3.4 F36000
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3606
G1 X94.682 Y103.372 E.00748
G1 X95.336 Y103.17 E.01993
G1 X95.938 Y102.842 E.01993
G1 X96.463 Y102.402 E.01994
G1 X96.892 Y101.863 E.02004
G1 X97.16 Y101.36 E.0166
G1 X97.354 Y100.768 E.01812
G1 X97.439 Y100.086 E.02
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.68 Y96.627 E.01999
G1 X94.06 Y96.561 E.01814
G1 X93.491 Y96.597 E.0166
G1 X92.823 Y96.767 E.02004
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01993
G1 X92.062 Y102.843 E.01994
G1 X92.664 Y103.17 E.01993
G1 X93.318 Y103.372 E.01993
G1 X94 Y103.44 E.01994
G1 X94.366 Y103.404 E.01071
M204 S250
G1 X94.461 Y103.753 F36000
; FEATURE: Outer wall
G1 F3606
M204 S6000
G1 X94.753 Y103.724 E.00852
G1 X95.476 Y103.501 E.02201
G1 X96.14 Y103.139 E.02201
G1 X96.72 Y102.653 E.02202
G1 X97.192 Y102.06 E.02205
G1 X97.49 Y101.5 E.01845
G1 X97.704 Y100.846 E.02002
G1 X97.798 Y100.095 E.02204
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02203
G1 X94.068 Y96.202 E.02003
G1 X93.435 Y96.243 E.01846
G1 X92.701 Y96.43 E.02205
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.66 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.653 E.02201
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.247 Y103.724 E.02201
G1 X94 Y103.799 E.02202
G1 X94.402 Y103.759 E.01175
; WIPE_START
G1 F10082.057
M204 S10000
M73 P45 R2
G1 X94.753 Y103.724 E-.1341
G1 X95.476 Y103.501 E-.28748
G1 X96.14 Y103.139 E-.28746
G1 X96.243 Y103.053 E-.05096
; WIPE_END
G1 E-.04 F1800
G1 X91.467 Y98.156 Z3.4 F36000
G1 Z3
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3606
G1 X91.868 Y97.702 E.01763
G1 X92.365 Y97.325 E.01817
G1 X92.544 Y97.239 E.00577
G1 X91.354 Y101.678 E.13371
G1 X91.756 Y102.189 E.01891
G1 X92.234 Y102.591 E.01818
G1 X92.331 Y102.643 E.00321
G1 X96.765 Y101.455 E.13358
G1 X96.879 Y101.24 E.00708
G1 X97.056 Y100.701 E.01651
G1 X97.128 Y100.128 E.0168
G1 X93.877 Y96.877 E.13379
G1 X94.054 Y96.865 E.00516
G1 X94.618 Y96.926 E.01653
G1 X95.218 Y97.111 E.01825
G1 X95.267 Y97.138 E.00162
; CHANGE_LAYER
; Z_HEIGHT: 3.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X95.218 Y97.111 E-.02115
G1 X94.618 Y96.926 E-.23837
G1 X94.054 Y96.865 E-.21585
G1 X93.877 Y96.877 E-.06739
G1 X94.281 Y97.281 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z3.4 I-.762 J.949 P1  F36000
G1 X109.442 Y109.443 Z3.4
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3557
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3557
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 16 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer16 end: 8,12
M625
; WIPE_START
M73 P46 R2
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X107.181 Y109.139 F36000
G1 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3557
G1 X105.752 Y109.139 E.04156
G1 X109.138 Y96.504 E.38064
G1 X109.138 Y95.688 E.02372
G1 X100.859 Y97.907 E.24939
G1 X100.859 Y100.235 E.06776
G1 X109.138 Y108.514 E.34068
G1 X109.138 Y106.779 E.0505
G1 X100.859 Y108.997 E.24939
G1 X100.859 Y109.139 E.00415
G1 X102.189 Y109.139 E.03868
G1 X100.859 Y107.81 E.0547
G1 X100.859 Y106.706 E.03213
G1 X105.105 Y90.861 E.47733
G1 X103.677 Y90.861 E.04156
G1 X109.138 Y91.936 F36000
G1 F3557
G1 X109.138 Y93.365 E.04156
G1 X106.634 Y90.861 E.10304
G1 X106.461 Y90.861 E.00505
G1 X100.859 Y92.361 E.16874
G1 X100.859 Y92.661 E.0087
G1 X109.138 Y100.939 E.34068
G1 X109.138 Y101.233 E.00855
G1 X100.859 Y103.452 E.24939
G1 X100.859 Y102.023 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X100.859 Y103.452 E-.54276
G1 X101.412 Y103.304 E-.21724
; WIPE_END
M73 P47 R2
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X94.415 Y103.405 Z3.6 F36000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3557
G1 X94.577 Y103.391 E.00474
G1 X95.175 Y103.234 E.018
G1 X95.794 Y102.935 E.02
G1 X96.34 Y102.522 E.01993
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01995
G1 X95.336 Y96.83 E.01993
G1 X94.68 Y96.627 E.01999
G1 X94.065 Y96.561 E.018
G1 X93.491 Y96.597 E.01674
G1 X92.823 Y96.767 E.02004
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01992
G1 X92.062 Y102.842 E.01994
G1 X92.664 Y103.17 E.01993
G1 X93.318 Y103.372 E.01993
G1 X94.004 Y103.441 E.02005
G1 X94.355 Y103.41 E.01025
M204 S250
G1 X94.445 Y103.761 F36000
; FEATURE: Outer wall
G1 F3557
M204 S6000
G1 X94.638 Y103.744 E.00563
G1 X95.299 Y103.57 E.01988
G1 X95.981 Y103.242 E.02203
G1 X96.584 Y102.785 E.02201
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.348 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02203
G1 X94.073 Y96.203 E.01989
G1 X93.435 Y96.243 E.0186
G1 X92.701 Y96.43 E.02205
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.66 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.652 E.022
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.247 Y103.724 E.02201
G1 X94.001 Y103.799 E.02206
G1 X94.385 Y103.766 E.01122
M204 S10000
G1 X93.872 Y103.122 F36000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3557
G1 X93.379 Y103.073 E.01442
G1 X92.782 Y102.889 E.01817
G1 X92.511 Y102.741 E.00897
G1 X96.662 Y101.629 E.12502
G1 X96.858 Y101.289 E.01142
G1 X97.057 Y100.698 E.01816
G1 X97.134 Y100.078 E.01817
G1 X97.123 Y99.923 E.00454
G1 X94.058 Y96.865 E.12595
G1 X93.538 Y96.898 E.01516
G1 X92.928 Y97.054 E.01834
G1 X92.376 Y97.32 E.01782
G1 X91.258 Y101.49 E.12563
G1 X91.082 Y101.146 E.01126
G1 X90.912 Y100.544 E.01818
G1 X90.881 Y100.129 E.01212
; CHANGE_LAYER
; Z_HEIGHT: 3.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X90.912 Y100.544 E-.15826
G1 X91.082 Y101.146 E-.23746
G1 X91.258 Y101.49 E-.14704
G1 X91.406 Y100.938 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z3.6 I-.519 J1.101 P1  F36000
G1 X109.442 Y109.443 Z3.6
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3627
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
M73 P48 R2
G1 F3627
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 17 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer17 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.859 Y107.789 F36000
G1 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3627
G1 X100.859 Y109.139 E.0393
G1 X100.874 Y109.139 E.00041
G1 X109.138 Y106.925 E.24896
G1 X109.138 Y108.314 E.04043
G1 X100.859 Y100.035 E.34068
G1 X100.859 Y98.053 E.05768
G1 X109.138 Y95.835 E.24939
G1 X109.138 Y95.957 E.00356
G1 X105.606 Y109.139 E.3971
G1 X102.389 Y109.139 E.09362
G1 X100.859 Y107.61 E.06293
G1 X100.859 Y106.16 E.04221
G1 X104.959 Y90.861 E.46087
G1 X103.53 Y90.861 E.04156
M73 P49 R2
G1 X109.138 Y91.736 F36000
G1 F3627
G1 X109.138 Y93.165 E.04156
G1 X106.834 Y90.861 E.09481
G1 X107.007 Y90.861 E.00503
G1 X100.859 Y92.508 E.1852
G1 X100.859 Y92.461 E.00138
G1 X109.138 Y100.739 E.34068
G1 X109.138 Y101.38 E.01863
G1 X100.859 Y103.598 E.24939
G1 X100.859 Y102.17 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X100.859 Y103.598 E-.54276
G1 X101.412 Y103.45 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X94.403 Y103.411 Z3.8 F36000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3627
G1 X94.507 Y103.403 E.00302
G1 X95.177 Y103.233 E.02012
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
G1 X96.793 Y102.008 E.01994
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.68 Y96.627 E.02
G1 X94.069 Y96.561 E.01786
G1 X93.49 Y96.597 E.01688
G1 X92.823 Y96.767 E.02003
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01994
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01992
G1 X92.062 Y102.842 E.01994
G1 X92.664 Y103.17 E.01993
G1 X93.318 Y103.372 E.01993
G1 X94.006 Y103.441 E.02012
G1 X94.343 Y103.416 E.00983
M204 S250
G1 X94.43 Y103.767 F36000
; FEATURE: Outer wall
G1 F3627
M204 S6000
G1 X94.565 Y103.757 E.00393
G1 X95.299 Y103.57 E.02207
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.217 E.02202
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02203
G1 X94.078 Y96.203 E.01974
G1 X93.435 Y96.243 E.01874
G1 X92.701 Y96.43 E.02204
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02202
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.022
G1 X91.28 Y102.652 E.022
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.247 Y103.724 E.02201
G1 X94.002 Y103.799 E.02207
G1 X94.37 Y103.772 E.01074
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.565 Y103.757 E-.07412
G1 X95.299 Y103.57 E-.28819
G1 X95.981 Y103.242 E-.28743
G1 X96.212 Y103.067 E-.11026
; WIPE_END
G1 E-.04 F1800
G1 X91.257 Y98.513 Z3.8 F36000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3627
G1 X91.455 Y98.17 E.01152
G1 X91.868 Y97.702 E.01816
G1 X92.193 Y97.455 E.01188
G1 X91.162 Y101.303 E.11589
G1 X91.198 Y101.373 E.0023
G1 X92.633 Y102.808 E.05905
G1 X92.691 Y102.84 E.00194
G1 X96.562 Y101.803 E.11658
G1 X96.583 Y101.765 E.00126
G1 X97.113 Y99.789 E.05951
G1 X97.106 Y99.706 E.00242
G1 X94.29 Y96.89 E.11588
G1 X94.618 Y96.926 E.00959
G1 X95.218 Y97.111 E.01827
G1 X95.631 Y97.336 E.0137
; CHANGE_LAYER
; Z_HEIGHT: 3.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X95.218 Y97.111 E-.17892
G1 X94.618 Y96.926 E-.23862
G1 X94.29 Y96.89 E-.12522
G1 X94.695 Y97.295 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z3.8 I-.774 J.939 P1  F36000
G1 X109.442 Y109.443 Z3.8
G1 Z3.6
M73 P50 R2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3687
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3687
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
M73 P50 R1
G1 X109.739 Y109.8 E.27758
; object ids of layer 18 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer18 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.859 Y108.272 F36000
G1 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3687
G1 X100.859 Y109.139 E.02525
G1 X101.42 Y109.139 E.01631
G1 X109.138 Y107.071 E.2325
G1 X109.138 Y108.114 E.03035
M73 P51 R1
G1 X100.859 Y99.835 E.34068
G1 X100.859 Y98.199 E.0476
G1 X109.138 Y95.981 E.24939
G1 X103.384 Y90.861 F36000
G1 F3687
G1 X104.812 Y90.861 E.04156
G1 X100.859 Y105.613 E.44441
G1 X100.859 Y107.41 E.05229
G1 X102.589 Y109.139 E.07116
G1 X105.46 Y109.139 E.08354
G1 X109.138 Y95.411 E.41356
G1 X109.138 Y92.965 E.07118
G1 X107.034 Y90.861 E.08658
G1 X108.982 Y90.861 F36000
G1 F3687
G1 X107.554 Y90.861 E.04156
G1 X100.859 Y92.654 E.20166
G1 X100.859 Y92.261 E.01146
G1 X109.138 Y100.539 E.34068
G1 X109.138 Y101.526 E.02871
G1 X100.859 Y103.745 E.24939
G1 X100.859 Y102.316 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X100.859 Y103.745 E-.54276
G1 X101.412 Y103.597 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X94.377 Y103.402 Z4 F36000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3687
G1 X94.685 Y103.372 E.00901
G1 X95.246 Y103.206 E.01701
G1 X95.792 Y102.937 E.01771
G1 X96.34 Y102.522 E.02001
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01994
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.158 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.68 Y96.627 E.02
G1 X94.074 Y96.561 E.01772
G1 X93.49 Y96.597 E.01702
G1 X92.823 Y96.767 E.02003
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01993
G1 X92.062 Y102.843 E.01994
G1 X92.664 Y103.17 E.01993
G1 X93.318 Y103.372 E.01993
G1 X94 Y103.44 E.01994
G1 X94.317 Y103.408 E.00928
M204 S250
G1 X94.413 Y103.758 F36000
; FEATURE: Outer wall
G1 F3687
M204 S6000
G1 X94.754 Y103.724 E.00999
G1 X95.377 Y103.54 E.01888
G1 X95.98 Y103.242 E.01959
G1 X96.584 Y102.785 E.02204
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
M73 P52 R1
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.022
G1 X96.72 Y97.348 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02203
G1 X94.082 Y96.203 E.0196
G1 X93.435 Y96.243 E.01888
G1 X92.701 Y96.43 E.02204
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.653 E.02201
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.247 Y103.724 E.02201
G1 X94 Y103.799 E.02202
G1 X94.353 Y103.764 E.01032
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.754 Y103.724 E-.15327
G1 X95.377 Y103.54 E-.24658
G1 X95.98 Y103.242 E-.25582
G1 X96.199 Y103.076 E-.10433
; WIPE_END
G1 E-.04 F1800
G1 X95.899 Y97.521 Z4 F36000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3687
G1 X95.766 Y97.41 E.00504
G1 X95.218 Y97.111 E.01816
G1 X94.615 Y96.926 E.01836
G1 X91.949 Y97.64 E.08029
G1 X92.009 Y97.594 E.00218
G1 X91.069 Y101.102 E.10566
G1 X91.047 Y101.021 E.00244
G1 X92.973 Y102.948 E.07928
G1 X92.908 Y102.928 E.00198
G1 X96.403 Y101.991 E.10528
G1 X96.364 Y102.036 E.00171
G1 X97.071 Y99.397 E.07947
G1 X97.09 Y99.49 E.00275
G1 X94.515 Y96.915 E.10599
G1 X94.234 Y96.884 E.00822
; CHANGE_LAYER
; Z_HEIGHT: 3.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X94.515 Y96.915 E-.1074
G1 X95.729 Y98.129 E-.6526
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z4 I-.774 J.939 P1  F36000
G1 X109.442 Y109.443 Z4
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3675
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3675
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
M73 P53 R1
G1 X109.739 Y109.8 E.27758
; object ids of layer 19 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer19 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X106.741 Y109.139 F36000
G1 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3675
G1 X105.313 Y109.139 E.04156
G1 X109.138 Y94.864 E.43002
G1 X109.138 Y92.765 E.0611
G1 X107.234 Y90.861 E.07835
G1 X109.138 Y91.251 F36000
G1 F3675
G1 X109.138 Y90.861 E.01135
G1 X108.1 Y90.861 E.03021
G1 X100.859 Y92.801 E.21812
G1 X100.859 Y92.061 E.02154
G1 X109.138 Y100.339 E.34068
G1 X109.138 Y101.673 E.03879
G1 X100.859 Y103.891 E.24939
G1 X100.859 Y102.463 E.04156
G1 X109.138 Y97.556 F36000
G1 F3675
G1 X109.138 Y96.127 E.04156
G1 X100.859 Y98.346 E.24939
G1 X100.859 Y99.635 E.03752
G1 X109.138 Y107.914 E.34068
G1 X109.138 Y107.218 E.02027
G1 X101.966 Y109.139 E.21604
G1 X100.859 Y109.139 E.03221
G1 X100.859 Y108.818 E.00935
G1 X102.789 Y109.139 F36000
G1 F3675
G1 X100.859 Y107.21 E.07939
G1 X100.859 Y105.067 E.06237
M73 P54 R1
G1 X104.666 Y90.861 E.42795
G1 X103.238 Y90.861 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X104.666 Y90.861 E-.54276
G1 X104.518 Y91.413 E-.21725
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X99.585 Y97.237 Z4.2 F36000
G1 X94.361 Y103.404 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3675
G1 X94.682 Y103.372 E.00937
G1 X95.336 Y103.17 E.01994
G1 X95.938 Y102.842 E.01993
G1 X96.463 Y102.402 E.01994
G1 X96.89 Y101.866 E.01993
G1 X97.205 Y101.251 E.02012
G1 X97.353 Y100.772 E.01459
G1 X97.439 Y100.086 E.02012
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.158 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.679 Y96.627 E.02
G1 X94.079 Y96.561 E.01758
G1 X93.49 Y96.597 E.01716
G1 X92.823 Y96.767 E.02002
G1 X92.206 Y97.065 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01994
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01993
G1 X92.062 Y102.842 E.01994
G1 X92.664 Y103.17 E.01993
G1 X93.318 Y103.372 E.01993
G1 X94 Y103.44 E.01993
G1 X94.302 Y103.41 E.00882
M204 S250
G1 X94.397 Y103.759 F36000
; FEATURE: Outer wall
G1 F3675
M204 S6000
G1 X94.753 Y103.724 E.01041
G1 X95.476 Y103.501 E.02201
G1 X96.14 Y103.139 E.02201
G1 X96.72 Y102.652 E.02202
G1 X97.191 Y102.061 E.02201
G1 X97.537 Y101.386 E.02207
G1 X97.704 Y100.847 E.01641
G1 X97.798 Y100.095 E.02207
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02203
G1 X94.087 Y96.203 E.01946
G1 X93.435 Y96.243 E.01903
G1 X92.701 Y96.43 E.02204
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02202
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.022
G1 X91.28 Y102.653 E.02201
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.247 Y103.724 E.02201
G1 X94 Y103.799 E.02201
G1 X94.337 Y103.765 E.00986
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.753 Y103.724 E-.15874
G1 X95.476 Y103.501 E-.28751
G1 X96.14 Y103.139 E-.28738
G1 X96.193 Y103.094 E-.02636
; WIPE_END
G1 E-.04 F1800
G1 X95.925 Y102.457 Z4.2 F36000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3675
G1 X96.157 Y102.262 E.0088
G1 X96.996 Y99.131 E.09433
G1 X97.022 Y99.222 E.00275
G1 X94.774 Y96.974 E.09249
G1 X94.87 Y97.004 E.00292
G1 X91.745 Y97.841 E.09414
G1 X91.819 Y97.756 E.00329
G1 X90.994 Y100.835 E.09276
G1 X90.968 Y100.743 E.00279
G1 X93.262 Y103.037 E.0944
G1 X93.162 Y103.006 E.00305
G1 X96.253 Y102.178 E.09311
G1 X96.456 Y101.924 E.00945
; CHANGE_LAYER
; Z_HEIGHT: 4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X96.253 Y102.178 E-.12342
G1 X94.635 Y102.612 E-.63658
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z4.2 I-.51 J1.105 P1  F36000
G1 X109.442 Y109.443 Z4.2
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3672
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
M73 P55 R1
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F3672
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 20 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer20 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X106.595 Y109.139 F36000
G1 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F3672
G1 X105.167 Y109.139 E.04156
G1 X109.138 Y94.318 E.44648
G1 X109.138 Y92.565 E.05102
G1 X107.434 Y90.861 E.07012
G1 X104.519 Y90.861 E.08481
G1 X100.859 Y104.52 E.41149
G1 X100.859 Y107.01 E.07245
M73 P56 R1
G1 X102.989 Y109.139 E.08762
G1 X101.084 Y109.139 F36000
G1 F3672
G1 X102.513 Y109.139 E.04156
G1 X109.138 Y107.364 E.19958
G1 X109.138 Y107.714 E.01019
G1 X100.859 Y99.435 E.34068
G1 X100.859 Y98.492 E.02744
G1 X109.138 Y96.274 E.24939
G1 X109.138 Y97.702 E.04156
G1 X109.138 Y91.797 F36000
G1 F3672
G1 X109.138 Y90.861 E.02725
G1 X108.646 Y90.861 E.01431
G1 X100.859 Y92.947 E.23458
G1 X100.859 Y91.861 E.03161
G1 X109.138 Y100.139 E.34068
G1 X109.138 Y101.819 E.04887
G1 X100.859 Y104.037 E.24939
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X102.791 Y103.52 E-.76
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X95.159 Y103.417 Z4.4 F36000
G1 X94.346 Y103.406 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F3672
G1 X94.682 Y103.372 E.00983
G1 X95.336 Y103.17 E.01994
G1 X95.938 Y102.842 E.01993
G1 X96.465 Y102.4 E.02003
G1 X96.843 Y101.936 E.01742
G1 X97.135 Y101.418 E.0173
G1 X97.354 Y100.766 E.02001
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.679 Y96.627 E.02001
G1 X94.083 Y96.561 E.01744
G1 X93.49 Y96.597 E.0173
G1 X92.823 Y96.767 E.02001
G1 X92.206 Y97.065 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01992
G1 X92.062 Y102.843 E.01994
G1 X92.664 Y103.17 E.01993
G1 X93.318 Y103.372 E.01993
G1 X94 Y103.44 E.01994
G1 X94.286 Y103.412 E.00836
M204 S250
G1 X94.381 Y103.761 F36000
; FEATURE: Outer wall
G1 F3672
M204 S6000
G1 X94.753 Y103.724 E.01086
G1 X95.476 Y103.501 E.02202
G1 X96.14 Y103.139 E.02201
G1 X96.721 Y102.652 E.02205
G1 X97.139 Y102.138 E.0193
G1 X97.463 Y101.563 E.01917
G1 X97.704 Y100.846 E.02204
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.348 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02203
G1 X94.092 Y96.203 E.01932
G1 X93.435 Y96.243 E.01917
G1 X92.701 Y96.43 E.02204
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.022
G1 X91.28 Y102.652 E.022
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.247 Y103.724 E.02201
G1 X94 Y103.799 E.02202
G1 X94.322 Y103.767 E.0094
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.753 Y103.724 E-.1647
G1 X95.476 Y103.501 E-.28753
G1 X96.14 Y103.139 E-.28739
G1 X96.181 Y103.104 E-.02039
; WIPE_END
G1 E-.04 F1800
G1 X91.494 Y101.861 Z4.4 F36000
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
M73 P57 R1
G1 F3672
G1 X91.366 Y101.701 E.00597
G1 X91.082 Y101.146 E.01816
G1 X90.919 Y100.569 E.01744
G1 X91.609 Y97.994 E.07755
G1 X91.575 Y98.033 E.00148
G1 X95.124 Y97.082 E.10689
G1 X95.063 Y97.063 E.00184
G1 X96.944 Y98.943 E.07737
G1 X96.921 Y98.864 E.00239
G1 X95.968 Y102.421 E.10713
G1 X96.003 Y102.391 E.00133
G1 X93.438 Y103.079 E.07729
G1 X93.512 Y103.086 E.00216
G1 X90.908 Y100.483 E.10714
G1 X90.886 Y100.196 E.00837
; CHANGE_LAYER
; Z_HEIGHT: 4.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X90.908 Y100.483 E-.10929
G1 X92.119 Y101.693 E-.65071
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z4.4 I-.497 J1.111 P1  F36000
G1 X109.442 Y109.443 Z4.4
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F4152
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F4152
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 21 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer21 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
M73 P58 R1
G1 X105.116 Y108.782 F36000
G1 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F4152
G1 X108.781 Y95.105 E.41203
G1 X108.781 Y92.007 E.09012
G1 X107.991 Y91.218 E.0325
G1 X107.86 Y91.218 E.00383
G1 X101.216 Y92.998 E.20012
G1 X101.216 Y92.018 E.02852
G1 X108.781 Y99.582 E.31128
G1 X108.781 Y102.061 E.07213
G1 X101.216 Y104.088 E.22787
G1 X101.216 Y102.641 E.0421
G1 X104.277 Y91.218 E.34411
G1 X102.849 Y91.218 E.04156
G1 X109.111 Y91.039 F36000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.383074
G1 F4152
G1 X109.085 Y90.913 E.00356
G1 X108.96 Y90.887 E.00356
G1 X101.038 Y90.887 E.21957
G1 X100.912 Y90.913 E.00356
G1 X100.886 Y91.039 E.00356
G1 X100.886 Y108.961 E.49675
G1 X100.912 Y109.087 E.00356
G1 X101.038 Y109.113 E.00356
G1 X108.96 Y109.113 E.21957
G1 X109.085 Y109.087 E.00356
G1 X109.111 Y108.961 E.00356
G1 X109.111 Y91.099 E.49509
G1 X108.781 Y97.944 F36000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F4152
G1 X108.781 Y96.516 E.04156
G1 X101.216 Y98.543 E.22787
G1 X101.216 Y99.593 E.03054
G1 X108.781 Y107.157 E.31128
G1 X108.781 Y107.606 E.01307
G1 X104.392 Y108.782 E.13221
G1 X102.831 Y108.782 E.04541
M73 P59 R1
G1 X101.216 Y107.167 E.06645
G1 X101.216 Y108.596 E.04156
; OBJECT_ID: 12
; WIPE_START
G1 F10081.784
G1 X101.216 Y107.167 E-.54276
G1 X101.621 Y107.572 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X94.996 Y103.781 Z4.6 F36000
G1 X94.348 Y103.41 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F4152
G1 X94.513 Y103.402 E.0048
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
G1 X96.793 Y102.008 E.01994
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01993
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.134 E.01992
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.679 Y96.627 E.02001
G1 X94.088 Y96.561 E.01731
G1 X93.49 Y96.598 E.01744
G1 X92.823 Y96.767 E.02001
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01994
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01993
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.111 Y101.869 E.02001
G1 X91.48 Y102.341 E.01743
G1 X91.92 Y102.741 E.0173
G1 X92.507 Y103.1 E.02002
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
G1 X94.288 Y103.413 E.01339
M204 S250
G1 X94.366 Y103.767 F36000
; FEATURE: Outer wall
G1 F4152
M204 S6000
G1 X94.566 Y103.757 E.00584
G1 X95.299 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02201
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.022
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02204
G1 X94.097 Y96.203 E.01918
G1 X93.434 Y96.243 E.01931
G1 X92.701 Y96.43 E.02203
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02202
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02201
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.062 E.02203
G1 X91.217 Y102.585 E.01931
G1 X91.705 Y103.028 E.01917
G1 X92.352 Y103.423 E.02204
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.306 Y103.77 E.01443
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.09909
G1 X95.299 Y103.57 E-.28742
G1 X95.981 Y103.242 E-.28739
G1 X96.161 Y103.105 E-.08611
; WIPE_END
G1 E-.04 F1800
G1 X97.132 Y100.055 Z4.6 F36000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F4152
G1 X97.088 Y99.456 E.01748
G1 X96.918 Y98.854 E.01818
G1 X96.826 Y98.674 E.0059
G1 X95.784 Y102.562 E.11713
G1 X95.635 Y102.675 E.00545
G1 X95.072 Y102.946 E.01816
G1 X94.468 Y103.1 E.01816
G1 X93.844 Y103.131 E.01817
G1 X93.741 Y103.116 E.00303
G1 X90.892 Y100.266 E.11725
G1 X90.866 Y99.922 E.01005
G1 X90.943 Y99.302 E.01817
G1 X91.142 Y98.711 E.01816
G1 X91.426 Y98.219 E.01651
G1 X95.331 Y97.173 E.11764
G1 X95.218 Y97.111 E.00376
G1 X94.617 Y96.926 E.0183
G1 X94.08 Y96.866 E.01571
G1 X93.95 Y96.874 E.00379
; CHANGE_LAYER
; Z_HEIGHT: 4.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X94.08 Y96.866 E-.04953
G1 X94.617 Y96.926 E-.20519
G1 X95.218 Y97.111 E-.23895
G1 X95.331 Y97.173 E-.0491
G1 X94.779 Y97.321 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
M106 S242.25
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z4.6 I-.775 J.938 P1  F36000
G1 X109.442 Y109.443 Z4.6
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F10082.057
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F10082.057
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 22 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer22 end: 8,12
M625
; WIPE_START
M204 S10000
M73 P60 R1
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X108.365 Y109.295 F36000
G1 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40914
; LAYER_HEIGHT: 0.4
M106 S255
G1 F3000
G1 X109.092 Y108.569 E.05504
G1 X109.092 Y107.92 E.03478
G1 X107.918 Y109.093 E.08889
G1 X107.269 Y109.093 E.03478
G1 X109.092 Y107.27 E.13808
G1 X109.092 Y106.621 E.03478
G1 X106.62 Y109.093 E.18727
G1 X105.97 Y109.093 E.03478
G1 X109.092 Y105.972 E.23646
G1 X109.092 Y105.322 E.03478
G1 X105.321 Y109.093 E.28564
G1 X104.672 Y109.093 E.03478
G1 X109.092 Y104.673 E.33483
G1 X109.092 Y104.024 E.03478
G1 X104.022 Y109.093 E.38402
G1 X103.373 Y109.093 E.03478
G1 X109.092 Y103.374 E.43321
G1 X109.092 Y102.725 E.03478
G1 X102.724 Y109.093 E.4824
G1 X102.074 Y109.093 E.03478
G1 X109.092 Y102.076 E.53159
G1 X109.092 Y101.426 E.03478
G1 X101.425 Y109.093 E.58078
G1 X100.906 Y109.093 E.02782
G1 X100.906 Y108.963 E.00696
G1 X109.092 Y100.777 E.62012
G1 X109.092 Y100.128 E.03478
G1 X100.906 Y108.314 E.62012
G1 X100.906 Y107.664 E.03478
M73 P61 R1
G1 X109.092 Y99.478 E.62012
G1 X109.092 Y98.829 E.03478
G1 X100.906 Y107.015 E.62012
G1 X100.906 Y106.366 E.03478
G1 X109.092 Y98.18 E.62012
G1 X109.092 Y97.53 E.03478
G1 X100.906 Y105.716 E.62012
G1 X100.906 Y105.067 E.03478
G1 X109.092 Y96.881 E.62012
G1 X109.092 Y96.232 E.03478
G1 X100.906 Y104.418 E.62012
G1 X100.906 Y103.768 E.03478
G1 X109.092 Y95.582 E.62012
G1 X109.092 Y94.933 E.03478
G1 X100.906 Y103.119 E.62012
G1 X100.906 Y102.47 E.03478
G1 X109.092 Y94.284 E.62012
G1 X109.092 Y93.634 E.03478
G1 X100.906 Y101.82 E.62012
G1 X100.906 Y101.171 E.03478
M73 P62 R1
G1 X109.092 Y92.985 E.62012
G1 X109.092 Y92.336 E.03478
G1 X100.906 Y100.522 E.62012
G1 X100.906 Y99.872 E.03478
G1 X109.092 Y91.687 E.62012
G1 X109.092 Y91.037 E.03478
G1 X100.906 Y99.223 E.62012
G1 X100.906 Y98.574 E.03478
G1 X108.573 Y90.907 E.58079
G1 X107.923 Y90.907 E.03478
G1 X100.906 Y97.925 E.53161
G1 X100.906 Y97.275 E.03478
G1 X107.274 Y90.907 E.48242
G1 X106.625 Y90.907 E.03478
G1 X100.906 Y96.626 E.43323
G1 X100.906 Y95.977 E.03478
G1 X105.975 Y90.907 E.38404
G1 X105.326 Y90.907 E.03478
G1 X100.906 Y95.327 E.33485
G1 X100.906 Y94.678 E.03478
G1 X104.677 Y90.907 E.28566
G1 X104.027 Y90.907 E.03478
M73 P63 R1
G1 X100.906 Y94.029 E.23647
G1 X100.906 Y93.379 E.03478
G1 X103.378 Y90.907 E.18728
G1 X102.729 Y90.907 E.03478
G1 X100.906 Y92.73 E.13809
G1 X100.906 Y92.081 E.03478
G1 X102.079 Y90.907 E.0889
G1 X101.43 Y90.907 E.03478
G1 X100.703 Y91.634 E.05505
M106 S242.25
; OBJECT_ID: 12
; WIPE_START
G1 X101.43 Y90.907 E-.39056
G1 X102.079 Y90.907 E-.24674
G1 X101.851 Y91.135 E-.1227
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X97.865 Y97.644 Z4.8 F36000
G1 X94.332 Y103.411 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F10082.057
G1 X94.513 Y103.402 E.00526
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.935 E.01993
G1 X96.34 Y102.522 E.01993
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01994
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.158 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.679 Y96.627 E.02002
G1 X94.093 Y96.562 E.01716
G1 X93.49 Y96.598 E.01757
G1 X92.823 Y96.767 E.02001
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.111 Y101.869 E.02
G1 X91.483 Y102.345 E.01757
G1 X91.92 Y102.741 E.01715
G1 X92.507 Y103.099 E.02002
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
G1 X94.273 Y103.414 E.01293
M204 S250
G1 X94.35 Y103.767 F36000
; FEATURE: Outer wall
G1 F10082.057
M204 S6000
G1 X94.566 Y103.757 E.0063
G1 X95.3 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02201
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02201
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.022
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02204
G1 X94.102 Y96.203 E.01903
G1 X93.434 Y96.243 E.01945
G1 X92.701 Y96.43 E.02204
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02201
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.062 E.02203
G1 X91.221 Y102.589 E.01945
G1 X91.705 Y103.028 E.01902
G1 X92.352 Y103.423 E.02204
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.29 Y103.77 E.01397
; WIPE_START
M204 S10000
G1 X94.566 Y103.757 E-.10507
G1 X95.3 Y103.57 E-.28745
G1 X95.981 Y103.242 E-.28746
G1 X96.149 Y103.114 E-.08002
; WIPE_END
G1 E-.04 F1800
G1 X97.117 Y99.845 Z4.8 F36000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F10081.784
G1 X97.088 Y99.456 E.01135
G1 X96.918 Y98.854 E.01818
G1 X96.73 Y98.486 E.01203
G1 X95.603 Y102.69 E.12664
G1 X95.072 Y102.946 E.01714
G1 X94.467 Y103.1 E.01817
G1 X93.951 Y103.126 E.01504
G1 X90.875 Y100.05 E.12657
G1 X90.866 Y99.922 E.00374
G1 X90.943 Y99.302 E.01817
G1 X91.142 Y98.711 E.01816
G1 X91.326 Y98.392 E.01069
G1 X95.511 Y97.271 E.12609
G1 X95.218 Y97.111 E.00973
G1 X94.617 Y96.926 E.01831
G1 X94.155 Y96.874 E.01352
; CHANGE_LAYER
; Z_HEIGHT: 4.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X94.617 Y96.926 E-.17662
G1 X95.218 Y97.111 E-.23908
G1 X95.511 Y97.271 E-.12706
G1 X94.959 Y97.419 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
M106 S252.45
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z4.8 I-.777 J.936 P1  F36000
G1 X109.442 Y109.443 Z4.8
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F7993
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F7993
M204 S6000
M73 P64 R1
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 23 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer23 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X101.421 Y109.3 F36000
G1 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40003
G1 F7993
G1 X100.859 Y108.739 E.0231
G1 X100.859 Y108.234 E.0147
G1 X101.765 Y109.139 E.03727
G1 X102.27 Y109.139 E.0147
G1 X100.859 Y107.729 E.05806
G1 X100.859 Y107.224 E.0147
G1 X102.775 Y109.139 E.07884
G1 X103.28 Y109.139 E.0147
G1 X100.859 Y106.719 E.09963
G1 X100.859 Y106.214 E.0147
G1 X103.785 Y109.139 E.12041
G1 X104.29 Y109.139 E.0147
G1 X100.859 Y105.709 E.14119
G1 X100.859 Y105.204 E.0147
G1 X104.795 Y109.139 E.16198
G1 X105.3 Y109.139 E.0147
G1 X100.859 Y104.699 E.18276
G1 X100.859 Y104.193 E.0147
G1 X105.805 Y109.139 E.20354
G1 X106.31 Y109.139 E.0147
G1 X100.859 Y103.688 E.22433
G1 X100.859 Y103.183 E.0147
G1 X106.815 Y109.139 E.24511
G1 X107.32 Y109.139 E.0147
G1 X100.859 Y102.678 E.2659
G1 X100.859 Y102.173 E.0147
G1 X107.825 Y109.139 E.28668
G1 X108.33 Y109.139 E.0147
G1 X100.859 Y101.668 E.30746
G1 X100.859 Y101.163 E.0147
G1 X108.835 Y109.139 E.32825
G1 X109.138 Y109.139 E.00881
G1 X109.138 Y108.937 E.00589
G1 X100.859 Y100.658 E.34071
G1 X100.859 Y100.153 E.0147
G1 X109.138 Y108.432 E.34071
G1 X109.138 Y107.927 E.0147
G1 X100.859 Y99.648 E.34071
G1 X100.859 Y99.143 E.0147
G1 X109.138 Y107.422 E.34071
G1 X109.138 Y106.917 E.0147
G1 X100.859 Y98.638 E.34071
G1 X100.859 Y98.133 E.0147
G1 X109.138 Y106.412 E.34071
G1 X109.138 Y105.907 E.0147
M73 P65 R1
G1 X100.859 Y97.628 E.34071
G1 X100.859 Y97.123 E.0147
G1 X109.138 Y105.402 E.34071
G1 X109.138 Y104.897 E.0147
G1 X100.859 Y96.618 E.34071
G1 X100.859 Y96.113 E.0147
G1 X109.138 Y104.392 E.34071
G1 X109.138 Y103.887 E.0147
G1 X100.859 Y95.608 E.34071
G1 X100.859 Y95.103 E.0147
G1 X109.138 Y103.382 E.34071
G1 X109.138 Y102.877 E.0147
G1 X100.859 Y94.598 E.34071
G1 X100.859 Y94.093 E.0147
G1 X109.138 Y102.372 E.34071
G1 X109.138 Y101.867 E.0147
G1 X100.859 Y93.588 E.34071
G1 X100.859 Y93.083 E.0147
G1 X109.138 Y101.362 E.34071
G1 X109.138 Y100.857 E.0147
G1 X100.859 Y92.578 E.34071
G1 X100.859 Y92.073 E.0147
G1 X109.138 Y100.352 E.34071
G1 X109.138 Y99.847 E.0147
G1 X100.859 Y91.568 E.34071
G1 X100.859 Y91.063 E.0147
G1 X109.138 Y99.342 E.34071
G1 X109.138 Y98.837 E.0147
G1 X101.162 Y90.861 E.32824
G1 X101.667 Y90.861 E.0147
G1 X109.138 Y98.332 E.30746
G1 X109.138 Y97.827 E.0147
G1 X102.172 Y90.861 E.28667
G1 X102.677 Y90.861 E.0147
G1 X109.138 Y97.321 E.26589
G1 X109.138 Y96.816 E.0147
G1 X103.182 Y90.861 E.24511
G1 X103.687 Y90.861 E.0147
G1 X109.138 Y96.311 E.22432
G1 X109.138 Y95.806 E.0147
G1 X104.192 Y90.861 E.20354
G1 X104.697 Y90.861 E.0147
G1 X109.138 Y95.301 E.18275
G1 X109.138 Y94.796 E.0147
G1 X105.202 Y90.861 E.16197
G1 X105.707 Y90.861 E.0147
M73 P66 R1
G1 X109.138 Y94.291 E.14119
G1 X109.138 Y93.786 E.0147
G1 X106.212 Y90.861 E.1204
G1 X106.718 Y90.861 E.0147
G1 X109.138 Y93.281 E.09962
G1 X109.138 Y92.776 E.0147
G1 X107.223 Y90.861 E.07884
G1 X107.728 Y90.861 E.0147
G1 X109.138 Y92.271 E.05805
G1 X109.138 Y91.766 E.0147
G1 X108.233 Y90.861 E.03727
G1 X108.738 Y90.861 E.0147
G1 X109.299 Y91.422 E.0231
; OBJECT_ID: 12
; WIPE_START
G1 F10080.927
G1 X108.738 Y90.861 E-.30161
G1 X108.233 Y90.861 E-.19191
G1 X108.728 Y91.356 E-.26648
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X102.874 Y96.253 Z5 F36000
G1 X94.317 Y103.412 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F7993
G1 X94.513 Y103.402 E.00572
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01993
G1 X96.793 Y102.008 E.01994
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01993
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.134 E.01992
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.679 Y96.627 E.02002
G1 X94.097 Y96.562 E.01703
G1 X93.489 Y96.598 E.01771
G1 X92.823 Y96.767 E.02
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01994
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01993
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.111 Y101.869 E.01999
G1 X91.486 Y102.348 E.01771
G1 X91.92 Y102.741 E.01702
G1 X92.507 Y103.1 E.02003
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
G1 X94.257 Y103.415 E.01247
M204 S250
G1 X94.335 Y103.768 F36000
; FEATURE: Outer wall
G1 F7993
M204 S6000
G1 X94.566 Y103.757 E.00676
G1 X95.3 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02201
G1 X97.085 Y102.217 E.02202
G1 X97.463 Y101.563 E.022
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02201
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.022
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02204
G1 X94.107 Y96.203 E.01889
G1 X93.434 Y96.243 E.0196
G1 X92.701 Y96.43 E.02203
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02201
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.062 E.02203
G1 X91.224 Y102.592 E.01959
G1 X91.705 Y103.028 E.01889
G1 X92.352 Y103.423 E.02205
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.275 Y103.771 E.01351
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.11103
G1 X95.3 Y103.57 E-.28745
G1 X95.981 Y103.242 E-.28743
G1 X96.136 Y103.124 E-.07409
; WIPE_END
G1 E-.04 F1800
G1 X92.751 Y102.865 Z5 F36000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F7993
G1 X93.227 Y103.038 E.01472
G1 X93.844 Y103.131 E.01816
G1 X94.142 Y103.116 E.00868
G1 X90.875 Y99.85 E.13443
G1 X90.943 Y99.302 E.01605
G1 X91.142 Y98.711 E.01816
G1 X91.226 Y98.566 E.00487
G1 X95.692 Y97.369 E.13453
G1 X95.766 Y97.409 E.00246
G1 X96.245 Y97.811 E.01818
G1 X96.634 Y98.299 E.01815
G1 X95.435 Y102.771 E.13473
G1 X95.635 Y102.675 E.00645
G1 X96.133 Y102.298 E.01817
G1 X96.518 Y101.862 E.01694
; CHANGE_LAYER
; Z_HEIGHT: 4.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X96.133 Y102.298 E-.22127
G1 X95.635 Y102.675 E-.23726
G1 X95.435 Y102.771 E-.08424
G1 X95.583 Y102.219 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z5 I-.563 J1.079 P1  F36000
G1 X109.442 Y109.443 Z5
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F7951
G1 X109.442 Y95 E.42024
G1 X109.442 Y90.557 E.12927
G1 X100.556 Y90.557 E.25855
G1 X100.556 Y109.443 E.54952
G1 X109.382 Y109.443 E.2568
M204 S250
G1 X109.799 Y109.8 F36000
; FEATURE: Outer wall
G1 F7951
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
M73 P67 R1
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 24 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer24 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X108.577 Y109.3 F36000
G1 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40003
G1 F7951
G1 X109.138 Y108.739 E.0231
G1 X109.138 Y108.234 E.0147
G1 X108.233 Y109.139 E.03727
G1 X107.728 Y109.139 E.0147
G1 X109.138 Y107.729 E.05805
G1 X109.138 Y107.224 E.0147
G1 X107.223 Y109.139 E.07884
G1 X106.718 Y109.139 E.0147
G1 X109.138 Y106.719 E.09962
G1 X109.138 Y106.214 E.0147
G1 X106.212 Y109.139 E.1204
G1 X105.707 Y109.139 E.0147
G1 X109.138 Y105.709 E.14119
G1 X109.138 Y105.204 E.0147
G1 X105.202 Y109.139 E.16197
G1 X104.697 Y109.139 E.0147
G1 X109.138 Y104.699 E.18275
G1 X109.138 Y104.194 E.0147
G1 X104.192 Y109.139 E.20354
G1 X103.687 Y109.139 E.0147
G1 X109.138 Y103.689 E.22432
G1 X109.138 Y103.184 E.0147
G1 X103.182 Y109.139 E.24511
G1 X102.677 Y109.139 E.0147
G1 X109.138 Y102.679 E.26589
G1 X109.138 Y102.174 E.0147
G1 X102.172 Y109.139 E.28667
G1 X101.667 Y109.139 E.0147
G1 X109.138 Y101.668 E.30746
G1 X109.138 Y101.163 E.0147
G1 X101.162 Y109.139 E.32824
G1 X100.859 Y109.139 E.00881
G1 X100.859 Y108.937 E.00588
G1 X109.138 Y100.658 E.34071
G1 X109.138 Y100.153 E.0147
G1 X100.859 Y108.432 E.34071
G1 X100.859 Y107.927 E.0147
G1 X109.138 Y99.648 E.34071
G1 X109.138 Y99.143 E.0147
G1 X100.859 Y107.422 E.34071
G1 X100.859 Y106.917 E.0147
G1 X109.138 Y98.638 E.34071
G1 X109.138 Y98.133 E.0147
G1 X100.859 Y106.412 E.34071
G1 X100.859 Y105.907 E.0147
M73 P68 R1
G1 X109.138 Y97.628 E.34071
G1 X109.138 Y97.123 E.0147
G1 X100.859 Y105.402 E.34071
G1 X100.859 Y104.897 E.0147
G1 X109.138 Y96.618 E.34071
G1 X109.138 Y96.113 E.0147
G1 X100.859 Y104.392 E.34071
G1 X100.859 Y103.887 E.0147
G1 X109.138 Y95.608 E.3407
G1 X109.138 Y95.103 E.0147
G1 X100.859 Y103.382 E.3407
G1 X100.859 Y102.877 E.0147
G1 X109.138 Y94.598 E.3407
G1 X109.138 Y94.093 E.0147
G1 X100.859 Y102.372 E.3407
G1 X100.859 Y101.867 E.0147
G1 X109.138 Y93.588 E.3407
G1 X109.138 Y93.083 E.0147
G1 X100.859 Y101.362 E.3407
G1 X100.859 Y100.857 E.0147
G1 X109.138 Y92.578 E.3407
G1 X109.138 Y92.073 E.0147
G1 X100.859 Y100.352 E.3407
G1 X100.859 Y99.847 E.0147
G1 X109.138 Y91.568 E.34071
G1 X109.138 Y91.063 E.0147
G1 X100.859 Y99.342 E.34071
G1 X100.859 Y98.837 E.0147
G1 X108.835 Y90.861 E.32825
G1 X108.33 Y90.861 E.0147
G1 X100.859 Y98.332 E.30746
G1 X100.859 Y97.827 E.0147
G1 X107.825 Y90.861 E.28668
G1 X107.32 Y90.861 E.0147
G1 X100.859 Y97.322 E.2659
G1 X100.859 Y96.817 E.0147
G1 X106.815 Y90.861 E.24511
G1 X106.31 Y90.861 E.0147
G1 X100.859 Y96.312 E.22433
G1 X100.859 Y95.807 E.0147
G1 X105.805 Y90.861 E.20354
G1 X105.3 Y90.861 E.0147
G1 X100.859 Y95.302 E.18276
G1 X100.859 Y94.796 E.0147
G1 X104.795 Y90.861 E.16198
G1 X104.29 Y90.861 E.0147
G1 X100.859 Y94.291 E.14119
G1 X100.859 Y93.786 E.0147
M73 P69 R1
G1 X103.785 Y90.861 E.12041
G1 X103.28 Y90.861 E.0147
G1 X100.859 Y93.281 E.09963
G1 X100.859 Y92.776 E.0147
G1 X102.775 Y90.861 E.07884
G1 X102.27 Y90.861 E.0147
G1 X100.859 Y92.271 E.05806
G1 X100.859 Y91.766 E.0147
G1 X101.765 Y90.861 E.03727
G1 X101.26 Y90.861 E.0147
G1 X100.699 Y91.422 E.0231
; OBJECT_ID: 12
; WIPE_START
G1 F10080.927
G1 X101.26 Y90.861 E-.30169
G1 X101.765 Y90.861 E-.19191
G1 X101.269 Y91.356 E-.2664
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X97.45 Y97.964 Z5.2 F36000
G1 X94.301 Y103.412 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F7951
G1 X94.513 Y103.402 E.00617
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01994
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01993
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.134 E.01992
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.158 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.678 Y96.627 E.02003
G1 X94.102 Y96.562 E.01688
G1 X93.489 Y96.598 E.01785
G1 X92.823 Y96.767 E.02
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01993
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.111 Y101.869 E.01999
G1 X91.49 Y102.352 E.01785
G1 X91.92 Y102.74 E.01687
G1 X92.507 Y103.1 E.02004
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
G1 X94.241 Y103.415 E.01202
M204 S250
G1 X94.319 Y103.769 F36000
; FEATURE: Outer wall
G1 F7951
M204 S6000
G1 X94.566 Y103.757 E.00721
G1 X95.299 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02201
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02201
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.341 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.022
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02205
G1 X94.111 Y96.204 E.01875
G1 X93.434 Y96.243 E.01974
G1 X92.701 Y96.43 E.02203
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02201
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.062 E.02203
G1 X91.227 Y102.596 E.01974
G1 X91.705 Y103.028 E.01874
G1 X92.352 Y103.423 E.02205
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.259 Y103.772 E.01306
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.11697
G1 X95.299 Y103.57 E-.28742
G1 X95.981 Y103.242 E-.28746
G1 X96.124 Y103.133 E-.06816
; WIPE_END
G1 E-.04 F1800
G1 X92.93 Y102.931 Z5.2 F36000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F7951
G1 X93.227 Y103.038 E.00917
G1 X93.844 Y103.131 E.01816
G1 X94.332 Y103.107 E.01423
G1 X90.897 Y99.672 E.14135
G1 X90.943 Y99.302 E.01084
G1 X91.133 Y98.737 E.01736
G1 X95.844 Y97.475 E.14189
G1 X96.245 Y97.811 E.01522
G1 X96.524 Y98.161 E.01304
G1 X95.267 Y102.852 E.14131
G1 X95.635 Y102.675 E.01188
G1 X96.133 Y102.298 E.01817
G1 X96.394 Y102.002 E.01151
; CHANGE_LAYER
; Z_HEIGHT: 5
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X96.133 Y102.298 E-.15037
G1 X95.635 Y102.675 E-.23727
G1 X95.267 Y102.852 E-.15513
G1 X95.415 Y102.3 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 8
; start printing object, unique label id: 8
M624 AQAAAAAAAAA=
G17
G3 Z5.2 I-.563 J1.079 P1  F36000
G1 X109.799 Y109.8 Z5.2
G1 Z5
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F7902
M204 S6000
G1 X109.799 Y95 E.43063
G1 X109.799 Y90.2 E.13966
G1 X100.199 Y90.2 E.27933
G1 X100.199 Y109.8 E.5703
G1 X109.739 Y109.8 E.27758
; object ids of layer 25 start: 8,12
M624 AwAAAAAAAAA=
; object ids of this layer25 end: 8,12
M625
; WIPE_START
G1 F10082.057
M204 S10000
G1 X109.747 Y107.8 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X101.075 Y109.657 F36000
G1 Z5.4
M73 P70 R1
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.40531
G1 F7902
M204 S2000
G1 X100.502 Y109.085 E.02391
G1 X100.502 Y108.572 E.01513
G1 X101.427 Y109.497 E.03861
G1 X101.939 Y109.497 E.01513
G1 X100.502 Y108.06 E.06001
G1 X100.502 Y107.547 E.01513
G1 X102.452 Y109.497 E.08141
G1 X102.964 Y109.497 E.01513
G1 X100.502 Y107.035 E.10282
G1 X100.502 Y106.522 E.01513
G1 X103.477 Y109.497 E.12422
G1 X103.989 Y109.497 E.01513
G1 X100.502 Y106.01 E.14562
G1 X100.502 Y105.497 E.01513
G1 X104.502 Y109.497 E.16702
G1 X105.014 Y109.497 E.01513
G1 X100.502 Y104.985 E.18843
G1 X100.502 Y104.472 E.01513
G1 X105.527 Y109.497 E.20983
G1 X106.039 Y109.497 E.01513
G1 X100.502 Y103.96 E.23123
G1 X100.502 Y103.447 E.01513
G1 X106.552 Y109.497 E.25264
G1 X107.064 Y109.497 E.01513
G1 X100.502 Y102.935 E.27404
G1 X100.502 Y102.422 E.01513
G1 X107.577 Y109.497 E.29544
G1 X108.089 Y109.497 E.01513
G1 X100.502 Y101.91 E.31684
G1 X100.502 Y101.397 E.01513
G1 X108.602 Y109.497 E.33825
G1 X109.114 Y109.497 E.01513
G1 X100.502 Y100.885 E.35965
G1 X100.502 Y100.372 E.01513
G1 X109.495 Y109.365 E.37557
G1 X109.495 Y108.853 E.01513
G1 X100.502 Y99.86 E.37557
G1 X100.502 Y99.347 E.01513
M73 P71 R1
G1 X109.495 Y108.34 E.37557
G1 X109.495 Y107.828 E.01513
G1 X100.502 Y98.835 E.37557
G1 X100.502 Y98.322 E.01513
G1 X109.495 Y107.315 E.37557
G1 X109.495 Y106.803 E.01513
G1 X100.502 Y97.81 E.37557
G1 X100.502 Y97.297 E.01513
G1 X109.495 Y106.29 E.37557
G1 X109.495 Y105.778 E.01513
G1 X100.502 Y96.785 E.37557
G1 X100.502 Y96.272 E.01513
G1 X109.495 Y105.265 E.37557
G1 X109.495 Y104.753 E.01513
G1 X100.502 Y95.76 E.37557
G1 X100.502 Y95.247 E.01513
G1 X109.495 Y104.24 E.37557
G1 X109.495 Y103.728 E.01513
G1 X100.502 Y94.735 E.37557
G1 X100.502 Y94.222 E.01513
G1 X109.495 Y103.215 E.37557
G1 X109.495 Y102.703 E.01513
G1 X100.502 Y93.71 E.37557
G1 X100.502 Y93.197 E.01513
G1 X109.495 Y102.19 E.37557
G1 X109.495 Y101.678 E.01513
M73 P72 R1
G1 X100.502 Y92.685 E.37557
G1 X100.502 Y92.172 E.01513
G1 X109.495 Y101.165 E.37557
G1 X109.495 Y100.653 E.01513
G1 X100.502 Y91.66 E.37557
G1 X100.502 Y91.147 E.01513
G1 X109.495 Y100.14 E.37557
G1 X109.495 Y99.628 E.01513
G1 X100.502 Y90.635 E.37557
G1 X100.502 Y90.503 E.00387
G1 X100.884 Y90.503 E.01126
G1 X109.495 Y99.115 E.35964
G1 X109.495 Y98.603 E.01513
G1 X101.396 Y90.503 E.33824
G1 X101.909 Y90.503 E.01513
G1 X109.495 Y98.09 E.31684
G1 X109.495 Y97.578 E.01513
G1 X102.421 Y90.503 E.29543
G1 X102.934 Y90.503 E.01513
G1 X109.495 Y97.065 E.27403
G1 X109.495 Y96.553 E.01513
G1 X103.446 Y90.503 E.25263
G1 X103.959 Y90.503 E.01513
G1 X109.495 Y96.04 E.23122
G1 X109.495 Y95.528 E.01513
G1 X104.471 Y90.503 E.20982
G1 X104.984 Y90.503 E.01513
G1 X109.495 Y95.015 E.18842
G1 X109.495 Y94.503 E.01513
G1 X105.496 Y90.503 E.16702
G1 X106.009 Y90.503 E.01513
G1 X109.495 Y93.99 E.14561
M73 P73 R1
G1 X109.495 Y93.478 E.01513
G1 X106.521 Y90.503 E.12421
G1 X107.034 Y90.503 E.01513
G1 X109.495 Y92.965 E.10281
G1 X109.495 Y92.453 E.01513
G1 X107.546 Y90.503 E.0814
G1 X108.059 Y90.503 E.01513
G1 X109.495 Y91.94 E.06
G1 X109.495 Y91.428 E.01513
G1 X108.571 Y90.503 E.0386
G1 X109.084 Y90.503 E.01513
G1 X109.656 Y91.076 E.02391
; OBJECT_ID: 12
; WIPE_START
G1 F9934.048
M204 S10000
G1 X109.084 Y90.503 E-.30762
G1 X108.571 Y90.503 E-.19475
G1 X109.05 Y90.983 E-.25762
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 8
M625
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G1 X103.212 Y95.898 Z5.4 F36000
G1 X94.286 Y103.413 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F7902
G1 X94.513 Y103.402 E.00662
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
G1 X96.793 Y102.008 E.01994
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01993
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.158 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.678 Y96.627 E.02003
G1 X94.106 Y96.562 E.01675
G1 X93.489 Y96.598 E.01799
G1 X92.823 Y96.767 E.01999
G1 X92.206 Y97.065 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01992
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01993
G1 X92.062 Y102.843 E.01994
G1 X92.664 Y103.17 E.01993
G1 X93.324 Y103.374 E.02012
G1 X93.822 Y103.436 E.01459
G1 X94.226 Y103.416 E.01176
M204 S250
G1 X94.303 Y103.77 F36000
; FEATURE: Outer wall
G1 F7902
M204 S6000
G1 X94.566 Y103.757 E.00766
G1 X95.3 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02201
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.022
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02204
G1 X94.116 Y96.204 E.01861
G1 X93.434 Y96.243 E.01988
G1 X92.701 Y96.43 E.02203
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.022
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.653 E.02201
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.249 Y103.724 E.02207
G1 X93.809 Y103.794 E.01641
G1 X94.244 Y103.773 E.01267
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.12287
G1 X95.3 Y103.57 E-.28745
G1 X95.981 Y103.242 E-.2874
G1 X96.112 Y103.143 E-.06228
; WIPE_END
G1 E-.04 F1800
G1 X97.041 Y99.29 Z5.4 F36000
G1 Z5
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F7902
G1 X96.918 Y98.854 E.01317
G1 X96.634 Y98.299 E.01816
G1 X96.414 Y98.024 E.01023
G1 X95.099 Y102.933 E.14789
G1 X94.514 Y103.088 E.01762
G1 X90.919 Y99.494 E.1479
G1 X90.943 Y99.302 E.00563
G1 X91.079 Y98.898 E.01242
G1 X95.976 Y97.586 E.14751
G1 X95.766 Y97.41 E.00797
G1 X95.218 Y97.111 E.01817
G1 X94.711 Y96.955 E.01542
; CHANGE_LAYER
; Z_HEIGHT: 5.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X95.218 Y97.111 E-.20141
G1 X95.766 Y97.41 E-.23724
G1 X95.976 Y97.586 E-.10411
G1 X95.424 Y97.734 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
M106 S255
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z5.4 I-1.193 J-.242 P1  F36000
G1 X94.27 Y103.414 Z5.4
G1 Z5.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1200
G1 X94.513 Y103.402 E.00707
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.935 E.01993
G1 X96.34 Y102.522 E.01993
; object ids of layer 26 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer26 end: 12
M625
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
M73 P74 R1
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.678 Y96.627 E.02004
G1 X94.111 Y96.562 E.01661
G1 X93.489 Y96.598 E.01813
G1 X92.823 Y96.767 E.01999
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01994
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01993
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.111 Y101.868 E.01999
G1 X91.496 Y102.358 E.01813
G1 X91.92 Y102.74 E.0166
G1 X92.507 Y103.1 E.02004
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
G1 X94.21 Y103.417 E.01112
M204 S250
G1 X94.288 Y103.771 F36000
; FEATURE: Outer wall
G1 F1200
M204 S6000
G1 X94.566 Y103.757 E.00811
G1 X95.299 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02201
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02201
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02204
G1 X94.121 Y96.204 E.01846
G1 X93.434 Y96.243 E.02002
G1 X92.701 Y96.43 E.02203
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02201
G1 X90.259 Y100.659 E.022
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.062 E.02203
G1 X91.234 Y102.603 E.02002
G1 X91.705 Y103.028 E.01846
G1 X92.352 Y103.423 E.02205
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.228 Y103.774 E.01216
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.12867
G1 X95.299 Y103.57 E-.28748
G1 X95.981 Y103.242 E-.28749
G1 X96.099 Y103.152 E-.05636
; WIPE_END
G1 E-.04 F1800
G1 X93.259 Y103.043 Z5.6 F36000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1200
G1 X93.844 Y103.131 E.01722
G1 X94.467 Y103.1 E.01816
G1 X94.673 Y103.048 E.00618
G1 X90.942 Y99.316 E.15355
G1 X91.025 Y99.059 E.00789
M73 P75 R1
G1 X96.108 Y97.697 E.15312
G1 X96.244 Y97.811 E.00517
G1 X96.305 Y97.887 E.00282
G1 X94.94 Y102.98 E.15343
G1 X95.072 Y102.946 E.00397
G1 X95.635 Y102.675 E.01817
G1 X96.161 Y102.266 E.0194
; CHANGE_LAYER
; Z_HEIGHT: 5.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X95.635 Y102.675 E-.25331
G1 X95.072 Y102.946 E-.23725
G1 X94.94 Y102.98 E-.0519
G1 X95.088 Y102.427 E-.21755
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z5.6 I-.93 J-.785 P1  F36000
G1 X94.255 Y103.415 Z5.6
G1 Z5.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1200
G1 X94.513 Y103.402 E.00751
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01992
G1 X96.34 Y102.522 E.01994
; object ids of layer 27 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer27 end: 12
M625
G1 X96.793 Y102.008 E.01993
M73 P75 R0
G1 X97.136 Y101.415 E.01994
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01993
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.678 Y96.627 E.02005
G1 X94.116 Y96.562 E.01646
G1 X93.489 Y96.598 E.01827
G1 X92.823 Y96.767 E.01999
G1 X92.206 Y97.064 E.01992
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.111 Y101.868 E.01998
G1 X91.499 Y102.362 E.01827
G1 X91.919 Y102.74 E.01645
G1 X92.507 Y103.099 E.02005
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
G1 X94.195 Y103.418 E.01067
M204 S250
G1 X94.273 Y103.771 F36000
; FEATURE: Outer wall
G1 F1200
M204 S6000
G1 X94.566 Y103.757 E.00855
G1 X95.3 Y103.57 E.02201
G1 X95.981 Y103.242 E.022
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02201
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.022
G1 X96.14 Y96.861 E.02202
M73 P76 R0
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02205
G1 X94.126 Y96.204 E.01832
G1 X93.434 Y96.243 E.02017
G1 X92.701 Y96.43 E.02203
G1 X92.019 Y96.758 E.022
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02201
G1 X90.259 Y100.66 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.062 E.02203
G1 X91.238 Y102.607 E.02017
G1 X91.705 Y103.028 E.0183
G1 X92.352 Y103.423 E.02205
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.213 Y103.774 E.01171
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.13452
G1 X95.3 Y103.57 E-.28745
G1 X95.981 Y103.242 E-.28736
G1 X96.087 Y103.161 E-.05067
; WIPE_END
G1 E-.04 F1800
G1 X96.966 Y99.023 Z5.8 F36000
G1 Z5.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1200
G1 X96.918 Y98.854 E.00509
G1 X96.634 Y98.299 E.01817
G1 X96.241 Y97.808 E.01831
G1 X90.971 Y99.219 E.15873
G1 X90.99 Y99.164 E.00169
G1 X94.832 Y103.007 E.15813
G1 X94.783 Y103.02 E.00149
G1 X96.191 Y97.766 E.15827
G1 X95.766 Y97.41 E.01613
G1 X95.218 Y97.111 E.01816
G1 X94.979 Y97.037 E.00727
; CHANGE_LAYER
; Z_HEIGHT: 5.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X95.218 Y97.111 E-.09489
G1 X95.766 Y97.41 E-.23721
G1 X96.191 Y97.766 E-.21066
G1 X96.043 Y98.318 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z5.8 I-1.147 J-.406 P1  F36000
G1 X94.24 Y103.415 Z5.8
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1200
G1 X94.513 Y103.402 E.00795
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
; object ids of layer 28 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer28 end: 12
M625
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
M73 P77 R0
G1 X96.89 Y98.133 E.01994
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.678 Y96.627 E.02005
G1 X94.12 Y96.562 E.01633
G1 X93.489 Y96.598 E.01841
G1 X92.823 Y96.767 E.01998
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01992
G1 X90.798 Y101.257 E.01994
G1 X91.111 Y101.868 E.01998
G1 X91.502 Y102.365 E.0184
G1 X91.919 Y102.74 E.01632
G1 X92.507 Y103.099 E.02005
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
G1 X94.18 Y103.418 E.01024
M204 S250
G1 X94.258 Y103.772 F36000
; FEATURE: Outer wall
G1 F1200
M204 S6000
G1 X94.566 Y103.757 E.00899
G1 X95.3 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.341 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02202
G1 X96.72 Y97.347 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02205
G1 X94.131 Y96.204 E.01818
G1 X93.434 Y96.243 E.02031
G1 X92.701 Y96.43 E.02202
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.022
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.062 E.02203
G1 X91.241 Y102.61 E.0203
G1 X91.705 Y103.028 E.01817
G1 X92.352 Y103.423 E.02205
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.198 Y103.775 E.01128
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.14025
G1 X95.3 Y103.57 E-.28745
G1 X95.981 Y103.242 E-.2874
G1 X96.075 Y103.17 E-.0449
; WIPE_END
G1 E-.04 F1800
G1 X93.211 Y103.033 Z6 F36000
G1 Z5.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1200
G1 X93.844 Y103.131 E.01863
G1 X94.467 Y103.1 E.01817
G1 X94.626 Y103.06 E.00475
G1 X96.071 Y97.666 E.1625
G1 X96.244 Y97.811 E.00658
M73 P78 R0
G1 X96.338 Y97.928 E.00436
G1 X90.934 Y99.376 E.16278
G1 X90.943 Y99.302 E.00216
G1 X91.04 Y99.015 E.00882
G1 X94.992 Y102.967 E.16262
G1 X95.073 Y102.946 E.00242
G1 X95.635 Y102.675 E.01816
G1 X96.133 Y102.298 E.01817
G1 X96.196 Y102.226 E.00281
; CHANGE_LAYER
; Z_HEIGHT: 5.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X96.133 Y102.298 E-.03668
G1 X95.635 Y102.675 E-.23729
G1 X95.073 Y102.946 E-.23715
G1 X94.992 Y102.967 E-.03164
G1 X94.588 Y102.562 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z6 I-1.12 J-.476 P1  F36000
G1 X94.225 Y103.416 Z6
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1200
G1 X94.513 Y103.402 E.00838
G1 X95.177 Y103.233 E.01994
G1 X95.794 Y102.936 E.01992
G1 X96.34 Y102.522 E.01994
; object ids of layer 29 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer29 end: 12
M625
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.678 Y96.627 E.02006
G1 X94.125 Y96.562 E.01618
G1 X93.489 Y96.598 E.01855
G1 X92.823 Y96.767 E.01998
G1 X92.206 Y97.064 E.01992
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.111 Y101.868 E.01998
G1 X91.505 Y102.369 E.01854
G1 X91.919 Y102.74 E.01618
G1 X92.507 Y103.099 E.02006
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
G1 X94.165 Y103.419 E.0098
M204 S250
G1 X94.243 Y103.773 F36000
; FEATURE: Outer wall
G1 F1200
M204 S6000
G1 X94.566 Y103.757 E.00942
G1 X95.3 Y103.57 E.02201
G1 X95.981 Y103.242 E.022
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.02201
M73 P79 R0
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02206
G1 X94.136 Y96.204 E.01803
G1 X93.434 Y96.243 E.02045
G1 X92.701 Y96.43 E.02203
G1 X92.019 Y96.758 E.022
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.66 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.062 E.02203
G1 X91.244 Y102.614 E.02045
G1 X91.705 Y103.028 E.01803
G1 X92.352 Y103.423 E.02205
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.183 Y103.776 E.01084
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.14585
G1 X95.3 Y103.57 E-.28751
G1 X95.981 Y103.242 E-.28736
G1 X96.063 Y103.179 E-.03928
; WIPE_END
G1 E-.04 F1800
G1 X93.059 Y102.977 Z6.2 F36000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1200
G1 X93.227 Y103.038 E.00519
G1 X93.844 Y103.131 E.01816
G1 X94.469 Y103.1 E.0182
G1 X95.952 Y97.565 E.16672
G1 X96.245 Y97.811 E.01112
G1 X96.434 Y98.049 E.00884
G1 X90.915 Y99.527 E.16625
G1 X90.943 Y99.302 E.0066
G1 X91.09 Y98.865 E.01342
G1 X95.139 Y102.914 E.16661
G1 X95.635 Y102.675 E.016
G1 X96.133 Y102.298 E.01817
G1 X96.3 Y102.108 E.00738
; CHANGE_LAYER
; Z_HEIGHT: 6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X96.133 Y102.298 E-.09643
G1 X95.635 Y102.675 E-.23734
G1 X95.139 Y102.914 E-.20899
G1 X94.735 Y102.51 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z6.2 I-1.054 J-.609 P1  F36000
G1 X94.211 Y103.417 Z6.2
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1200
G1 X94.513 Y103.402 E.00881
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
; object ids of layer 30 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer30 end: 12
M625
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
M73 P80 R0
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01995
G1 X95.336 Y96.83 E.01993
G1 X94.678 Y96.627 E.02006
G1 X94.13 Y96.562 E.01604
G1 X93.488 Y96.598 E.01869
G1 X92.823 Y96.767 E.01997
G1 X92.206 Y97.065 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.111 Y101.868 E.01998
G1 X91.509 Y102.372 E.01869
G1 X91.919 Y102.74 E.01603
G1 X92.507 Y103.1 E.02007
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
G1 X94.151 Y103.42 E.00938
M204 S250
G1 X94.228 Y103.774 F36000
; FEATURE: Outer wall
G1 F1200
M204 S6000
G1 X94.566 Y103.757 E.00985
G1 X95.3 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.348 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.752 Y96.276 E.02205
G1 X94.141 Y96.204 E.01789
G1 X93.434 Y96.243 E.0206
G1 X92.701 Y96.43 E.02202
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.66 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.062 E.02203
G1 X91.247 Y102.617 E.02059
G1 X91.705 Y103.028 E.01788
G1 X92.352 Y103.423 E.02206
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.168 Y103.776 E.01042
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.15146
G1 X95.3 Y103.57 E-.28745
G1 X95.981 Y103.242 E-.28742
G1 X96.052 Y103.188 E-.03367
; WIPE_END
G1 E-.04 F1800
G1 X91.064 Y101.083 Z6.4 F36000
G1 Z6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1200
G1 X90.912 Y100.544 E.01627
G1 X90.866 Y99.922 E.01816
G1 X90.896 Y99.679 E.00713
G1 X96.53 Y98.169 E.16972
G1 X96.245 Y97.811 E.01333
M73 P81 R0
G1 X95.832 Y97.465 E.01567
G1 X94.32 Y103.108 E.16998
G1 X94.467 Y103.1 E.00429
G1 X95.073 Y102.946 E.01817
G1 X95.274 Y102.849 E.00651
G1 X91.141 Y98.715 E.1701
G1 X91.454 Y98.17 E.01831
G1 X91.868 Y97.702 E.01817
G1 X92.007 Y97.596 E.00508
; CHANGE_LAYER
; Z_HEIGHT: 6.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X91.868 Y97.702 E-.06632
G1 X91.454 Y98.17 E-.23729
G1 X91.141 Y98.715 E-.23911
G1 X91.545 Y99.12 E-.21728
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z6.4 I-1.036 J.639 P1  F36000
G1 X94.196 Y103.418 Z6.4
G1 Z6.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1200
G1 X94.513 Y103.402 E.00923
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
; object ids of layer 31 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer31 end: 12
M625
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01995
G1 X95.336 Y96.83 E.01993
G1 X94.677 Y96.627 E.02007
G1 X94.134 Y96.563 E.0159
G1 X93.488 Y96.598 E.01883
G1 X92.823 Y96.767 E.01997
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01992
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01992
G1 X92.062 Y102.843 E.01995
G1 X92.664 Y103.17 E.01993
G1 X93.324 Y103.374 E.02012
G1 X93.822 Y103.436 E.01459
G1 X94.136 Y103.421 E.00915
M204 S250
G1 X94.214 Y103.774 F36000
; FEATURE: Outer wall
G1 F1200
M204 S6000
G1 X94.566 Y103.757 E.01027
G1 X95.299 Y103.57 E.02201
G1 X95.981 Y103.242 E.022
G1 X96.584 Y102.785 E.02202
M73 P82 R0
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.341 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.348 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02205
G1 X94.146 Y96.204 E.01775
G1 X93.434 Y96.243 E.02074
G1 X92.701 Y96.43 E.02202
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.022
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.652 E.022
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.249 Y103.724 E.02207
G1 X93.809 Y103.794 E.01641
G1 X94.154 Y103.777 E.01006
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.15687
G1 X95.299 Y103.57 E-.28749
G1 X95.981 Y103.242 E-.28738
G1 X96.04 Y103.197 E-.02827
; WIPE_END
G1 E-.04 F1800
G1 X97.1 Y99.623 Z6.6 F36000
G1 Z6.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1200
G1 X97.088 Y99.456 E.00488
G1 X96.918 Y98.854 E.01818
G1 X96.626 Y98.29 E.01849
G1 X90.877 Y99.83 E.17319
G1 X90.943 Y99.302 E.01549
G1 X91.142 Y98.711 E.01816
G1 X91.213 Y98.588 E.00412
G1 X95.409 Y102.784 E.17267
G1 X95.072 Y102.946 E.01087
G1 X94.467 Y103.1 E.01817
G1 X94.172 Y103.115 E.00861
G1 X95.709 Y97.378 E.17281
G1 X95.218 Y97.111 E.01627
G1 X94.614 Y96.925 E.01838
G1 X94.378 Y96.897 E.00691
; CHANGE_LAYER
; Z_HEIGHT: 6.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
M73 P83 R0
G1 X94.614 Y96.925 E-.09025
G1 X95.218 Y97.111 E-.24002
G1 X95.709 Y97.378 E-.21249
G1 X95.561 Y97.931 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z6.6 I-1.18 J-.297 P1  F36000
G1 X94.182 Y103.418 Z6.6
G1 Z6.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1200
G1 X94.513 Y103.402 E.00964
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
; object ids of layer 32 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer32 end: 12
M625
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01994
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.677 Y96.627 E.02008
G1 X94.139 Y96.563 E.01576
G1 X93.488 Y96.598 E.01896
G1 X92.823 Y96.767 E.01997
G1 X92.206 Y97.065 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01994
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.111 Y101.868 E.01997
G1 X91.515 Y102.379 E.01896
G1 X91.919 Y102.74 E.01575
G1 X92.507 Y103.1 E.02008
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
G1 X94.122 Y103.421 E.00855
M204 S250
G1 X94.2 Y103.775 F36000
; FEATURE: Outer wall
G1 F1200
M204 S6000
G1 X94.566 Y103.757 E.01067
G1 X95.299 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.846 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.341 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02202
G1 X96.72 Y97.348 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02206
G1 X94.151 Y96.204 E.0176
G1 X93.434 Y96.243 E.02088
G1 X92.701 Y96.43 E.02203
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02202
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.062 E.02203
G1 X91.254 Y102.625 E.02088
G1 X91.705 Y103.028 E.01759
G1 X92.352 Y103.423 E.02206
G1 X93.063 Y103.682 E.02202
M73 P84 R0
G1 X93.811 Y103.794 E.02201
G1 X94.14 Y103.778 E.00959
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.16221
G1 X95.299 Y103.57 E-.28748
G1 X95.981 Y103.242 E-.28743
G1 X96.029 Y103.205 E-.02287
; WIPE_END
G1 E-.04 F1800
G1 X91.19 Y101.356 Z6.8 F36000
G1 Z6.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1200
G1 X91.082 Y101.146 E.00688
G1 X90.912 Y100.544 E.01818
G1 X90.87 Y99.979 E.0165
G1 X96.695 Y98.418 E.17546
G1 X96.634 Y98.299 E.0039
G1 X96.245 Y97.811 E.01815
G1 X95.766 Y97.409 E.01818
G1 X95.581 Y97.309 E.00612
G1 X94.023 Y103.122 E.17513
G1 X94.467 Y103.1 E.01293
G1 X95.072 Y102.946 E.01817
G1 X95.544 Y102.719 E.01523
G1 X91.286 Y98.461 E.17521
G1 X91.454 Y98.17 E.00978
G1 X91.868 Y97.702 E.01817
G1 X92.24 Y97.419 E.01361
; CHANGE_LAYER
; Z_HEIGHT: 6.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X91.868 Y97.702 E-.1777
G1 X91.454 Y98.17 E-.23732
G1 X91.286 Y98.461 E-.12774
G1 X91.691 Y98.865 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z6.8 I-1.069 J.582 P1  F36000
G1 X94.168 Y103.419 Z6.8
G1 Z6.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1200
G1 X94.513 Y103.402 E.01004
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
; object ids of layer 33 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer33 end: 12
M625
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.677 Y96.626 E.02008
G1 X94.144 Y96.563 E.01563
G1 X93.488 Y96.598 E.0191
G1 X92.823 Y96.767 E.01996
G1 X92.206 Y97.064 E.01992
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
M73 P85 R0
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.111 Y101.867 E.01996
G1 X91.518 Y102.382 E.0191
G1 X91.918 Y102.74 E.01562
G1 X92.507 Y103.099 E.02008
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
G1 X94.108 Y103.422 E.00815
M204 S250
G1 X94.186 Y103.776 F36000
; FEATURE: Outer wall
G1 F1200
M204 S6000
G1 X94.566 Y103.757 E.01108
G1 X95.299 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.01099
G1 X97.741 Y99.341 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.348 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02206
G1 X94.155 Y96.205 E.01746
G1 X93.434 Y96.243 E.02102
G1 X92.701 Y96.43 E.02202
G1 X92.019 Y96.758 E.022
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02201
G1 X90.259 Y100.66 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.062 E.02202
G1 X91.257 Y102.628 E.02102
G1 X91.705 Y103.027 E.01745
G1 X92.352 Y103.423 E.02206
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.126 Y103.779 E.00919
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.16751
G1 X95.299 Y103.57 E-.28742
G1 X95.981 Y103.242 E-.28739
G1 X96.018 Y103.214 E-.01768
; WIPE_END
G1 E-.04 F1800
G1 X92.513 Y102.747 Z7 F36000
G1 Z6.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1200
G1 X92.64 Y102.825 E.00431
G1 X93.227 Y103.038 E.01818
G1 X93.875 Y103.13 E.01905
G1 X95.453 Y97.239 E.17745
G1 X95.766 Y97.409 E.01036
G1 X96.245 Y97.811 E.01818
G1 X96.634 Y98.299 E.01816
G1 X96.761 Y98.547 E.0081
G1 X90.881 Y100.122 E.17712
G1 X90.866 Y99.922 E.00584
M73 P86 R0
G1 X90.943 Y99.302 E.01817
G1 X91.142 Y98.71 E.01816
G1 X91.36 Y98.334 E.01264
G1 X95.672 Y102.647 E.17747
G1 X96.133 Y102.298 E.01681
G1 X96.546 Y101.83 E.01817
G1 X96.659 Y101.634 E.00659
; CHANGE_LAYER
; Z_HEIGHT: 6.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X96.546 Y101.83 E-.08603
G1 X96.133 Y102.298 E-.23726
G1 X95.672 Y102.647 E-.21947
G1 X95.268 Y102.243 E-.21724
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z7 I-.884 J-.836 P1  F36000
G1 X94.155 Y103.42 Z7
G1 Z6.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1200
G1 X94.513 Y103.402 E.01043
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
; object ids of layer 34 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer34 end: 12
M625
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.158 E.01994
G1 X95.336 Y96.83 E.01994
G1 X94.677 Y96.626 E.02009
G1 X94.148 Y96.563 E.01548
G1 X93.488 Y96.598 E.01924
G1 X92.823 Y96.767 E.01996
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01994
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.11 Y101.867 E.01993
G1 X91.537 Y102.402 E.01992
G1 X92.062 Y102.842 E.01994
G1 X92.664 Y103.17 E.01995
G1 X93.296 Y103.367 E.01925
G1 X93.823 Y103.436 E.01547
G1 X94.095 Y103.423 E.00791
M204 S250
G1 X94.173 Y103.776 F36000
; FEATURE: Outer wall
G1 F1200
M204 S6000
G1 X94.566 Y103.757 E.01147
G1 X95.299 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02202
G1 X94.751 Y96.276 E.02206
G1 X94.16 Y96.205 E.01732
G1 X93.434 Y96.243 E.02116
M73 P87 R0
G1 X92.701 Y96.43 E.02202
G1 X92.019 Y96.758 E.022
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02202
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02201
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.652 E.022
G1 X91.86 Y103.139 E.02202
G1 X92.525 Y103.501 E.02202
G1 X93.219 Y103.718 E.02117
G1 X93.809 Y103.794 E.01731
G1 X94.113 Y103.779 E.00885
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.17255
G1 X95.299 Y103.57 E-.28747
G1 X95.981 Y103.242 E-.28741
G1 X96.007 Y103.222 E-.01257
; WIPE_END
G1 E-.04 F1800
G1 X92.389 Y102.675 Z7.2 F36000
G1 Z6.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1200
G1 X92.783 Y102.89 E.01307
G1 X93.361 Y103.07 E.01762
G1 X93.732 Y103.118 E.01087
G1 X95.326 Y97.17 E.17919
G1 X95.766 Y97.41 E.0146
G1 X96.245 Y97.811 E.01817
G1 X96.634 Y98.299 E.01816
G1 X96.827 Y98.675 E.01231
G1 X90.892 Y100.266 E.17879
G1 X90.866 Y99.922 E.01003
G1 X90.943 Y99.302 E.01817
G1 X91.142 Y98.711 E.01816
G1 X91.433 Y98.207 E.0169
G1 X95.786 Y102.561 E.17914
G1 X96.133 Y102.298 E.01265
G1 X96.546 Y101.83 E.01816
G1 X96.73 Y101.51 E.01074
; CHANGE_LAYER
; Z_HEIGHT: 7
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X96.546 Y101.83 E-.14032
G1 X96.133 Y102.298 E-.23722
G1 X95.786 Y102.561 E-.16521
G1 X95.382 Y102.156 E-.21724
; WIPE_END
G1 E-.03999 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z7.2 I-.869 J-.852 P1  F36000
G1 X94.142 Y103.42 Z7.2
G1 Z7
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1200
G1 X94.513 Y103.402 E.01081
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
; object ids of layer 35 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer35 end: 12
M625
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
M73 P88 R0
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.158 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.676 Y96.626 E.02009
G1 X94.153 Y96.563 E.01534
G1 X93.488 Y96.598 E.01938
G1 X92.823 Y96.767 E.01995
G1 X92.206 Y97.065 E.01993
G1 X91.66 Y97.478 E.01993
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.111 Y101.867 E.01996
G1 X91.524 Y102.389 E.01937
G1 X91.918 Y102.739 E.01534
G1 X92.507 Y103.1 E.02009
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
G1 X94.082 Y103.423 E.00738
M204 S250
G1 X94.16 Y103.777 F36000
; FEATURE: Outer wall
G1 F1200
M204 S6000
G1 X94.566 Y103.757 E.01185
G1 X95.299 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.348 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02206
G1 X94.165 Y96.205 E.01717
G1 X93.434 Y96.243 E.0213
G1 X92.701 Y96.43 E.02202
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02201
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.062 E.02203
G1 X91.264 Y102.635 E.0213
G1 X91.705 Y103.027 E.01717
G1 X92.352 Y103.423 E.02206
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.1 Y103.78 E.00842
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.1775
G1 X95.299 Y103.57 E-.28749
G1 X95.981 Y103.242 E-.28746
G1 X95.997 Y103.23 E-.00755
; WIPE_END
G1 E-.04 F1800
G1 X97.119 Y100.2 Z7.4 F36000
G1 Z7
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1200
G1 X97.134 Y100.078 E.00358
G1 X97.088 Y99.456 E.01816
G1 X96.918 Y98.854 E.01818
G1 X96.893 Y98.804 E.00164
G1 X90.902 Y100.409 E.18045
G1 X90.866 Y99.922 E.01422
M73 P89 R0
G1 X90.943 Y99.302 E.01817
G1 X91.142 Y98.71 E.01817
G1 X91.454 Y98.17 E.01816
G1 X91.52 Y98.095 E.0029
G1 X95.9 Y102.475 E.18021
G1 X95.635 Y102.675 E.00967
G1 X95.072 Y102.946 E.01816
G1 X94.467 Y103.1 E.01817
G1 X93.844 Y103.131 E.01816
G1 X93.592 Y103.093 E.00741
G1 X95.197 Y97.104 E.18041
G1 X94.613 Y96.924 E.01777
G1 X94.143 Y96.867 E.01379
G1 X93.799 Y96.886 E.01
; CHANGE_LAYER
; Z_HEIGHT: 7.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10081.784
G1 X94.143 Y96.867 E-.1306
G1 X94.613 Y96.924 E-.18004
G1 X95.197 Y97.104 E-.23211
G1 X95.049 Y97.657 E-.21725
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z7.4 I-1.202 J-.192 P1  F36000
G1 X94.129 Y103.421 Z7.4
G1 Z7.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1200
G1 X94.513 Y103.402 E.01118
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01992
G1 X96.34 Y102.522 E.01994
; object ids of layer 36 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer36 end: 12
M625
G1 X96.793 Y102.008 E.01994
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01995
G1 X95.336 Y96.83 E.01993
G1 X94.676 Y96.626 E.02009
G1 X94.158 Y96.563 E.01521
G1 X93.488 Y96.598 E.01952
G1 X92.823 Y96.767 E.01995
G1 X92.206 Y97.064 E.01992
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.11 Y101.867 E.01995
G1 X91.527 Y102.392 E.01951
G1 X91.918 Y102.739 E.0152
G1 X92.507 Y103.1 E.02011
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
M73 P90 R0
G1 X94.069 Y103.424 E.00701
M204 S250
G1 X94.147 Y103.778 F36000
; FEATURE: Outer wall
G1 F1200
M204 S6000
G1 X94.566 Y103.757 E.01222
G1 X95.3 Y103.57 E.02201
G1 X95.981 Y103.242 E.022
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.348 E.022
G1 X96.14 Y96.861 E.02203
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02206
G1 X94.17 Y96.205 E.01704
G1 X93.434 Y96.243 E.02145
G1 X92.701 Y96.43 E.02202
G1 X92.019 Y96.758 E.022
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.061 E.02201
G1 X91.267 Y102.639 E.02144
G1 X91.704 Y103.027 E.01703
G1 X92.352 Y103.423 E.02207
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.087 Y103.781 E.00805
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.18237
G1 X95.3 Y103.57 E-.28746
G1 X95.981 Y103.242 E-.28735
G1 X95.987 Y103.237 E-.00283
; WIPE_END
G1 E-.04 F1800
G1 X96.73 Y100.435 Z7.6 F36000
G1 Z7.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1200
G1 X96.775 Y100.069 E.01073
G1 X96.734 Y99.518 E.01608
G1 X96.597 Y99.03 E.01476
G1 X91.264 Y100.459 E.16064
G1 X91.225 Y99.931 E.0154
G1 X91.293 Y99.382 E.01609
G1 X91.469 Y98.858 E.01608
G1 X91.746 Y98.379 E.01609
G1 X91.867 Y98.242 E.00534
G1 X95.759 Y102.133 E.16013
G1 X95.447 Y102.369 E.01136
G1 X94.95 Y102.609 E.01607
G1 X94.414 Y102.745 E.01609
G1 X93.849 Y102.773 E.01646
G1 X93.542 Y102.734 E.00901
G1 X94.969 Y97.408 E.16044
G1 X94.538 Y97.275 E.01312
M73 P91 R0
G1 X94.139 Y97.226 E.0117
G1 X93.565 Y97.26 E.01673
G1 X91.486 Y98.174 F36000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F1200
G1 X91.174 Y98.709 E.01714
G1 X90.975 Y99.294 E.01714
G1 X90.895 Y99.908 E.01715
G1 X90.938 Y100.524 E.01713
G1 X91.103 Y101.121 E.01715
G1 X91.383 Y101.674 E.01717
G1 X91.76 Y102.154 E.01692
G1 X92.181 Y102.512 E.0153
G1 X92.639 Y102.793 E.01488
G1 X93.219 Y103.007 E.01714
G1 X93.818 Y103.101 E.01681
G1 X94.448 Y103.074 E.01747
G1 X95.049 Y102.924 E.01714
G1 X95.607 Y102.659 E.01713
G1 X96.102 Y102.288 E.01715
G1 X96.514 Y101.826 E.01714
G1 X96.826 Y101.291 E.01714
G1 X97.025 Y100.706 E.01714
G1 X97.105 Y100.092 E.01715
G1 X97.061 Y99.46 E.01756
G1 X96.897 Y98.879 E.01674
G1 X96.618 Y98.327 E.01713
G1 X96.235 Y97.842 E.01713
G1 X95.762 Y97.441 E.01715
G1 X95.221 Y97.143 E.01714
G1 X94.607 Y96.952 E.01781
G1 X94.133 Y96.895 E.01322
G1 X93.553 Y96.925 E.0161
G1 X92.951 Y97.076 E.01716
G1 X92.393 Y97.341 E.01713
G1 X91.898 Y97.712 E.01715
G1 X91.526 Y98.13 E.01548
; CHANGE_LAYER
; Z_HEIGHT: 7.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F10588.235
G1 X91.898 Y97.712 E-.21231
G1 X92.393 Y97.341 E-.23517
G1 X92.951 Y97.076 E-.23498
G1 X93.149 Y97.026 E-.07754
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z7.6 I-1.203 J.182 P1  F36000
G1 X94.117 Y103.422 Z7.6
G1 Z7.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1200
G1 X94.513 Y103.402 E.01153
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
; object ids of layer 37 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer37 end: 12
M625
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01994
G1 X97.354 Y100.765 E.01993
G1 X97.439 Y100.086 E.01993
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01995
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.158 E.01994
G1 X95.336 Y96.83 E.01994
G1 X94.676 Y96.626 E.0201
G1 X94.162 Y96.563 E.01506
G1 X93.488 Y96.598 E.01965
G1 X92.823 Y96.767 E.01995
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01994
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01992
G1 X90.798 Y101.257 E.01994
G1 X91.11 Y101.866 E.01993
G1 X91.537 Y102.402 E.01993
G1 X92.062 Y102.842 E.01994
G1 X92.664 Y103.17 E.01994
M73 P92 R0
G1 X93.309 Y103.371 E.01966
G1 X93.823 Y103.436 E.01506
G1 X94.057 Y103.425 E.00683
M204 S250
G1 X94.135 Y103.778 F36000
; FEATURE: Outer wall
G1 F1200
M204 S6000
G1 X94.566 Y103.757 E.01257
G1 X95.299 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02201
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.341 E.01101
G1 X97.536 Y98.612 E.02203
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02202
G1 X94.751 Y96.276 E.02207
G1 X94.175 Y96.205 E.01689
G1 X93.434 Y96.243 E.02159
G1 X92.701 Y96.43 E.02202
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.783 E.02202
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.022
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.652 E.02201
G1 X91.86 Y103.139 E.02202
G1 X92.524 Y103.501 E.02201
G1 X93.233 Y103.721 E.0216
G1 X93.809 Y103.794 E.01688
G1 X94.075 Y103.781 E.00775
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.18695
G1 X95.299 Y103.57 E-.28747
G1 X95.977 Y103.244 E-.28557
; WIPE_END
G1 E-.04 F1800
G1 X90.739 Y99.677 Z7.8 F36000
G1 Z7.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42171
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X91.131 Y101.141 E.08624
G1 X91.406 Y101.676 E.03419
G1 X91.789 Y102.156 E.03499
G1 X91.922 Y102.268 E.00987
G1 X91.067 Y99.079 E.18786
G1 X91.185 Y98.73 E.02098
G1 X91.374 Y98.402 E.02156
G1 X92.525 Y102.696 E.253
G1 X92.801 Y102.846 E.01789
G1 X93.076 Y102.932 E.01641
G1 X91.734 Y97.923 E.2951
G1 X91.899 Y97.736 E.01419
G1 X92.126 Y97.564 E.01622
G1 X93.598 Y103.055 E.32349
G1 X93.836 Y103.085 E.01369
G1 X94.091 Y103.072 E.0145
G1 X92.542 Y97.291 E.3406
G1 X92.976 Y97.09 E.02725
G1 X94.567 Y103.027 E.3498
G1 X95.024 Y102.91 E.02685
G1 X93.433 Y96.973 E.3498
G1 X93.54 Y96.946 E.0063
G1 X93.909 Y96.927 E.02101
G1 X95.458 Y102.709 E.34065
M73 P93 R0
G1 X95.61 Y102.635 E.00961
G1 X95.874 Y102.436 E.01879
G1 X94.402 Y96.945 E.32349
G1 X94.603 Y96.97 E.01148
G1 X94.924 Y97.069 E.01913
G1 X96.266 Y102.077 E.29506
G1 X96.508 Y101.803 E.02081
G1 X96.626 Y101.598 E.01345
G1 X95.475 Y97.304 E.253
G1 X95.74 Y97.448 E.01715
G1 X96.078 Y97.732 E.02514
G1 X96.933 Y100.921 E.18786
G1 X97.011 Y100.687 E.01402
G1 X97.088 Y100.077 E.035
G1 X97.046 Y99.521 E.03174
G1 X96.66 Y98.082 E.08475
; CHANGE_LAYER
; Z_HEIGHT: 7.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X97.046 Y99.521 E-.56589
G1 X97.084 Y100.03 E-.19411
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
M106 S252.45
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z7.8 I-.914 J-.803 P1  F36000
G1 X94.105 Y103.422 Z7.8
G1 Z7.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1734
G1 X94.513 Y103.402 E.01187
G1 X95.177 Y103.233 E.01994
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
; object ids of layer 38 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer38 end: 12
M625
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.766 E.01993
G1 X97.439 Y100.086 E.01994
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01993
G1 X96.463 Y97.598 E.01993
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.676 Y96.626 E.02011
G1 X94.167 Y96.563 E.01493
G1 X93.488 Y96.598 E.01979
G1 X92.823 Y96.767 E.01995
G1 X92.206 Y97.065 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01992
G1 X90.864 Y98.585 E.01994
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01993
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01994
G1 X91.11 Y101.867 E.01995
G1 X91.534 Y102.399 E.01979
G1 X91.918 Y102.739 E.01492
G1 X92.507 Y103.1 E.02011
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01993
G1 X94.045 Y103.425 E.00631
M204 S250
G1 X94.123 Y103.779 F36000
; FEATURE: Outer wall
G1 F1734
M204 S6000
G1 X94.566 Y103.757 E.01291
G1 X95.3 Y103.57 E.02202
G1 X95.981 Y103.242 E.022
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.562 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02202
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02201
G1 X96.72 Y97.347 E.02201
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02207
G1 X94.18 Y96.205 E.01675
G1 X93.434 Y96.243 E.02173
G1 X92.701 Y96.43 E.02202
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.022
G1 X90.537 Y98.438 E.02202
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02201
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.061 E.02202
G1 X91.274 Y102.646 E.02173
G1 X91.704 Y103.027 E.01674
G1 X92.352 Y103.423 E.02207
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.063 Y103.782 E.00735
; WIPE_START
M73 P94 R0
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.19141
G1 X95.3 Y103.57 E-.28753
G1 X95.966 Y103.249 E-.28107
; WIPE_END
G1 E-.04 F1800
G1 X95.511 Y102.913 Z8 F36000
G1 Z7.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41095
G1 F1734
G1 X96.183 Y102.241 E.02852
G1 X96.546 Y101.83 E.01643
G1 X96.858 Y101.289 E.01872
G1 X96.981 Y100.922 E.01161
G1 X94.918 Y102.985 E.08749
G1 X94.467 Y103.1 E.01395
G1 X94.273 Y103.11 E.00583
G1 X97.11 Y100.273 E.1203
G1 X97.134 Y100.078 E.0059
G1 X97.11 Y99.753 E.00978
G1 X93.746 Y103.117 E.14267
G1 X93.294 Y103.048 E.01372
G1 X97.043 Y99.299 E.15903
G1 X96.929 Y98.893 E.01265
G1 X92.902 Y102.92 E.17081
G1 X92.64 Y102.825 E.00836
G1 X92.538 Y102.763 E.00356
G1 X96.759 Y98.543 E.17899
G1 X96.634 Y98.299 E.00821
G1 X96.566 Y98.214 E.00324
G1 X92.215 Y102.565 E.18453
G1 X92.099 Y102.494 E.0041
G1 X91.922 Y102.338 E.00707
G1 X96.335 Y97.925 E.18716
G1 X96.244 Y97.811 E.00437
G1 X96.073 Y97.667 E.00672
G1 X91.664 Y102.076 E.18698
G1 X91.434 Y101.786 E.01111
G1 X95.79 Y97.429 E.18476
G1 X95.457 Y97.241 E.01145
G1 X91.241 Y101.457 E.17881
G1 X91.071 Y101.107 E.01167
M73 P95 R0
G1 X95.103 Y97.075 E.17101
G1 X94.705 Y96.953 E.01248
G1 X90.957 Y100.701 E.15898
G1 X90.912 Y100.544 E.00489
G1 X90.89 Y100.247 E.00893
G1 X94.257 Y96.88 E.1428
G1 X94.156 Y96.868 E.00306
G1 X93.727 Y96.89 E.01287
G1 X90.89 Y99.727 E.12032
G1 X90.943 Y99.302 E.01283
G1 X91.019 Y99.078 E.00711
G1 X93.082 Y97.015 E.08749
G1 X92.928 Y97.054 E.00477
G1 X92.365 Y97.325 E.01872
G1 X91.895 Y97.681 E.01768
G1 X91.081 Y98.495 E.03451
; CHANGE_LAYER
; Z_HEIGHT: 7.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F9781.81
G1 X91.895 Y97.681 E-.4373
G1 X92.365 Y97.325 E-.22407
G1 X92.599 Y97.212 E-.09863
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z8 I-1.183 J.285 P1  F36000
G1 X94.094 Y103.423 Z8
G1 Z7.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1726
G1 X94.513 Y103.402 E.0122
G1 X95.177 Y103.233 E.01993
G1 X95.794 Y102.936 E.01993
G1 X96.34 Y102.522 E.01994
; object ids of layer 39 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer39 end: 12
M625
G1 X96.793 Y102.008 E.01993
G1 X97.136 Y101.415 E.01993
G1 X97.354 Y100.765 E.01994
G1 X97.439 Y100.086 E.01993
G1 X97.414 Y99.744 E.00996
G1 X97.388 Y99.403 E.00997
G1 X97.202 Y98.743 E.01994
G1 X96.89 Y98.133 E.01994
G1 X96.463 Y97.598 E.01992
G1 X95.938 Y97.157 E.01994
G1 X95.336 Y96.83 E.01993
G1 X94.676 Y96.626 E.02011
G1 X94.171 Y96.564 E.01479
G1 X93.487 Y96.598 E.01993
G1 X92.823 Y96.767 E.01993
G1 X92.206 Y97.064 E.01993
G1 X91.66 Y97.478 E.01994
G1 X91.207 Y97.992 E.01993
G1 X90.864 Y98.585 E.01993
G1 X90.646 Y99.234 E.01993
G1 X90.561 Y99.914 E.01994
G1 X90.612 Y100.597 E.01993
G1 X90.798 Y101.257 E.01995
G1 X91.11 Y101.867 E.01994
G1 X91.533 Y102.397 E.01972
G1 X92.067 Y102.847 E.02033
G1 X92.507 Y103.1 E.01477
G1 X93.151 Y103.334 E.01994
G1 X93.829 Y103.436 E.01994
G1 X94.034 Y103.426 E.00599
M204 S250
G1 X94.112 Y103.779 F36000
; FEATURE: Outer wall
G1 F1726
M204 S6000
G1 X94.566 Y103.757 E.01324
G1 X95.3 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02202
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.845 E.02202
G1 X97.798 Y100.095 E.02201
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02202
G1 X96.72 Y97.347 E.022
G1 X96.14 Y96.861 E.02202
G1 X95.476 Y96.499 E.02201
G1 X94.751 Y96.276 E.02207
G1 X94.184 Y96.205 E.01661
M73 P96 R0
G1 X93.434 Y96.243 E.02187
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.438 E.02201
G1 X90.296 Y99.155 E.02201
G1 X90.202 Y99.905 E.02201
G1 X90.259 Y100.659 E.02201
G1 X90.464 Y101.388 E.02203
G1 X90.809 Y102.061 E.02201
G1 X91.275 Y102.647 E.02179
G1 X91.862 Y103.14 E.02229
G1 X92.356 Y103.425 E.0166
G1 X93.063 Y103.682 E.02188
G1 X93.811 Y103.794 E.02201
G1 X94.052 Y103.782 E.00702
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.19577
G1 X95.3 Y103.57 E-.28745
G1 X95.956 Y103.254 E-.27678
; WIPE_END
G1 E-.04 F1800
G1 X92.511 Y102.938 Z8.2 F36000
G1 Z7.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41116
G1 F1726
G1 X91.724 Y102.151 E.0334
G1 X91.367 Y101.701 E.01723
G1 X91.082 Y101.146 E.01874
G1 X91.02 Y100.925 E.00688
G1 X93.079 Y102.985 E.08741
G1 X93.226 Y103.038 E.00469
G1 X93.729 Y103.114 E.01526
G1 X90.892 Y100.277 E.12039
G1 X90.866 Y99.922 E.01069
G1 X90.887 Y99.751 E.00516
G1 X94.247 Y103.111 E.14259
G1 X94.468 Y103.1 E.00662
G1 X94.698 Y103.041 E.00714
G1 X90.947 Y99.291 E.15917
G1 X91.078 Y98.901 E.01234
G1 X95.107 Y102.929 E.17096
G1 X95.458 Y102.76 E.01171
G1 X91.24 Y98.542 E.17902
G1 X91.43 Y98.211 E.01144
G1 X95.782 Y102.563 E.18468
G1 X96.079 Y102.339 E.01115
G1 X91.668 Y97.928 E.18718
G1 X91.868 Y97.702 E.00905
G1 X91.922 Y97.661 E.00203
G1 X96.332 Y102.072 E.18718
G1 X96.57 Y101.788 E.01109
M73 P97 R0
G1 X92.218 Y97.436 E.18468
G1 X92.365 Y97.325 E.00555
G1 X92.542 Y97.24 E.00588
G1 X96.76 Y101.458 E.17902
G1 X96.858 Y101.289 E.00585
G1 X96.922 Y101.099 E.00603
G1 X92.893 Y97.07 E.17095
G1 X93.302 Y96.958 E.01272
G1 X97.053 Y100.709 E.15916
G1 X97.113 Y100.248 E.01394
G1 X93.753 Y96.889 E.14258
G1 X94.16 Y96.868 E.01223
G1 X94.266 Y96.881 E.00321
G1 X97.108 Y99.722 E.12057
G1 X97.088 Y99.456 E.00803
G1 X96.98 Y99.074 E.01189
G1 X94.927 Y97.021 E.08712
G1 X95.218 Y97.111 E.00912
G1 X95.766 Y97.41 E.01873
G1 X96.203 Y97.776 E.0171
G1 X96.907 Y98.48 E.0299
; CHANGE_LAYER
; Z_HEIGHT: 8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F9776.232
G1 X96.203 Y97.776 E-.37864
G1 X95.766 Y97.41 E-.21661
G1 X95.385 Y97.202 E-.16475
; WIPE_END
G1 E-.04 F1800
; stop printing object, unique label id: 12
M625
; OBJECT_ID: 12
; start printing object, unique label id: 12
M624 AgAAAAAAAAA=
G17
G3 Z8.2 I-1.194 J-.233 P1  F36000
G1 X94.101 Y103.78 Z8.2
G1 Z8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1726
M204 S6000
G1 X94.566 Y103.757 E.01356
G1 X95.3 Y103.57 E.02201
G1 X95.981 Y103.242 E.02201
G1 X96.584 Y102.785 E.02201
; object ids of layer 40 start: 12
M624 AgAAAAAAAAA=
; object ids of this layer40 end: 12
M625
G1 X97.085 Y102.218 E.02201
G1 X97.463 Y101.563 E.02201
G1 X97.704 Y100.845 E.02201
G1 X97.798 Y100.095 E.02201
G1 X97.77 Y99.718 E.011
G1 X97.741 Y99.34 E.01101
G1 X97.536 Y98.612 E.02202
G1 X97.191 Y97.939 E.02202
G1 X96.721 Y97.349 E.02194
G1 X96.14 Y96.861 E.02209
G1 X95.476 Y96.499 E.02201
G1 X94.939 Y96.319 E.01646
G1 X94.187 Y96.206 E.02214
G1 X93.434 Y96.243 E.02194
G1 X92.701 Y96.43 E.02201
G1 X92.019 Y96.758 E.02201
G1 X91.416 Y97.215 E.02202
G1 X90.915 Y97.782 E.02201
G1 X90.537 Y98.437 E.02201
G1 X90.296 Y99.154 E.02201
G1 X90.202 Y99.905 E.02202
G1 X90.259 Y100.659 E.022
G1 X90.464 Y101.388 E.02202
G1 X90.809 Y102.061 E.02201
G1 X91.28 Y102.653 E.02201
G1 X91.704 Y103.027 E.01647
M73 P98 R0
G1 X92.352 Y103.423 E.02207
G1 X93.063 Y103.682 E.02202
G1 X93.811 Y103.794 E.02201
G1 X94.041 Y103.783 E.00671
; WIPE_START
G1 F10082.057
M204 S10000
G1 X94.566 Y103.757 E-.19986
G1 X95.3 Y103.57 E-.28745
G1 X95.946 Y103.259 E-.2727
; WIPE_END
G1 E-.04 F1800
G1 X95.726 Y103.206 F36000
G1 Z8.4
G1 Z8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.41
G1 F1726
M204 S2000
G1 X96.422 Y102.51 E.02946
G1 X96.837 Y102.04 E.01875
G1 X97.185 Y101.437 E.02081
G1 X97.291 Y101.122 E.00994
G1 X95.107 Y103.306 E.09238
G1 X94.521 Y103.455 E.01809
G1 X94.434 Y103.459 E.0026
G1 X97.448 Y100.445 E.12749
G1 X97.493 Y100.087 E.0108
G1 X97.479 Y99.896 E.00574
G1 X93.888 Y103.487 E.1519
G1 X93.826 Y103.49 E.00185
G1 X93.426 Y103.429 E.0121
G1 X97.442 Y99.413 E.16991
G1 X97.332 Y99.005 E.01265
G1 X93 Y103.336 E.18323
G1 X92.62 Y103.197 E.01212
G1 X97.199 Y98.618 E.1937
G1 X97.023 Y98.275 E.01154
G1 X92.277 Y103.021 E.20077
G1 X91.954 Y102.824 E.0113
G1 X96.82 Y97.959 E.20581
G1 X96.589 Y97.67 E.01105
G1 X91.669 Y102.591 E.20815
G1 X91.501 Y102.443 E.00669
G1 X91.411 Y102.33 E.00433
G1 X96.327 Y97.414 E.20795
G1 X96.044 Y97.177 E.01102
M73 P99 R0
G1 X91.181 Y102.041 E.20575
G1 X91.065 Y101.896 E.00555
G1 X90.977 Y101.725 E.00574
G1 X95.723 Y96.979 E.20075
G1 X95.387 Y96.796 E.01145
G1 X90.801 Y101.382 E.19398
G1 X90.748 Y101.277 E.00353
G1 X90.668 Y100.996 E.00874
G1 X95.004 Y96.66 E.18339
G1 X94.868 Y96.615 E.00428
G1 X94.574 Y96.571 E.00889
G1 X90.558 Y100.587 E.16991
G1 X90.521 Y100.104 E.01449
G1 X94.113 Y96.513 E.15192
G1 X93.566 Y96.541 E.01637
G1 X90.552 Y99.555 E.1275
G1 X90.594 Y99.222 E.01002
G1 X90.709 Y98.878 E.01085
G1 X92.893 Y96.694 E.09239
G1 X92.805 Y96.717 E.00273
G1 X92.178 Y97.019 E.02081
G1 X91.649 Y97.419 E.01985
G1 X90.799 Y98.269 E.03595
; close powerlost recovery
M1003 S0
; WIPE_START
G1 F9807.126
M204 S10000
G1 X91.649 Y97.419 E-.45666
G1 X92.178 Y97.019 E-.25221
G1 X92.299 Y96.96 E-.05113
; WIPE_END
G1 E-.04 F1800
G17
G3 Z8.4 I1.217 J0 P1  F36000
; stop printing object, unique label id: 12
M625
M106 S0
M981 S0 P20000 ; close spaghetti detector
; FEATURE: Custom
; MACHINE_END_GCODE_START
M104 S0 ; turn off temperature
G28 X0  ; home X axis
M84     ; disable motors
M73 P100 R0
; EXECUTABLE_BLOCK_END

